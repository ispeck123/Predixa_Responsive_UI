import { Component, ViewChild } from '@angular/core';
import { IdleTimeoutService } from './services/idle-timeout.service';
import { NavigationEnd, Router } from '@angular/router';
import { filter } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'fin_product';
   showLayout = true;
   private hideOn: string[] = ['/', '/login', '/landing', '/feature'];

 constructor(private router: Router) {
    this.router.events
      .pipe(filter(e => e instanceof NavigationEnd))
      .subscribe((e: any) => {
        const url = e.urlAfterRedirects.split('?')[0];
        this.showLayout = !this.hideOn.includes(url);
      });
  }

}
