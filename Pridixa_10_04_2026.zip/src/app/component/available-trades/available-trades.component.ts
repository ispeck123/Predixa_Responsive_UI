import { AfterViewInit, ChangeDetectorRef, Component, ElementRef, HostListener, OnInit, QueryList, ViewChild, ViewChildren } from '@angular/core';
import { Router, TitleStrategy } from '@angular/router';
import { createChart, CrosshairMode } from 'lightweight-charts';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { ApiService } from 'src/app/services/api.service';
import { RectangleDrawingTool } from '../homecandles/rectangle-drawing-tool';
import moment from 'moment';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { WebSocketService } from 'src/app/services/web-socket.service';
import { debounceTime, filter, forkJoin, fromEvent, map, Subscription, timestamp } from 'rxjs';
import { Subject } from 'rxjs';
import { FloatingModalComponent } from '../floating-modal/floating-modal.component';
import { formatDate } from '@angular/common';



type Patch = Partial<{
  optimized_buy_sell_zone: boolean;
  qualified_zones: boolean;
}>;

type MenuRule = {
  base: string;
  overlap_evaluate?: Record<string, Patch>;
  overlap_analyze?: Record<string, Patch>;
};

// exchange_name -> activeMenu -> rule
const EXCHANGE_MENU_RULES: Record<string, Record<string, MenuRule>> = {
  // ======================
  // NSE
  // ======================
  NSE: {
    daily: {
      base: "daily",
      overlap_evaluate: {
        monthly: { qualified_zones: false, optimized_buy_sell_zone: true },
      },
      overlap_analyze: {
        weekly: { qualified_zones: false, optimized_buy_sell_zone: true },
      }
    },

    sixty: {
      base: "sixty",
      overlap_evaluate: {
        weekly: { optimized_buy_sell_zone: true },
        seventy_five: { optimized_buy_sell_zone: true },
      },
      overlap_analyze: {
        daily: { optimized_buy_sell_zone: true },
        seventy_five: { optimized_buy_sell_zone: true },
      }
    },

    fifteen: {
      base: "fifteen",
      overlap_evaluate: {
        daily: { optimized_buy_sell_zone: true },
      },
      overlap_analyze: {
        sixty: { optimized_buy_sell_zone: true },
      }
    },

    one_twenty_five: {
      base: "one_twenty_five",
      overlap_evaluate: {
        weekly: { optimized_buy_sell_zone: true },
      },
      overlap_analyze: {
        daily: { optimized_buy_sell_zone: true },
      }
    },

    seventy_five: {
      base: "seventy_five",
      overlap_evaluate: {
        weekly: { optimized_buy_sell_zone: true },
      },
      overlap_analyze: {
        daily: { optimized_buy_sell_zone: true },
      }
    },

    twenty_five: {
      base: "twenty_five",
      overlap_evaluate: {
        daily: { optimized_buy_sell_zone: true },
      },
      overlap_analyze: {
        one_twenty_five: { optimized_buy_sell_zone: true },
      }
    },
  },

  // ======================
  // NSEFO (your static code)
  // ======================
  NSEFO: {
    daily: {
      base: "daily",
      overlap_evaluate: { monthly: { optimized_buy_sell_zone: true } },
      overlap_analyze: { weekly: { optimized_buy_sell_zone: true } },
    },

    seventy_five: {
      base: "seventy_five",
      overlap_evaluate: { weekly: { optimized_buy_sell_zone: true } },
      overlap_analyze: { daily: { optimized_buy_sell_zone: true } },
    },

    sixty: {
      base: "sixty",
      overlap_evaluate: { weekly: { optimized_buy_sell_zone: true } },
      overlap_analyze: { daily: { optimized_buy_sell_zone: true } },
    },

    fifteen: {
      base: "fifteen",
      overlap_evaluate: { daily: { optimized_buy_sell_zone: true } },
      overlap_analyze: { seventy_five: { optimized_buy_sell_zone: true } },
    },
  },

  // ======================
  // MCX (your static code)
  // ======================
  MCX: {
    daily: {
      base: "daily",
      overlap_evaluate: { monthly: { optimized_buy_sell_zone: true } },
      overlap_analyze: { weekly: { optimized_buy_sell_zone: true } },
    },

    two_forty: {
      base: "two_forty",
      overlap_evaluate: { weekly: { optimized_buy_sell_zone: true } },
      overlap_analyze: { daily: { optimized_buy_sell_zone: true } },
    },

    sixty: {
      base: "sixty",
      overlap_evaluate: { daily: { optimized_buy_sell_zone: true } },
      overlap_analyze: { two_forty: { optimized_buy_sell_zone: true } },
    },

    one_twenty: {
      base: "one_twenty",
      overlap_evaluate: { daily: { optimized_buy_sell_zone: true } },
      // your static code had "tro_forty" typo; using "two_forty"
      overlap_analyze: { two_forty: { optimized_buy_sell_zone: true } },
    },
  },
};



@Component({
  selector: 'app-available-trades',
  templateUrl: './available-trades.component.html',
  styleUrls: ['./available-trades.component.css']
})
export class AvailableTradesComponent implements OnInit {
  private overlapMemory: Record<string, { evaluate: boolean; analyze: boolean; qualified: boolean }> = {};
  modalAPos = { top: 0, left: 0 };
  EntryEndTime: any
  LastValidEntryPrice: any;
  LastValidEntryTime: any;
  LastValidEntryEndTime: any;
  TargetStartTime: any;
  TargetEndTime: any;
  LastValidTargetPrice: any;
  LastValidTargetStartTime: any;
  LastValidTargetEndTime: any;
  StopStartTime: any;
  StopEndTime: any;
  LastValidStopPrice: any;
  LastValidStopStartTime: any;
  LastValidStopEndTime: any;
  @ViewChild('modalalert') modalalert!: FloatingModalComponent;
  @ViewChild('chart_container_new') chartContainer!: ElementRef;
  @ViewChild('modalA') modalA!: FloatingModalComponent;
  lastBar: any;
  PreviousHighData: any;
  selectedTradeType: any;
  selectedTradeId: any;
  activeMenu: string = 'daily';
  realTimePrice: any;
  DailyTrades: any;
  SixtyTrades: any;
  FifteenTrades: any;
  TwoFortyTrades: any;
  OneTwentyTrades: any;
  SeventyFiveTrades: any;
  OneTwentyFiveTrades: any;
  TwentyFiveTrades: any;
  candles: { color: string; height: number, wickHeight: number }[] = [];
  colorInterval: any;
  showmsg: any;
  stockData: any;
  selectedStock: any = "All";
  SpinnerCounter: any;
  SelectedStockName: any;
  finData: any;
  time_frame: any = 1;
  FullScreenModeValue: any;
  ModalHeader: any;
  QualifiedData: any;
  BaseCandleData: any;
  BuyZoneData: any;
  SellZoneData: any;
  AllZonesData: any;
  OverLayCandleData: any;
  BuyOverlayData: any;
  SellOverlayData: any;
  ChartRESPONSE: any;
  lastTime: any;
  status: any;
  purchased_date: any;
  entry_timestamp: any;
  completed_on: any;
  entry_price: any;
  stoploss_price: any;
  target_price: any;
  order_type: any;
  private buylineSeries: any;
  private targetlineSeries: any;
  private stoplosslineSeries: any;
  chart: any;
  timestampInSeconds_completed: any;
  selectedOptions: any = {
    base_candle: false,
    buy_sell_zone: false,
    bad_zone: false,
    setup: false,
    overlap_evaluate: false,
    overlap_analyze: false
  };
  ModelPrediction: any;
  private candlestickSeries: any;
  rectangleTool: any;
  toolTipData: any;
  Open: any;
  High: any;
  Low: any;
  private areaSeries: any;
  Close: any;
  CandleColor: any;
  dropdownShow: any;
  lastRow: any;
  xspan: any;
  BadZoneData: any;
  fincreateform: FormGroup;
  fincreateformForPanel: FormGroup;
  submitted = false;
  SelectedStock: any;
  RRR: any;
  @ViewChild('closemodal') closemodal!: ElementRef;
  Role: any;
  UserName: any;
  isAdmin: boolean = false;
  SelectedCountryId: any;
  SelectedCountryName: any;
  lastCMPLine: any = null;
  FullChartResponse: any;
  QualifiedZoneFlag: boolean = false;
  sortColumn: string = '';
  sortDirection: 'asc' | 'desc' = 'asc';
  highlightedStockNames: string[] = [];
  highlightedStockNamesSixty: string[] = [];
  highlightedStockNamesFifteen: string[] = [];
  highlightedStockNames240: string[] = [];
  highlightedStockNames120: string[] = [];
  highlightedStockNames75: string[] = [];
  highlightedStockNames125: string[] = [];
  highlightedStockNames25: string[] = [];
  typedText: string = '';
  private keySub!: Subscription;
  @ViewChildren('stockCell') stockCells!: QueryList<ElementRef>;
  totalCount: any;
  currentPage: any;
  exchanges: any;
  selectedExchange: any;
  SelectedStockId: any;
  dailyState = {
    currentPage: 1,
    totalCount: 0,
    searchKey: '',
    trades: [] as any[]
  };

  sixtyState = {
    currentPage: 1,
    totalCount: 0,
    searchKey: '',
    trades: [] as any[]
  };

  fifteenState = {
    currentPage: 1,
    totalCount: 0,
    searchKey: '',
    trades: [] as any[]
  };

  twofortyState = {
    currentPage: 1,
    totalCount: 0,
    searchKey: '',
    trades: [] as any[]
  };

  onetwentyState = {
    currentPage: 1,
    totalCount: 0,
    searchKey: '',
    trades: [] as any[]
  };


  seventyfiveState = {
    currentPage: 1,
    totalCount: 0,
    searchKey: '',
    trades: [] as any[]
  };

  onetwentyfiveState = {
    currentPage: 1,
    totalCount: 0,
    searchKey: '',
    trades: [] as any[]
  };
  twentyfiveState = {
    currentPage: 1,
    totalCount: 0,
    searchKey: '',
    trades: [] as any[]
  };

  pageSize = 10;
  searchText: string = '';
  searchSubject: Subject<string> = new Subject<string>();
  selectedDateRange: any;
  SelectedTimeFrame: any;
  getting_Stock_Tick_by_StockName: any;
  PricePercentageData: any;
  PP_Analyze: any;
  PP_Evaluate: any;
  PP_Execute: any;
  PP_Reason: any;
  PP_FinalDecision: any;
  showPopup = false;

  ranges: any = {
    'All': [moment('2019-01-01'), moment()],
    'Today': [moment(), moment()],
    'Last 7 Days': [moment().subtract(6, 'days'), moment()],
    'Last 15 Days': [moment().subtract(14, 'days'), moment()],
    'This Month': [moment().startOf('month'), moment().endOf('month')],
    'Last 3 Months': [moment().subtract(3, 'months').startOf('month'), moment().subtract(1, 'month').endOf('month')], // Last 3 months excluding current month
    'Last 6 Months': [moment().subtract(6, 'months').startOf('month'), moment().subtract(1, 'month').endOf('month')]
  }
  invalidDates: moment.Moment[] = [moment().add(2, 'days'), moment().add(3, 'days'), moment().add(5, 'days')];
  isInvalidDate = (m: moment.Moment) => {
    return this.invalidDates.some(d => d.isSame(m, 'day'))
  }
  pageSizeOptions = [10, 25, 50, 100];
  StartDate: any;
  EndDate: any;
  highlightedStockTick: string = '';
  MatchedCount: number = 0;
  alertForm: FormGroup;
  countryId: any;
  userId: any;
  submitStock = false;
  allSetAlerts: any = [];
  SelectedExchange_Id: any = 8;
  SelectedExchange_Name: any;
  stockId: string;
  showCreateOrderModal = false;
  showCreateOrderModalforButtonClick = false;
  fincreateorderData: any;
  submit: boolean = false;
  updateModelPredictionFlag: boolean = false;
  EntryPrice: any;
  EntryTime: any;
  StoplossPrice: any;
  TargetPrice: any;
  isNotificationVisible: boolean = false;
  SETUPTYPE: any;
  UpdateTradeFlag = false;
  Prediction: any;
  Probability: any;
  SelectedExpiryDate: any;
  OptimizedBuySellZoneData: any;
  isChecked: boolean = true;
  isCheckedForCMP: boolean = false;
  showReasonPanel = false;
  reasons: string[] = [];
  tradeTypeOpen = false;
  isPopupOpen = false;
  selectTradeType: any = "all";
  EXP_NUM: any;
  SelectedTradeId: any;
  isMobile: boolean = false;
  isMobileActionPanelOpen = false;
  isMobileScreen = false;
  showMobileTradeMenu = false;
  isLeftBarOpen = false;
  ScoreData: any;

  constructor(private elementRef: ElementRef, private cdr: ChangeDetectorRef, private formBuilder: FormBuilder, private toastr: ToastrService, private webSocketService: WebSocketService, private router: Router, private spinner: NgxSpinnerService, private apiService: ApiService) {
    this.xspan = 3600;
  }

  @HostListener('document:click', ['$event'])
  onOutsideClick(event: MouseEvent) {
    if (!this.isLeftBarOpen) return;

    const leftBar = document.getElementById('leftBar');
    const target = event.target as HTMLElement;

    if (leftBar && leftBar.contains(target)) return;

    const settingsBtn = target.closest('.trade-header__settings');
    if (settingsBtn) return;

    this.openBar(false);
  }

  toggleMobileTradeMenu(): void {
    this.showMobileTradeMenu = !this.showMobileTradeMenu;
  }

  closeMobileTradeMenu(): void {
    this.showMobileTradeMenu = false;
  }

  @HostListener('document:click', ['$event'])
  onClickOutside(event: MouseEvent) {
    const clickedInsidePopup = (event.target as HTMLElement).closest('.filter-popup');
    const clickedOnButton = (event.target as HTMLElement).closest('.filter-btn');

    if (!clickedInsidePopup && !clickedOnButton) {
      this.isPopupOpen = false;
    }
  }

  togglePopup(event: MouseEvent) {
    event.stopPropagation(); // prevent immediate close
    this.isPopupOpen = !this.isPopupOpen;
  }




  @HostListener('window:keydown', ['$event'])
  handleKeyDown(event: KeyboardEvent): void {
    // ✅ Prevent shortcut logic if focus is in an input or textarea
    const tagName = (event.target as HTMLElement).tagName.toLowerCase();
    const isEditable = (event.target as HTMLElement).isContentEditable;

    if (tagName === 'input' || tagName === 'textarea' || isEditable) {
      return;
    }
    // this.QualifiedZoneFlag = false;
    if (event.key == "ArrowLeft") {
      this.shiftChart(-10);
    }
    if (event.key == "ArrowRight") {
      this.shiftChart(10);
    }

    if (event.key == "+" || event.key == "=") {
      this.scaleChart(1 / 8, true);
    }

    if (event.key == "-") {
      this.scaleChart(1 / 8, false);
    }

    let dataPresent = false;
    if (this.selectedExchange.exchange_name == "NSE") {
      if (this.activeMenu == "daily") {
        switch (event.key) {
          case 'm':
          case 'M':
            dataPresent = !!this.FullChartResponse['monthly'];
            if (dataPresent) {
              // this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = false;
              this.ChangeScreenMode('monthly', 'chart-container_new', false);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
          case 'd':
          case 'D':
            dataPresent = !!this.FullChartResponse['daily'];
            if (dataPresent) {
              this.QualifiedZoneFlag = true;
              // this.selectedOptions = []
              this.dropdownShow = false;
              this.ChangeScreenMode('daily', 'chart-container_new', true);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
          case 'w':
          case 'W':
            dataPresent = !!this.FullChartResponse['weekly'];
            if (dataPresent) {
              // this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = false;
              this.ChangeScreenMode('weekly', 'chart-container_new', false);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
        }
      }

      if (this.activeMenu == "sixty") {
        switch (event.key) {
          case '7':
            dataPresent = !!this.FullChartResponse['seventy_five'];
            if (dataPresent) {
              // this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = false;
              this.ChangeScreenMode('seventy_five', 'chart-container_new', false);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
          case 'd':
          case 'D':
            dataPresent = !!this.FullChartResponse['daily'];
            if (dataPresent) {
              // this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = false;
              this.ChangeScreenMode('daily', 'chart-container_new', false);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
          case '6':
            dataPresent = !!this.FullChartResponse['sixty'];
            if (dataPresent) {
              // this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = true;
              this.ChangeScreenMode('sixty', 'chart-container_new', true);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
          case 'w':
          case 'W':
            dataPresent = !!this.FullChartResponse['weekly'];
            if (dataPresent) {
              // this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = false;
              this.ChangeScreenMode('weekly', 'chart-container_new', false);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
        }
      }

      if (this.activeMenu == "fifteen") {
        switch (event.key) {
          case '5':
            dataPresent = !!this.FullChartResponse['fifteen'];
            if (dataPresent) {
              // this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = true;
              this.ChangeScreenMode('fifteen', 'chart-container_new', true);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
          case 'd':
          case 'D':
            dataPresent = !!this.FullChartResponse['daily'];
            if (dataPresent) {
              // this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = false;
              this.ChangeScreenMode('daily', 'chart-container_new', false);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
          // case '7':
          //   dataPresent = !!this.FullChartResponse['seventy_five'];
          //   if (dataPresent) {
          //     this.selectedOptions = []
          //     this.dropdownShow = false;
          //     this.QualifiedZoneFlag = false;
          //     this.ChangeScreenMode('seventy_five', 'chart-container_new',false);
          //   }
          //   else {
          //     this.toastr.error(`No Data Found !`)
          //   }
          //   break;
          case '6':
            dataPresent = !!this.FullChartResponse['sixty'];
            if (dataPresent) {
              // this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = false;
              this.ChangeScreenMode('sixty', 'chart-container_new', false);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
        }
      }

      if (this.activeMenu == "seventy_five") {
        switch (event.key) {
          case '7':
            dataPresent = !!this.FullChartResponse['seventy_five'];
            if (dataPresent) {
              // this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = true;
              this.ChangeScreenMode('seventy_five', 'chart-container_new', true);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
          case 'd':
          case 'D':
            dataPresent = !!this.FullChartResponse['daily'];
            if (dataPresent) {
              // this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = false;
              this.ChangeScreenMode('daily', 'chart-container_new', false);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
          case 'w':
          case 'W':
            dataPresent = !!this.FullChartResponse['weekly'];
            if (dataPresent) {
              // this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = false;
              this.ChangeScreenMode('weekly', 'chart-container_new', false);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
        }
      }

      if (this.activeMenu == "one_twenty_five") {
        switch (event.key) {
          case '1':
            dataPresent = !!this.FullChartResponse['one_twenty_five'];
            if (dataPresent) {
              // this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = true;
              this.ChangeScreenMode('one_twenty_five', 'chart-container_new', true);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
          case 'd':
          case 'D':
            dataPresent = !!this.FullChartResponse['daily'];
            if (dataPresent) {
              // this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = false;
              this.ChangeScreenMode('daily', 'chart-container_new', false);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
          case 'w':
          case 'W':
            dataPresent = !!this.FullChartResponse['weekly'];
            if (dataPresent) {
              // this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = false;
              this.ChangeScreenMode('weekly', 'chart-container_new', false);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
          case 'm':
          case 'M':
            dataPresent = !!this.FullChartResponse['monthly'];
            if (dataPresent) {
              // this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = false;
              this.ChangeScreenMode('monthly', 'chart-container_new', false);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
        }
      }

      if (this.activeMenu == "twenty_five") {
        switch (event.key) {
          case '2':
            dataPresent = !!this.FullChartResponse['twenty_five'];
            if (dataPresent) {
              // this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = true;
              this.ChangeScreenMode('twenty_five', 'chart-container_new', true);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
          case '1':
            dataPresent = !!this.FullChartResponse['one_twenty_five'];
            if (dataPresent) {
              // this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = false;
              this.ChangeScreenMode('one_twenty_five', 'chart-container_new', false);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
          case 'd':
          case 'D':
            dataPresent = !!this.FullChartResponse['daily'];
            if (dataPresent) {
              // this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = false;
              this.ChangeScreenMode('daily', 'chart-container_new', false);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
        }
      }
    }

    if (this.selectedExchange.exchange_name == "MCX") {
      if (this.activeMenu == "daily") {
        switch (event.key) {
          case 'm':
          case 'M':
            dataPresent = !!this.FullChartResponse['monthly'];
            if (dataPresent) {
              // this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = false;
              this.ChangeScreenMode('monthly', 'chart-container_new', false);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
          case 'd':
          case 'D':
            dataPresent = !!this.FullChartResponse['daily'];
            if (dataPresent) {
              this.QualifiedZoneFlag = true;
              this.selectedOptions = []
              this.dropdownShow = false;
              this.ChangeScreenMode('daily', 'chart-container_new', true);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
          case 'w':
          case 'W':
            dataPresent = !!this.FullChartResponse['weekly'];
            if (dataPresent) {
              this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = false;
              this.ChangeScreenMode('weekly', 'chart-container_new', false);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
        }
      }

      if (this.activeMenu == "sixty") {
        switch (event.key) {
          case '4':
            dataPresent = !!this.FullChartResponse['two_forty'];
            if (dataPresent) {
              // this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = false;
              this.ChangeScreenMode('two_forty', 'chart-container_new', false);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
          case 'd':
          case 'D':
            dataPresent = !!this.FullChartResponse['daily'];
            if (dataPresent) {
              this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = false;
              this.ChangeScreenMode('daily', 'chart-container_new', false);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
          case '6':
            dataPresent = !!this.FullChartResponse['sixty'];
            if (dataPresent) {
              this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = true;
              this.ChangeScreenMode('sixty', 'chart-container_new', true);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
        }
      }

      if (this.activeMenu == "one_twenty") {
        switch (event.key) {
          case '2':
            dataPresent = !!this.FullChartResponse['one_twenty'];
            if (dataPresent) {
              // this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = true;
              this.ChangeScreenMode('one_twenty', 'chart-container_new', true);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
          case 'd':
          case 'D':
            dataPresent = !!this.FullChartResponse['daily'];
            if (dataPresent) {
              this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = false;
              this.ChangeScreenMode('daily', 'chart-container_new', false);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
          case '4':
            dataPresent = !!this.FullChartResponse['two_forty'];
            if (dataPresent) {
              this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = false;
              this.ChangeScreenMode('two_forty', 'chart-container_new', false);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
        }
      }

      if (this.activeMenu == "two_forty") {
        switch (event.key) {
          case '4':
            dataPresent = !!this.FullChartResponse['two_forty'];
            if (dataPresent) {
              // this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = true;
              this.ChangeScreenMode('two_forty', 'chart-container_new', true);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
          case 'd':
          case 'D':
            dataPresent = !!this.FullChartResponse['daily'];
            if (dataPresent) {
              this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = false;
              this.ChangeScreenMode('daily', 'chart-container_new', false);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
          case 'w':
          case 'W':
            dataPresent = !!this.FullChartResponse['weekly'];
            if (dataPresent) {
              this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = false;
              this.ChangeScreenMode('weekly', 'chart-container_new', false);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
        }
      }
    }

    if (this.selectedExchange.exchange_name == "NSEFO") {

      if (this.activeMenu == "daily") {
        switch (event.key) {
          case 'm':
          case 'M':
            dataPresent = !!this.FullChartResponse['monthly'];
            if (dataPresent) {
              // this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = false;
              this.ChangeScreenMode('monthly', 'chart-container_new', false);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
          case 'd':
          case 'D':
            dataPresent = !!this.FullChartResponse['daily'];
            if (dataPresent) {
              this.QualifiedZoneFlag = true;
              this.selectedOptions = []
              this.dropdownShow = false;
              this.ChangeScreenMode('daily', 'chart-container_new', true);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
          case 'w':
          case 'W':
            dataPresent = !!this.FullChartResponse['weekly'];
            if (dataPresent) {
              this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = false;
              this.ChangeScreenMode('weekly', 'chart-container_new', false);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
        }
      }

      if (this.activeMenu == "sixty") {
        switch (event.key) {
          case 'w':
          case 'W':
            dataPresent = !!this.FullChartResponse['weekly'];
            if (dataPresent) {
              // this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = false;
              this.ChangeScreenMode('weekly', 'chart-container_new', false);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
          case 'd':
          case 'D':
            dataPresent = !!this.FullChartResponse['daily'];
            if (dataPresent) {
              this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = false;
              this.ChangeScreenMode('daily', 'chart-container_new', false);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
          case '6':
            dataPresent = !!this.FullChartResponse['sixty'];
            if (dataPresent) {
              this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = true;
              this.ChangeScreenMode('sixty', 'chart-container_new', true);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
        }
      }

      if (this.activeMenu == "seventy_five") {
        switch (event.key) {
          case '5':
            dataPresent = !!this.FullChartResponse['seventy_five'];
            if (dataPresent) {
              // this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = true;
              this.ChangeScreenMode('seventy_five', 'chart-container_new', true);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
          case 'd':
          case 'D':
            dataPresent = !!this.FullChartResponse['daily'];
            if (dataPresent) {
              this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = false;
              this.ChangeScreenMode('daily', 'chart-container_new', false);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
          case 'w':
          case 'W':
            dataPresent = !!this.FullChartResponse['weekly'];
            if (dataPresent) {
              this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = false;
              this.ChangeScreenMode('weekly', 'chart-container_new', false);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
        }
      }

      if (this.activeMenu == "fifteen") {
        switch (event.key) {
          case '5':
            dataPresent = !!this.FullChartResponse['fifteen'];
            if (dataPresent) {
              // this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = true;
              this.ChangeScreenMode('fifteen', 'chart-container_new', true);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
          case 'd':
          case 'D':
            dataPresent = !!this.FullChartResponse['daily'];
            if (dataPresent) {
              this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = false;
              this.ChangeScreenMode('daily', 'chart-container_new', false);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
          case '6':
            dataPresent = !!this.FullChartResponse['sixty'];
            if (dataPresent) {
              this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = false;
              this.ChangeScreenMode('sixty', 'chart-container_new', false);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
        }
      }
    }
  }

  ChangeScreenMode(type: any, chartId: any, setupReq: boolean) {
    const prevFullScreen = this.FullScreenModeValue;
    this.disconnectWebSocket()
    const dataPresent: boolean = !!this.FullChartResponse[type];
    if (dataPresent) {
      switch (type) {
        case "monthly":
          this.ModalHeader = type;
          this.FullScreenModeValue = type;
          break;
        case "weekly":
          this.ModalHeader = type;
          this.FullScreenModeValue = type;
          break;
        case "daily":
          this.ModalHeader = type;
          this.FullScreenModeValue = type;
          break;
        case "seventy_five":
          this.ModalHeader = "75 Minute";
          this.FullScreenModeValue = type;
          break;
        case "sixty":
          this.ModalHeader = "60 Minute";
          this.FullScreenModeValue = type;
          break;
        case "fifteen":
          this.ModalHeader = "15 Minute";
          this.FullScreenModeValue = type;
          break;
        case "one_twenty":
          this.ModalHeader = "120 Minute";
          this.FullScreenModeValue = type;
          break;
        case "two_forty":
          this.ModalHeader = "240 Minute";
          this.FullScreenModeValue = type;
          break;
        case "one_twenty_five":
          this.ModalHeader = "125 Minute";
          this.FullScreenModeValue = type;
          break;
        case "twenty_five":
          this.ModalHeader = "25 Minute";
          this.FullScreenModeValue = type;
          break;
      }



      const data = this.FullChartResponse[type];
      this.cleanup();
      this.LoadChart(data, chartId);
      const lastRow = data.slice(-1)[0];
      this.CreateClosingLine(lastRow.close)
      this.addPreviousHighPriceLine(type)
      this.connectWebSocket(type);
      this.handleOverlapMemoryAndOptimized(prevFullScreen)
      this.checkboxClicked(this.selectedOptions)
      if (setupReq) {
        this.getsetup(this.purchased_date, this.entry_timestamp, this.entry_price, this.stoploss_price, this.target_price)
      }
    }
    else {
      this.toastr.error(`No Data found !`)
      return;
    }
  }


  private handleOverlapMemoryAndOptimized(prevFullScreen: string) {
    const exchangeName = this.selectedExchange?.exchange_name;
    if (!exchangeName) return;

    const rulesForExchange = EXCHANGE_MENU_RULES[exchangeName];
    if (!rulesForExchange) return;

    const rule = rulesForExchange[this.activeMenu];
    if (!rule) return;

    // init memory for this menu (and exchange) — optional improvement:
    // if you want memory isolated per exchange, use a composite key:
    const memKey = `${exchangeName}__${this.activeMenu}`;

    if (!this.overlapMemory[memKey]) {
      this.overlapMemory[memKey] = { evaluate: false, analyze: false, qualified: false };
    }

    // 1) If leaving base screen -> remember BOTH selections
    if (prevFullScreen === rule.base) {
      this.overlapMemory[memKey] = {
        evaluate: !!this.selectedOptions["overlap_evaluate"],
        analyze: !!this.selectedOptions["overlap_analyze"],
        qualified: !!this.selectedOptions["qualified_zones"]
      };
    }

    const mem = this.overlapMemory[memKey];

    // 2) If back on base screen -> restore BOTH
    if (this.FullScreenModeValue === rule.base) {
      this.selectedOptions["overlap_evaluate"] = mem.evaluate;
      this.selectedOptions["overlap_analyze"] = mem.analyze;
      this.selectedOptions["qualified_zones"] = mem.qualified;
    } else {
      // outside base, overlap options are not valid -> keep UI OFF, but memory remains saved
      this.selectedOptions["overlap_evaluate"] = false;
      this.selectedOptions["overlap_analyze"] = false;
      this.selectedOptions["qualified_zones"] = false;
    }

    // 3) Compute optimized dynamically (OR logic)
    this.selectedOptions.optimized_buy_sell_zone = false;

    const combinedPatch: any = {};

    if (mem.evaluate) {
      const p1 = rule.overlap_evaluate?.[this.FullScreenModeValue];
      if (p1) Object.assign(combinedPatch, p1);
    }

    if (mem.analyze) {
      const p2 = rule.overlap_analyze?.[this.FullScreenModeValue];
      if (p2) Object.assign(combinedPatch, p2);
    }

    // apply only if something matched
    if (Object.keys(combinedPatch).length > 0) {
      Object.assign(this.selectedOptions, combinedPatch);
    }
  }


  cleanup(): void {
    if (this.chart) {
      this.chart.remove();
    }
  }

  shiftChart(diff: any) {
    const currentPos = this.chart.timeScale().scrollPosition();
    this.chart.timeScale().scrollToPosition(currentPos + diff, false);
  }

  scaleChart(pct: any, zoomIn: any) {
    const currentRange = this.chart.timeScale().getVisibleLogicalRange();
    if (currentRange) {
      const bars = currentRange.to - currentRange.from;
      const direction = zoomIn ? -1 : 1;
      const newRangeBars = bars * pct * direction + bars;
      this.chart.timeScale().setVisibleLogicalRange({
        to: currentRange.to,
        from: currentRange.to - newRangeBars,
      });
    }
  }

  get f() { return this.fincreateformForPanel.controls; }
  get g() { return this.fincreateform.controls; }
  get j() { return this.alertForm.controls; }

  private CreateForm() {
    this.fincreateform = this.formBuilder.group({
      stock_tick: [''],
      order_type: ['', [Validators.required]],
      entry_price: ['', [Validators.required]],
      stoploss_price: ['', [Validators.required]],
      target_price: ['', [Validators.required]],
      stock_quantity: ['', [Validators.required]],
      purchased_cmp_date: [''],
      time_frame: [''],
      stock_id: [""],
      country_id: [''],
      prediction: [''],
      probability: ['']
    });

    this.fincreateformForPanel = this.formBuilder.group({
      stock_tick: [''],
      order_type: ['', [Validators.required]],
      entry_price: ['', [Validators.required]],
      stoploss_price: ['', [Validators.required]],
      target_price: ['', [Validators.required]],
      stock_quantity: ['', [Validators.required]],
      purchased_cmp_date: [''],
      time_frame: [''],
      stock_id: [""],
      country_id: [''],
      prediction: [''],
      probability: ['']
    });
  }

  private buildForm() {
    this.alertForm = this.formBuilder.group({
      user_id: [Number(this.userId)],
      country_id: [Number(this.countryId)],
      stock_symbol: ['', Validators.required],
      exchange: [''],
      alert_type: ['', Validators.required],
      trigger_price: ['', Validators.required],
      price_range_min: ['', Validators.required],
      price_range_max: ['', Validators.required],
      threshold: ['', Validators.required],
      timeframe: [''],
      note: [''],
      target_percentage: [],
      cooldown_minutes: [Number],
      is_active: [true],
      email_notification: [false]
    });
  }

  resetOrderForm() {
    this.fincreateform.reset()
  }

  startResize(event: MouseEvent) {
    const th = (event.target as HTMLElement).parentElement as HTMLElement;
    const startX = event.pageX;
    const startWidth = th.offsetWidth;

    const onMouseMove = (e: MouseEvent) => {
      const newWidth = startWidth + (e.pageX - startX);
      th.style.width = `${newWidth}px`;
    };

    const onMouseUp = () => {
      document.removeEventListener('mousemove', onMouseMove);
      document.removeEventListener('mouseup', onMouseUp);
    };

    document.addEventListener('mousemove', onMouseMove);
    document.addEventListener('mouseup', onMouseUp);
  }

  ngOnInit(): void {
    const width = window.innerWidth;
    if (width <= 767) {
      this.isMobile = true;
    }
    this.selectedDateRange = {
      startDate: moment().startOf('year'),     // January 1st, current year
      endDate: moment().endOf('year')          // December 31st, current year
    }
    this.StartDate = this.selectedDateRange.startDate.format('YYYY-MM-DD');
    this.EndDate = this.selectedDateRange.endDate.format('YYYY-MM-DD');
    this.SelectedCountryId = localStorage.getItem('selectedCountryId');
    this.SelectedCountryName = localStorage.getItem('selectedCountryName');
    this.Role = localStorage.getItem('role');
    if (this.Role == "admin") {
      this.isAdmin = true;
    }
    else {
      this.isAdmin = false;
    }
    this.UserName = localStorage.getItem('UserName');
    this.countryId = localStorage.getItem('selectedCountryId');
    this.userId = localStorage.getItem('UserId');
    this.CreateForm();
    this.buildForm();
    this.exchange();
    this.initializeCandles();
    this.startRandomColorToggle();
    this.stockDataFunc()
    this.FetchDailyTrades(1, null, false, this.StartDate, this.EndDate);
    this.FetchSixtyTrades(1, null, false, this.StartDate, this.EndDate);
    this.FetchFifteenTrades(1, null, false, this.StartDate, this.EndDate);
    this.Fetch75Trades(1, null, false, this.StartDate, this.EndDate);
    this.Fetch240Trades(1, null, false, this.StartDate, this.EndDate);
    this.Fetch120Trades(1, null, false, this.StartDate, this.EndDate);
    this.Fetch125Trades(1, null, false, this.StartDate, this.EndDate);
    this.Fetch25Trades(1, null, false, this.StartDate, this.EndDate);
    this.PrepDebounce();
    // this.selectedExchange = this.exchanges.find((e: { exchange_id: number; }) => e.exchange_id === 2);
    // console.log("Selected Exchanges",this.selectedExchange)
    this.getAllSetAlerts();
  }

  calculateMinMax() {
    const trigger = this.alertForm.get('trigger_price')?.value;
    const threshold = this.alertForm.get('threshold')?.value;

    if (trigger && threshold) {
      const diff = (trigger * threshold) / 100;
      this.alertForm.get('price_range_min')?.setValue(trigger - diff, { emitEvent: false });
      this.alertForm.get('price_range_max')?.setValue(trigger + diff, { emitEvent: false });
    }
  }

  onExchangeChange() {
    if (this.selectedExchange) {
      this.SelectedExchange_Id = this.selectedExchange.exchange_id;
      this.SelectedExchange_Name = this.selectedExchange.exchange_name;
    }
    this.activeMenu = "daily"
    this.FetchDailyTrades(1, null, false, this.StartDate, this.EndDate);
    this.FetchSixtyTrades(1, null, false, this.StartDate, this.EndDate);
    this.FetchFifteenTrades(1, null, false, this.StartDate, this.EndDate);
    this.Fetch75Trades(1, null, false, this.StartDate, this.EndDate);
    this.Fetch240Trades(1, null, false, this.StartDate, this.EndDate);
    this.Fetch120Trades(1, null, false, this.StartDate, this.EndDate);
    this.Fetch125Trades(1, null, false, this.StartDate, this.EndDate);
    this.Fetch25Trades(1, null, false, this.StartDate, this.EndDate);
  }

  onTradeTypeChange() {
    this.FetchDailyTrades(1, null, false, this.StartDate, this.EndDate);
    this.FetchSixtyTrades(1, null, false, this.StartDate, this.EndDate);
    this.FetchFifteenTrades(1, null, false, this.StartDate, this.EndDate);
    this.Fetch75Trades(1, null, false, this.StartDate, this.EndDate);
    this.Fetch240Trades(1, null, false, this.StartDate, this.EndDate);
    this.Fetch120Trades(1, null, false, this.StartDate, this.EndDate);
    this.Fetch125Trades(1, null, false, this.StartDate, this.EndDate);
    this.Fetch25Trades(1, null, false, this.StartDate, this.EndDate);
  }

  PrepDebounce() {
    this.searchSubject.pipe(
      debounceTime(400)
    ).subscribe((value: string) => {
      const trimmed = value.trim().toLowerCase();
      this.typedText = trimmed;

      if (this.activeMenu === 'daily') {
        this.dailyState.searchKey = trimmed;
        this.FetchDailyTrades("", trimmed, true, this.StartDate, this.EndDate);
      } else if (this.activeMenu === 'sixty') {
        this.sixtyState.searchKey = trimmed;
        this.FetchSixtyTrades("", trimmed, true, this.StartDate, this.EndDate);
      } else if (this.activeMenu === 'fifteen') {
        this.fifteenState.searchKey = trimmed;
        this.FetchFifteenTrades("", trimmed, true, this.StartDate, this.EndDate);
      } else if (this.activeMenu === 'one_twenty') {
        this.onetwentyState.searchKey = trimmed;
        this.Fetch120Trades("", trimmed, true, this.StartDate, this.EndDate);
      } else if (this.activeMenu === 'two_forty') {
        this.twofortyState.searchKey = trimmed;
        this.Fetch240Trades("", trimmed, true, this.StartDate, this.EndDate);
      } else if (this.activeMenu === 'one_twenty_five') {
        this.onetwentyfiveState.searchKey = trimmed;
        this.Fetch125Trades("", trimmed, true, this.StartDate, this.EndDate);
      } else if (this.activeMenu === 'seventy_five') {
        this.seventyfiveState.searchKey = trimmed;
        this.Fetch75Trades("", trimmed, true, this.StartDate, this.EndDate);
      } else if (this.activeMenu === 'twenty_five') {
        this.twentyfiveState.searchKey = trimmed;
        this.Fetch25Trades("", trimmed, true, this.StartDate, this.EndDate);
      }
    });
  }

  onSearchInput(value: string) {
    this.searchSubject.next(value);
  }

  onPageSizeChange() {
    if (this.activeMenu === 'daily') {
      this.FetchDailyTrades(1, this.dailyState.searchKey || '', true, this.StartDate, this.EndDate);
    } else if (this.activeMenu === 'sixty') {
      this.FetchSixtyTrades(1, this.sixtyState.searchKey || '', true, this.StartDate, this.EndDate);
    } else if (this.activeMenu === 'fifteen') {
      this.FetchFifteenTrades(1, this.fifteenState.searchKey || '', true, this.StartDate, this.EndDate);
    } else if (this.activeMenu === 'one_twenty_five') {
      this.Fetch125Trades(1, this.onetwentyfiveState.searchKey || '', true, this.StartDate, this.EndDate);
    } else if (this.activeMenu === 'two_forty') {
      this.Fetch240Trades(1, this.twofortyState.searchKey || '', true, this.StartDate, this.EndDate);
    } else if (this.activeMenu === 'one_twenty') {
      this.Fetch120Trades(1, this.onetwentyState.searchKey || '', true, this.StartDate, this.EndDate);
    } else if (this.activeMenu === 'seventy_five') {
      this.Fetch75Trades(1, this.seventyfiveState.searchKey || '', true, this.StartDate, this.EndDate);
    }
    else if (this.activeMenu === 'twenty_five') {
      this.Fetch25Trades(1, this.twentyfiveState.searchKey || '', true, this.StartDate, this.EndDate);
    }
  }

  logout() {
    localStorage.clear();
    this.router.navigate(['landing']);
  }

  alerts() {
    this.router.navigate(['alerts']);
  }

  orderList() {
    this.router.navigate(['orderlist']);
  }

  autoorders() {
    this.router.navigate(['auto-order-list']);
  }

  stock_screener() {
    this.router.navigate(['home']);
  }

  news() {
    this.router.navigate(['news']);
  }

  sysmgmt() {
    this.router.navigate(['system-management']);
  }

  dashboard() {
    this.router.navigate(['dashboard']);
  }

  available_trades() {
    this.router.navigate(['trades']);
  }

  previousHighService() {
    console.log("Previous High Payload", this.finData)
    this.apiService.GetprevioushighDataService(this.finData).subscribe(resp => {
      this.PreviousHighData = resp.response;
      this.addPreviousHighPriceLine(this.FullScreenModeValue);
      console.log(`RESPONSE 7 (PREVIOUS HIGH) :`, this.PreviousHighData);
    })
  }

  switchMenu(menu: string) {
    this.highlightedStockNames = [];
    this.highlightedStockNamesSixty = [];
    this.highlightedStockNamesFifteen = [];
    this.highlightedStockNames240 = [];
    this.highlightedStockNames120 = [];
    this.highlightedStockNames75 = [];
    this.highlightedStockNames125 = [];
    this.highlightedStockNames25 = [];
    this.activeMenu = menu;
    this.searchText = "";
    this.MatchedCount = 0;

    if (menu === 'daily') {
      // this.SelectedTimeFrame = 1;
      this.dailyState.currentPage = 1;
      this.FetchDailyTrades(1, this.dailyState.searchKey, true, this.StartDate, this.EndDate);

    } else if (menu === 'sixty') {
      // this.SelectedTimeFrame = 2;
      this.sixtyState.currentPage = 1;
      this.FetchSixtyTrades(1, this.sixtyState.searchKey, true, this.StartDate, this.EndDate);

    } else if (menu === 'fifteen') {
      // this.SelectedTimeFrame = 3;
      this.fifteenState.currentPage = 1;
      this.FetchFifteenTrades(1, this.fifteenState.searchKey, true, this.StartDate, this.EndDate);

    } else if (menu === 'one_twenty_five') {
      // this.SelectedTimeFrame = 4;
      this.onetwentyfiveState.currentPage = 1;
      this.Fetch125Trades(1, this.onetwentyfiveState.searchKey, true, this.StartDate, this.EndDate);

    } else if (menu === 'two_forty') {
      // this.SelectedTimeFrame = 5;
      this.twofortyState.currentPage = 1;
      this.Fetch240Trades(1, this.twofortyState.searchKey, true, this.StartDate, this.EndDate);

    } else if (menu === 'one_twenty') {
      // this.SelectedTimeFrame = 6;
      this.onetwentyState.currentPage = 1;
      this.Fetch120Trades(1, this.onetwentyState.searchKey, true, this.StartDate, this.EndDate);

    } else if (menu === 'seventy_five') {
      // this.SelectedTimeFrame = 25;
      this.seventyfiveState.currentPage = 1;
      this.Fetch75Trades(1, this.seventyfiveState.searchKey, true, this.StartDate, this.EndDate);
    }
    else if (menu === 'twenty_five') {
      this.twentyfiveState.currentPage = 1;
      this.Fetch25Trades(1, this.twentyfiveState.searchKey, true, this.StartDate, this.EndDate);
    }
  }

  initializeCandles(): void {
    this.candles = Array.from({ length: 10 }, () => ({
      color: 'green',
      height: this.getRandomHeight(),
      wickHeight: this.getRandomWickHeight()
    }));
  }

  getRandomWickHeight(): number {
    return Math.floor(Math.random() * 30) + 10;
  }

  getRandomHeight(): number {
    return Math.floor(Math.random() * 50) + 20;
  }

  startRandomColorToggle(): void {
    this.colorInterval = setInterval(() => {
      this.candles = this.candles.map((candle) => ({
        color: Math.random() > 0.5 ? 'green' : 'red',
        height: this.getRandomHeight(),
        wickHeight: this.getRandomWickHeight()
      }));
    }, 500);
  }

  getKeys(item: any): string[] {
    return Object.keys(item).filter(key => key === 'BUY' || key === 'SELL');
  }

  Search() {
    this.StartDate = this.selectedDateRange.startDate.format('YYYY-MM-DD');
    this.EndDate = this.selectedDateRange.endDate.format('YYYY-MM-DD');
    this.FetchDailyTrades(1, this.searchText, false, this.StartDate, this.EndDate)
    this.FetchSixtyTrades(1, this.searchText, false, this.StartDate, this.EndDate);
    this.FetchFifteenTrades(1, this.searchText, false, this.StartDate, this.EndDate);
    this.Fetch240Trades(1, this.searchText, false, this.StartDate, this.EndDate)
    this.Fetch125Trades(1, this.searchText, false, this.StartDate, this.EndDate);
    this.Fetch120Trades(1, this.searchText, false, this.StartDate, this.EndDate);
    this.Fetch75Trades(1, this.searchText, false, this.StartDate, this.EndDate);
    this.Fetch25Trades(1, this.searchText, false, this.StartDate, this.EndDate);

  }

  // FetchDailyTrades(page: any, searchKey: any, highlight: boolean = false, start: any, end: any) {
  //   this.spinner.show();
  //   this.apiService.getDailyTrades(page, searchKey, this.pageSize, start, end, Number(this.SelectedExchange_Id), this.isChecked, this.isCheckedForCMP, this.selectTradeType).subscribe(resp => {
  //     if (resp.msg === 'success') {
  //       this.DailyTrades = resp.response.trades;
  //       console.log(" this.DailyTrades", this.DailyTrades)
  //       this.dailyState.trades = resp.response.trades;
  //       this.dailyState.totalCount = resp.response.total_count;
  //       this.dailyState.currentPage = resp.response.page_no;
  //       this.spinner.hide();
  //       if (this.DailyTrades.length <= 0) {

  //       }
  //       if (highlight && searchKey) {
  //         const lowerSearch = searchKey.trim().toLowerCase();

  //         const startsWithMatches = resp.response.trades.filter((item: { STOCK_SYMBOL: string }) =>
  //           item.STOCK_SYMBOL?.toLowerCase().startsWith(lowerSearch)
  //         );

  //         const containsMatches = resp.response.trades.filter((item: { STOCK_SYMBOL: string }) =>
  //           item.STOCK_SYMBOL?.toLowerCase().includes(lowerSearch)
  //         );

  //         const matches = startsWithMatches.length > 0 ? startsWithMatches : containsMatches;

  //         this.MatchedCount = matches.length;
  //         this.highlightedStockNames = matches.map((item: { STOCK_SYMBOL: any }) => item.STOCK_SYMBOL);

  //         if (matches.length > 0) {
  //           const firstMatchName = matches[0].STOCK_SYMBOL;

  //           setTimeout(() => {
  //             const target = this.stockCells?.find(row =>
  //               row.nativeElement
  //                 .getAttribute('data-stock')
  //                 ?.toLowerCase() === firstMatchName.toLowerCase()
  //             );

  //             if (target) {
  //               target.nativeElement.scrollIntoView({
  //                 behavior: 'smooth',
  //                 block: 'center'
  //               });
  //             }
  //           });
  //         } else {
  //           this.highlightedStockNames = [];
  //         }
  //       } else {
  //         this.highlightedStockNames = [];
  //         this.MatchedCount = 0;
  //       }
  //     } else {
  //       this.spinner.hide();
  //       this.dailyState.trades = [];
  //       this.dailyState.totalCount = 0;
  //       this.highlightedStockNames = [];
  //       this.MatchedCount = 0;
  //     }

  //     this.cdr.detectChanges();
  //   });
  // }

  FetchDailyTrades(page: any, searchKey: any, highlight: boolean = false, start: any, end: any) {
    this.spinner.show();

    this.apiService.getDailyTrades(
      page,
      searchKey,
      this.pageSize,
      start,
      end,
      Number(this.SelectedExchange_Id),
      this.isChecked,
      this.isCheckedForCMP,
      this.selectTradeType
    ).subscribe(resp => {
      if (resp.msg === 'success') {
        const backendTrades = [...resp.response.trades];

        // keep backend date-wise order if no UI sort selected
        const finalTrades = this.sortColumn
          ? this.applySorting(backendTrades)
          : backendTrades;

        this.DailyTrades = finalTrades;
        this.dailyState.trades = finalTrades;
        this.dailyState.totalCount = resp.response.total_count;
        this.dailyState.currentPage = resp.response.page_no;

        console.log("this.DailyTrades", this.DailyTrades);

        this.spinner.hide();

        if (highlight && searchKey) {
          const lowerSearch = searchKey.trim().toLowerCase();

          const startsWithMatches = finalTrades.filter((item: { STOCK_SYMBOL: string }) =>
            item.STOCK_SYMBOL?.toLowerCase().startsWith(lowerSearch)
          );

          const containsMatches = finalTrades.filter((item: { STOCK_SYMBOL: string }) =>
            item.STOCK_SYMBOL?.toLowerCase().includes(lowerSearch)
          );

          const matches = startsWithMatches.length > 0 ? startsWithMatches : containsMatches;

          this.MatchedCount = matches.length;
          this.highlightedStockNames = matches.map((item: { STOCK_SYMBOL: any }) => item.STOCK_SYMBOL);

          if (matches.length > 0) {
            const firstMatchName = matches[0].STOCK_SYMBOL;

            setTimeout(() => {
              const target = this.stockCells?.find(row =>
                row.nativeElement
                  .getAttribute('data-stock')
                  ?.toLowerCase() === firstMatchName.toLowerCase()
              );

              if (target) {
                target.nativeElement.scrollIntoView({
                  behavior: 'smooth',
                  block: 'center'
                });
              }
            });
          } else {
            this.highlightedStockNames = [];
          }
        } else {
          this.highlightedStockNames = [];
          this.MatchedCount = 0;
        }
      } else {
        this.spinner.hide();
        this.DailyTrades = [];
        this.dailyState.trades = [];
        this.dailyState.totalCount = 0;
        this.highlightedStockNames = [];
        this.MatchedCount = 0;
      }

      this.cdr.detectChanges();
    });
  }

  // FetchSixtyTrades(page: any, searchKey: any, highlight: boolean = false, start: any, end: any) {
  //   this.spinner.show();
  //   this.apiService.getSixtyTrades(page, searchKey, this.pageSize, start, end, Number(this.SelectedExchange_Id), this.isChecked, this.isCheckedForCMP, this.selectTradeType).subscribe(resp => {
  //     if (resp.msg === 'success') {
  //       this.spinner.hide();
  //       this.SixtyTrades = resp.response.trades;
  //       console.log("Sixty Trades", this.SixtyTrades)
  //       this.sixtyState.trades = resp.response.trades;
  //       this.sixtyState.totalCount = resp.response.total_count;
  //       this.sixtyState.currentPage = resp.response.page_no;

  //       if (highlight && searchKey) {
  //         const lowerSearch = searchKey.trim().toLowerCase();

  //         const matches = resp.response.trades.filter((item: { STOCK_SYMBOL: string }) =>
  //           item.STOCK_SYMBOL?.toLowerCase().includes(lowerSearch)
  //         );
  //         this.MatchedCount = matches.length;
  //         this.highlightedStockNamesSixty = matches.map((item: { STOCK_SYMBOL: any; }) => item.STOCK_SYMBOL);

  //         if (matches.length > 0) {
  //           const firstMatch = matches[0].STOCK_SYMBOL;

  //           setTimeout(() => {
  //             const target = this.stockCells.find(cell =>
  //               cell.nativeElement
  //                 .getAttribute('data-stock')
  //                 ?.toLowerCase() === firstMatch.toLowerCase()
  //             );

  //             if (target) {
  //               target.nativeElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
  //             }
  //           });
  //         } else {
  //           this.highlightedStockNamesSixty = [];
  //         }
  //       } else {
  //         this.highlightedStockNamesSixty = [];
  //         this.MatchedCount = 0;
  //       }
  //     } else {
  //       this.spinner.hide();
  //       this.sixtyState.trades = [];
  //       this.sixtyState.totalCount = 0;
  //       this.highlightedStockNamesSixty = [];
  //       this.MatchedCount = 0;
  //     }

  //     this.cdr.detectChanges();
  //   });
  // }

  FetchSixtyTrades(page: any, searchKey: any, highlight: boolean = false, start: any, end: any) {
    this.spinner.show();

    this.apiService.getSixtyTrades(
      page,
      searchKey,
      this.pageSize,
      start,
      end,
      Number(this.SelectedExchange_Id),
      this.isChecked,
      this.isCheckedForCMP,
      this.selectTradeType
    ).subscribe(resp => {
      if (resp.msg === 'success') {
        this.spinner.hide();

        const backendTrades = [...resp.response.trades];

        const finalTrades = this.sortColumn
          ? this.applySorting(backendTrades)
          : backendTrades;

        this.SixtyTrades = finalTrades;
        this.sixtyState.trades = finalTrades;
        this.sixtyState.totalCount = resp.response.total_count;
        this.sixtyState.currentPage = resp.response.page_no;

        console.log("Sixty Trades", this.SixtyTrades);

        if (highlight && searchKey) {
          const lowerSearch = searchKey.trim().toLowerCase();

          const startsWithMatches = finalTrades.filter((item: { STOCK_SYMBOL: string }) =>
            item.STOCK_SYMBOL?.toLowerCase().startsWith(lowerSearch)
          );

          const containsMatches = finalTrades.filter((item: { STOCK_SYMBOL: string }) =>
            item.STOCK_SYMBOL?.toLowerCase().includes(lowerSearch)
          );

          const matches = startsWithMatches.length > 0 ? startsWithMatches : containsMatches;

          this.MatchedCount = matches.length;
          this.highlightedStockNamesSixty = matches.map((item: { STOCK_SYMBOL: any }) => item.STOCK_SYMBOL);

          if (matches.length > 0) {
            const firstMatch = matches[0].STOCK_SYMBOL;

            setTimeout(() => {
              const target = this.stockCells.find(cell =>
                cell.nativeElement
                  .getAttribute('data-stock')
                  ?.toLowerCase() === firstMatch.toLowerCase()
              );

              if (target) {
                target.nativeElement.scrollIntoView({
                  behavior: 'smooth',
                  block: 'center'
                });
              }
            });
          } else {
            this.highlightedStockNamesSixty = [];
          }
        } else {
          this.highlightedStockNamesSixty = [];
          this.MatchedCount = 0;
        }
      } else {
        this.spinner.hide();
        this.SixtyTrades = [];
        this.sixtyState.trades = [];
        this.sixtyState.totalCount = 0;
        this.highlightedStockNamesSixty = [];
        this.MatchedCount = 0;
      }

      this.cdr.detectChanges();
    });
  }

  // FetchFifteenTrades(page: any, searchKey: any, highlight: boolean = false, start: any, end: any) {
  //   this.spinner.show();
  //   this.apiService.getFifteenTrades(page, searchKey, this.pageSize, start, end, Number(this.SelectedExchange_Id), this.isChecked, this.isCheckedForCMP, this.selectTradeType).subscribe(resp => {
  //     if (resp.msg === 'success') {
  //       this.spinner.hide();
  //       this.FifteenTrades = resp.response.trades;
  //       this.fifteenState.trades = resp.response.trades;
  //       this.fifteenState.totalCount = resp.response.total_count;
  //       this.fifteenState.currentPage = resp.response.page_no;

  //       if (highlight && searchKey) {
  //         const lowerSearch = searchKey.trim().toLowerCase();

  //         const matches = resp.response.trades.filter((item: { STOCK_SYMBOL: string }) =>
  //           item.STOCK_SYMBOL?.toLowerCase().includes(lowerSearch)
  //         );
  //         this.MatchedCount = matches.length;

  //         this.highlightedStockNamesFifteen = matches.map((item: { STOCK_SYMBOL: any; }) => item.STOCK_SYMBOL);

  //         if (matches.length > 0) {
  //           const firstMatch = matches[0].STOCK_NAME;

  //           setTimeout(() => {
  //             const target = this.stockCells.find(cell =>
  //               cell.nativeElement
  //                 .getAttribute('data-stock')
  //                 ?.toLowerCase() === firstMatch.toLowerCase()
  //             );

  //             if (target) {
  //               target.nativeElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
  //             }
  //           });
  //         } else {
  //           this.highlightedStockNamesFifteen = [];
  //         }
  //       } else {
  //         this.highlightedStockNamesFifteen = [];
  //         this.MatchedCount = 0;
  //       }
  //     } else {
  //       this.spinner.hide();
  //       this.fifteenState.trades = [];
  //       this.fifteenState.totalCount = 0;
  //       this.highlightedStockNamesFifteen = [];
  //       this.MatchedCount = 0;
  //     }

  //     this.cdr.detectChanges();
  //   });
  // }

  FetchFifteenTrades(page: any, searchKey: any, highlight: boolean = false, start: any, end: any) {
    this.spinner.show();

    this.apiService.getFifteenTrades(
      page,
      searchKey,
      this.pageSize,
      start,
      end,
      Number(this.SelectedExchange_Id),
      this.isChecked,
      this.isCheckedForCMP,
      this.selectTradeType
    ).subscribe(resp => {
      if (resp.msg === 'success') {
        this.spinner.hide();

        const backendTrades = [...resp.response.trades];

        const finalTrades = this.sortColumn
          ? this.applySorting(backendTrades)
          : backendTrades;

        this.FifteenTrades = finalTrades;
        this.fifteenState.trades = finalTrades;
        this.fifteenState.totalCount = resp.response.total_count;
        this.fifteenState.currentPage = resp.response.page_no;

        if (highlight && searchKey) {
          const lowerSearch = searchKey.trim().toLowerCase();

          const startsWithMatches = finalTrades.filter((item: { STOCK_SYMBOL: string }) =>
            item.STOCK_SYMBOL?.toLowerCase().startsWith(lowerSearch)
          );

          const containsMatches = finalTrades.filter((item: { STOCK_SYMBOL: string }) =>
            item.STOCK_SYMBOL?.toLowerCase().includes(lowerSearch)
          );

          const matches = startsWithMatches.length > 0 ? startsWithMatches : containsMatches;

          this.MatchedCount = matches.length;
          this.highlightedStockNamesFifteen = matches.map((item: { STOCK_SYMBOL: any }) => item.STOCK_SYMBOL);

          if (matches.length > 0) {
            const firstMatch = matches[0].STOCK_SYMBOL;

            setTimeout(() => {
              const target = this.stockCells.find(cell =>
                cell.nativeElement
                  .getAttribute('data-stock')
                  ?.toLowerCase() === firstMatch.toLowerCase()
              );

              if (target) {
                target.nativeElement.scrollIntoView({
                  behavior: 'smooth',
                  block: 'center'
                });
              }
            });
          } else {
            this.highlightedStockNamesFifteen = [];
          }
        } else {
          this.highlightedStockNamesFifteen = [];
          this.MatchedCount = 0;
        }
      } else {
        this.spinner.hide();
        this.FifteenTrades = [];
        this.fifteenState.trades = [];
        this.fifteenState.totalCount = 0;
        this.highlightedStockNamesFifteen = [];
        this.MatchedCount = 0;
      }

      this.cdr.detectChanges();
    });
  }

  // Fetch240Trades(page: any, searchKey: any, highlight: boolean = false, start: any, end: any) {
  //   this.spinner.show();
  //   this.apiService.get240Trades(page, searchKey, this.pageSize, start, end, Number(this.SelectedExchange_Id), this.isChecked, this.isCheckedForCMP, this.selectTradeType).subscribe(resp => {
  //     if (resp.msg === 'success') {
  //       this.TwoFortyTrades = resp.response.trades;
  //       this.twofortyState.trades = resp.response.trades;
  //       this.twofortyState.totalCount = resp.response.total_count;
  //       this.twofortyState.currentPage = resp.response.page_no;
  //       this.spinner.hide();
  //       if (this.TwoFortyTrades.length <= 0) {

  //       }
  //       if (highlight && searchKey) {
  //         const lowerSearch = searchKey.trim().toLowerCase();

  //         const matches = resp.response.trades.filter((item: { STOCK_SYMBOL: string }) =>
  //           item.STOCK_SYMBOL?.toLowerCase().includes(lowerSearch)
  //         );

  //         this.MatchedCount = matches.length;
  //         this.highlightedStockNames240 = matches.map((item: { STOCK_SYMBOL: any; }) => item.STOCK_SYMBOL);

  //         if (matches.length > 0) {
  //           const firstMatchName = matches[0].STOCK_SYMBOL;

  //           setTimeout(() => {
  //             const target = this.stockCells.find(cell =>
  //               cell.nativeElement
  //                 .getAttribute('data-stock')
  //                 ?.toLowerCase() === firstMatchName.toLowerCase()
  //             );

  //             if (target) {
  //               target.nativeElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
  //             }
  //           });
  //         } else {
  //           this.highlightedStockNames240 = [];
  //         }
  //       } else {
  //         this.highlightedStockNames240 = [];
  //         this.MatchedCount = 0;
  //       }
  //     } else {
  //       this.spinner.hide();
  //       this.twofortyState.trades = [];
  //       this.twofortyState.totalCount = 0;
  //       this.highlightedStockNames240 = [];
  //       this.MatchedCount = 0;
  //     }

  //     this.cdr.detectChanges();
  //   });
  // }

  Fetch240Trades(page: any, searchKey: any, highlight: boolean = false, start: any, end: any) {
    this.spinner.show();

    this.apiService.get240Trades(
      page,
      searchKey,
      this.pageSize,
      start,
      end,
      Number(this.SelectedExchange_Id),
      this.isChecked,
      this.isCheckedForCMP,
      this.selectTradeType
    ).subscribe(resp => {
      if (resp.msg === 'success') {
        const backendTrades = [...resp.response.trades];

        const finalTrades = this.sortColumn
          ? this.applySorting(backendTrades)
          : backendTrades;

        this.TwoFortyTrades = finalTrades;
        this.twofortyState.trades = finalTrades;
        this.twofortyState.totalCount = resp.response.total_count;
        this.twofortyState.currentPage = resp.response.page_no;

        this.spinner.hide();

        if (highlight && searchKey) {
          const lowerSearch = searchKey.trim().toLowerCase();

          const startsWithMatches = finalTrades.filter((item: { STOCK_SYMBOL: string }) =>
            item.STOCK_SYMBOL?.toLowerCase().startsWith(lowerSearch)
          );

          const containsMatches = finalTrades.filter((item: { STOCK_SYMBOL: string }) =>
            item.STOCK_SYMBOL?.toLowerCase().includes(lowerSearch)
          );

          const matches = startsWithMatches.length > 0 ? startsWithMatches : containsMatches;

          this.MatchedCount = matches.length;
          this.highlightedStockNames240 = matches.map((item: { STOCK_SYMBOL: any }) => item.STOCK_SYMBOL);

          if (matches.length > 0) {
            const firstMatchName = matches[0].STOCK_SYMBOL;

            setTimeout(() => {
              const target = this.stockCells.find(cell =>
                cell.nativeElement
                  .getAttribute('data-stock')
                  ?.toLowerCase() === firstMatchName.toLowerCase()
              );

              if (target) {
                target.nativeElement.scrollIntoView({
                  behavior: 'smooth',
                  block: 'center'
                });
              }
            });
          } else {
            this.highlightedStockNames240 = [];
          }
        } else {
          this.highlightedStockNames240 = [];
          this.MatchedCount = 0;
        }
      } else {
        this.spinner.hide();
        this.TwoFortyTrades = [];
        this.twofortyState.trades = [];
        this.twofortyState.totalCount = 0;
        this.highlightedStockNames240 = [];
        this.MatchedCount = 0;
      }

      this.cdr.detectChanges();
    });
  }

  // Fetch120Trades(page: any, searchKey: any, highlight: boolean = false, start: any, end: any) {
  //   this.spinner.show();
  //   this.apiService.get120Trades(page, searchKey, this.pageSize, start, end, Number(this.SelectedExchange_Id), this.isChecked, this.isCheckedForCMP, this.selectTradeType).subscribe(resp => {
  //     if (resp.msg === 'success') {
  //       this.OneTwentyTrades = resp.response.trades;
  //       this.onetwentyState.trades = resp.response.trades;
  //       this.onetwentyState.totalCount = resp.response.total_count;
  //       this.onetwentyState.currentPage = resp.response.page_no;
  //       this.spinner.hide();
  //       if (this.OneTwentyTrades.length <= 0) {

  //       }
  //       if (highlight && searchKey) {
  //         const lowerSearch = searchKey.trim().toLowerCase();

  //         const matches = resp.response.trades.filter((item: { STOCK_SYMBOL: string }) =>
  //           item.STOCK_SYMBOL?.toLowerCase().includes(lowerSearch)
  //         );

  //         this.MatchedCount = matches.length;
  //         this.highlightedStockNames120 = matches.map((item: { STOCK_SYMBOL: any; }) => item.STOCK_SYMBOL);

  //         if (matches.length > 0) {
  //           const firstMatchName = matches[0].STOCK_SYMBOL;

  //           setTimeout(() => {
  //             const target = this.stockCells.find(cell =>
  //               cell.nativeElement
  //                 .getAttribute('data-stock')
  //                 ?.toLowerCase() === firstMatchName.toLowerCase()
  //             );

  //             if (target) {
  //               target.nativeElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
  //             }
  //           });
  //         } else {
  //           this.highlightedStockNames120 = [];
  //         }
  //       } else {
  //         this.highlightedStockNames120 = [];
  //         this.MatchedCount = 0;
  //       }
  //     } else {
  //       this.spinner.hide();
  //       this.OneTwentyTrades.trades = [];
  //       this.OneTwentyTrades.totalCount = 0;
  //       this.highlightedStockNames120 = [];
  //       this.MatchedCount = 0;
  //     }

  //     this.cdr.detectChanges();
  //   });
  // }

  Fetch120Trades(page: any, searchKey: any, highlight: boolean = false, start: any, end: any) {
    this.spinner.show();

    this.apiService.get120Trades(
      page,
      searchKey,
      this.pageSize,
      start,
      end,
      Number(this.SelectedExchange_Id),
      this.isChecked,
      this.isCheckedForCMP,
      this.selectTradeType
    ).subscribe(resp => {
      if (resp.msg === 'success') {
        const backendTrades = [...resp.response.trades];

        const finalTrades = this.sortColumn
          ? this.applySorting(backendTrades)
          : backendTrades;

        this.OneTwentyTrades = finalTrades;
        this.onetwentyState.trades = finalTrades;
        this.onetwentyState.totalCount = resp.response.total_count;
        this.onetwentyState.currentPage = resp.response.page_no;

        this.spinner.hide();

        if (highlight && searchKey) {
          const lowerSearch = searchKey.trim().toLowerCase();

          const startsWithMatches = finalTrades.filter((item: { STOCK_SYMBOL: string }) =>
            item.STOCK_SYMBOL?.toLowerCase().startsWith(lowerSearch)
          );

          const containsMatches = finalTrades.filter((item: { STOCK_SYMBOL: string }) =>
            item.STOCK_SYMBOL?.toLowerCase().includes(lowerSearch)
          );

          const matches = startsWithMatches.length > 0 ? startsWithMatches : containsMatches;

          this.MatchedCount = matches.length;
          this.highlightedStockNames120 = matches.map((item: { STOCK_SYMBOL: any }) => item.STOCK_SYMBOL);

          if (matches.length > 0) {
            const firstMatchName = matches[0].STOCK_SYMBOL;

            setTimeout(() => {
              const target = this.stockCells.find(cell =>
                cell.nativeElement
                  .getAttribute('data-stock')
                  ?.toLowerCase() === firstMatchName.toLowerCase()
              );

              if (target) {
                target.nativeElement.scrollIntoView({
                  behavior: 'smooth',
                  block: 'center'
                });
              }
            });
          } else {
            this.highlightedStockNames120 = [];
          }
        } else {
          this.highlightedStockNames120 = [];
          this.MatchedCount = 0;
        }
      } else {
        this.spinner.hide();
        this.OneTwentyTrades = [];
        this.onetwentyState.trades = [];
        this.onetwentyState.totalCount = 0;
        this.highlightedStockNames120 = [];
        this.MatchedCount = 0;
      }

      this.cdr.detectChanges();
    });
  }

  // Fetch75Trades(page: any, searchKey: any, highlight: boolean = false, start: any, end: any) {
  //   this.spinner.show();
  //   this.apiService.get75Trades(page, searchKey, this.pageSize, start, end, Number(this.SelectedExchange_Id), this.isChecked, this.isCheckedForCMP, this.selectTradeType).subscribe(resp => {
  //     if (resp.msg === 'success') {
  //       this.SeventyFiveTrades = resp.response.trades;
  //       this.seventyfiveState.trades = resp.response.trades;
  //       this.seventyfiveState.totalCount = resp.response.total_count;
  //       this.seventyfiveState.currentPage = resp.response.page_no;
  //       this.spinner.hide();
  //       if (this.SeventyFiveTrades.length <= 0) {

  //       }
  //       if (highlight && searchKey) {
  //         const lowerSearch = searchKey.trim().toLowerCase();

  //         const matches = resp.response.trades.filter((item: { STOCK_SYMBOL: string }) =>
  //           item.STOCK_SYMBOL?.toLowerCase().includes(lowerSearch)
  //         );

  //         this.MatchedCount = matches.length;
  //         this.highlightedStockNames75 = matches.map((item: { STOCK_SYMBOL: any; }) => item.STOCK_SYMBOL);

  //         if (matches.length > 0) {
  //           const firstMatchName = matches[0].STOCK_SYMBOL;

  //           setTimeout(() => {
  //             const target = this.stockCells.find(cell =>
  //               cell.nativeElement
  //                 .getAttribute('data-stock')
  //                 ?.toLowerCase() === firstMatchName.toLowerCase()
  //             );

  //             if (target) {
  //               target.nativeElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
  //             }
  //           });
  //         } else {
  //           this.highlightedStockNames75 = [];
  //         }
  //       } else {
  //         this.highlightedStockNames75 = [];
  //         this.MatchedCount = 0;
  //       }
  //     } else {
  //       this.spinner.hide();
  //       this.SeventyFiveTrades.trades = [];
  //       this.seventyfiveState.totalCount = 0;
  //       this.highlightedStockNames75 = [];
  //       this.MatchedCount = 0;
  //     }

  //     this.cdr.detectChanges();
  //   });
  // }

  Fetch75Trades(page: any, searchKey: any, highlight: boolean = false, start: any, end: any) {
    this.spinner.show();

    this.apiService.get75Trades(
      page,
      searchKey,
      this.pageSize,
      start,
      end,
      Number(this.SelectedExchange_Id),
      this.isChecked,
      this.isCheckedForCMP,
      this.selectTradeType
    ).subscribe(resp => {
      if (resp.msg === 'success') {
        const backendTrades = [...resp.response.trades];

        const finalTrades = this.sortColumn
          ? this.applySorting(backendTrades)
          : backendTrades;

        this.SeventyFiveTrades = finalTrades;
        this.seventyfiveState.trades = finalTrades;
        this.seventyfiveState.totalCount = resp.response.total_count;
        this.seventyfiveState.currentPage = resp.response.page_no;

        this.spinner.hide();

        if (highlight && searchKey) {
          const lowerSearch = searchKey.trim().toLowerCase();

          const startsWithMatches = finalTrades.filter((item: { STOCK_SYMBOL: string }) =>
            item.STOCK_SYMBOL?.toLowerCase().startsWith(lowerSearch)
          );

          const containsMatches = finalTrades.filter((item: { STOCK_SYMBOL: string }) =>
            item.STOCK_SYMBOL?.toLowerCase().includes(lowerSearch)
          );

          const matches = startsWithMatches.length > 0 ? startsWithMatches : containsMatches;

          this.MatchedCount = matches.length;
          this.highlightedStockNames75 = matches.map((item: { STOCK_SYMBOL: any }) => item.STOCK_SYMBOL);

          if (matches.length > 0) {
            const firstMatchName = matches[0].STOCK_SYMBOL;

            setTimeout(() => {
              const target = this.stockCells.find(cell =>
                cell.nativeElement
                  .getAttribute('data-stock')
                  ?.toLowerCase() === firstMatchName.toLowerCase()
              );

              if (target) {
                target.nativeElement.scrollIntoView({
                  behavior: 'smooth',
                  block: 'center'
                });
              }
            });
          } else {
            this.highlightedStockNames75 = [];
          }
        } else {
          this.highlightedStockNames75 = [];
          this.MatchedCount = 0;
        }
      } else {
        this.spinner.hide();
        this.SeventyFiveTrades = [];
        this.seventyfiveState.trades = [];
        this.seventyfiveState.totalCount = 0;
        this.highlightedStockNames75 = [];
        this.MatchedCount = 0;
      }

      this.cdr.detectChanges();
    });
  }

  // Fetch125Trades(page: any, searchKey: any, highlight: boolean = false, start: any, end: any) {
  //   this.spinner.show();
  //   this.apiService.get125Trades(page, searchKey, this.pageSize, start, end, Number(this.SelectedExchange_Id), this.isChecked, this.isCheckedForCMP, this.selectTradeType).subscribe(resp => {
  //     if (resp.msg === 'success') {
  //       this.OneTwentyFiveTrades = resp.response.trades;
  //       this.onetwentyfiveState.trades = resp.response.trades;
  //       this.onetwentyfiveState.totalCount = resp.response.total_count;
  //       this.onetwentyfiveState.currentPage = resp.response.page_no;
  //       this.spinner.hide();
  //       if (this.OneTwentyFiveTrades.length <= 0) {

  //       }
  //       if (highlight && searchKey) {
  //         const lowerSearch = searchKey.trim().toLowerCase();

  //         const matches = resp.response.trades.filter((item: { STOCK_SYMBOL: string }) =>
  //           item.STOCK_SYMBOL?.toLowerCase().includes(lowerSearch)
  //         );

  //         this.MatchedCount = matches.length;
  //         this.highlightedStockNames125 = matches.map((item: { STOCK_SYMBOL: any; }) => item.STOCK_SYMBOL);

  //         if (matches.length > 0) {
  //           const firstMatchName = matches[0].STOCK_SYMBOL;

  //           setTimeout(() => {
  //             const target = this.stockCells.find(cell =>
  //               cell.nativeElement
  //                 .getAttribute('data-stock')
  //                 ?.toLowerCase() === firstMatchName.toLowerCase()
  //             );

  //             if (target) {
  //               target.nativeElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
  //             }
  //           });
  //         } else {
  //           this.highlightedStockNames125 = [];
  //         }
  //       } else {
  //         this.highlightedStockNames125 = [];
  //         this.MatchedCount = 0;
  //       }
  //     } else {
  //       this.spinner.hide();
  //       this.OneTwentyFiveTrades.trades = [];
  //       this.onetwentyfiveState.totalCount = 0;
  //       this.highlightedStockNames125 = [];
  //       this.MatchedCount = 0;
  //     }

  //     this.cdr.detectChanges();
  //   });
  // }

  Fetch125Trades(page: any, searchKey: any, highlight: boolean = false, start: any, end: any) {
    this.spinner.show();

    this.apiService.get125Trades(
      page,
      searchKey,
      this.pageSize,
      start,
      end,
      Number(this.SelectedExchange_Id),
      this.isChecked,
      this.isCheckedForCMP,
      this.selectTradeType
    ).subscribe(resp => {
      if (resp.msg === 'success') {
        const backendTrades = [...resp.response.trades];

        const finalTrades = this.sortColumn
          ? this.applySorting(backendTrades)
          : backendTrades;

        this.OneTwentyFiveTrades = finalTrades;
        this.onetwentyfiveState.trades = finalTrades;
        this.onetwentyfiveState.totalCount = resp.response.total_count;
        this.onetwentyfiveState.currentPage = resp.response.page_no;

        this.spinner.hide();

        if (highlight && searchKey) {
          const lowerSearch = searchKey.trim().toLowerCase();

          const startsWithMatches = finalTrades.filter((item: { STOCK_SYMBOL: string }) =>
            item.STOCK_SYMBOL?.toLowerCase().startsWith(lowerSearch)
          );

          const containsMatches = finalTrades.filter((item: { STOCK_SYMBOL: string }) =>
            item.STOCK_SYMBOL?.toLowerCase().includes(lowerSearch)
          );

          const matches = startsWithMatches.length > 0 ? startsWithMatches : containsMatches;

          this.MatchedCount = matches.length;
          this.highlightedStockNames125 = matches.map((item: { STOCK_SYMBOL: any }) => item.STOCK_SYMBOL);

          if (matches.length > 0) {
            const firstMatchName = matches[0].STOCK_SYMBOL;

            setTimeout(() => {
              const target = this.stockCells.find(cell =>
                cell.nativeElement
                  .getAttribute('data-stock')
                  ?.toLowerCase() === firstMatchName.toLowerCase()
              );

              if (target) {
                target.nativeElement.scrollIntoView({
                  behavior: 'smooth',
                  block: 'center'
                });
              }
            });
          } else {
            this.highlightedStockNames125 = [];
          }
        } else {
          this.highlightedStockNames125 = [];
          this.MatchedCount = 0;
        }
      } else {
        this.spinner.hide();
        this.OneTwentyFiveTrades = [];
        this.onetwentyfiveState.trades = [];
        this.onetwentyfiveState.totalCount = 0;
        this.highlightedStockNames125 = [];
        this.MatchedCount = 0;
      }

      this.cdr.detectChanges();
    });
  }

  // Fetch25Trades(page: any, searchKey: any, highlight: boolean = false, start: any, end: any) {
  //   this.spinner.show();
  //   this.apiService.get25Trades(page, searchKey, this.pageSize, start, end, Number(this.SelectedExchange_Id), this.isChecked, this.isCheckedForCMP, this.selectTradeType).subscribe(resp => {
  //     if (resp.msg === 'success') {
  //       this.TwentyFiveTrades = resp.response.trades;
  //       this.twentyfiveState.trades = resp.response.trades;
  //       this.twentyfiveState.totalCount = resp.response.total_count;
  //       this.twentyfiveState.currentPage = resp.response.page_no;
  //       this.spinner.hide();
  //       if (this.TwentyFiveTrades.length <= 0) {

  //       }
  //       if (highlight && searchKey) {
  //         const lowerSearch = searchKey.trim().toLowerCase();

  //         const matches = resp.response.trades.filter((item: { STOCK_SYMBOL: string }) =>
  //           item.STOCK_SYMBOL?.toLowerCase().includes(lowerSearch)
  //         );

  //         this.MatchedCount = matches.length;
  //         this.highlightedStockNames25 = matches.map((item: { STOCK_SYMBOL: any; }) => item.STOCK_SYMBOL);

  //         if (matches.length > 0) {
  //           const firstMatchName = matches[0].STOCK_SYMBOL;

  //           setTimeout(() => {
  //             const target = this.stockCells.find(cell =>
  //               cell.nativeElement
  //                 .getAttribute('data-stock')
  //                 ?.toLowerCase() === firstMatchName.toLowerCase()
  //             );

  //             if (target) {
  //               target.nativeElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
  //             }
  //           });
  //         } else {
  //           this.highlightedStockNames25 = [];
  //         }
  //       } else {
  //         this.highlightedStockNames25 = [];
  //         this.MatchedCount = 0;
  //       }
  //     } else {
  //       this.spinner.hide();
  //       this.TwentyFiveTrades.trades = [];
  //       this.twentyfiveState.totalCount = 0;
  //       this.highlightedStockNames25 = [];
  //       this.MatchedCount = 0;
  //     }

  //     this.cdr.detectChanges();
  //   });
  // }

  Fetch25Trades(page: any, searchKey: any, highlight: boolean = false, start: any, end: any) {
    this.spinner.show();

    this.apiService.get25Trades(
      page,
      searchKey,
      this.pageSize,
      start,
      end,
      Number(this.SelectedExchange_Id),
      this.isChecked,
      this.isCheckedForCMP,
      this.selectTradeType
    ).subscribe(resp => {
      if (resp.msg === 'success') {
        const backendTrades = [...resp.response.trades];

        const finalTrades = this.sortColumn
          ? this.applySorting(backendTrades)
          : backendTrades;

        this.TwentyFiveTrades = finalTrades;
        this.twentyfiveState.trades = finalTrades;
        this.twentyfiveState.totalCount = resp.response.total_count;
        this.twentyfiveState.currentPage = resp.response.page_no;

        this.spinner.hide();

        if (highlight && searchKey) {
          const lowerSearch = searchKey.trim().toLowerCase();

          const startsWithMatches = finalTrades.filter((item: { STOCK_SYMBOL: string }) =>
            item.STOCK_SYMBOL?.toLowerCase().startsWith(lowerSearch)
          );

          const containsMatches = finalTrades.filter((item: { STOCK_SYMBOL: string }) =>
            item.STOCK_SYMBOL?.toLowerCase().includes(lowerSearch)
          );

          const matches = startsWithMatches.length > 0 ? startsWithMatches : containsMatches;

          this.MatchedCount = matches.length;
          this.highlightedStockNames25 = matches.map((item: { STOCK_SYMBOL: any }) => item.STOCK_SYMBOL);

          if (matches.length > 0) {
            const firstMatchName = matches[0].STOCK_SYMBOL;

            setTimeout(() => {
              const target = this.stockCells.find(cell =>
                cell.nativeElement
                  .getAttribute('data-stock')
                  ?.toLowerCase() === firstMatchName.toLowerCase()
              );

              if (target) {
                target.nativeElement.scrollIntoView({
                  behavior: 'smooth',
                  block: 'center'
                });
              }
            });
          } else {
            this.highlightedStockNames25 = [];
          }
        } else {
          this.highlightedStockNames25 = [];
          this.MatchedCount = 0;
        }
      } else {
        this.spinner.hide();
        this.TwentyFiveTrades = [];
        this.twentyfiveState.trades = [];
        this.twentyfiveState.totalCount = 0;
        this.highlightedStockNames25 = [];
        this.MatchedCount = 0;
      }

      this.cdr.detectChanges();
    });
  }

  goToNextPage() {
    if (this.activeMenu === 'daily') {
      const nextPage = this.dailyState.currentPage + 1;
      const totalPages = Math.ceil(this.dailyState.totalCount / this.pageSize);
      if (nextPage <= totalPages) {
        this.FetchDailyTrades(nextPage, this.dailyState.searchKey, true, this.StartDate, this.EndDate);
      }
    } else if (this.activeMenu === 'sixty') {
      const nextPage = this.sixtyState.currentPage + 1;
      const totalPages = Math.ceil(this.sixtyState.totalCount / this.pageSize);
      if (nextPage <= totalPages) {
        this.FetchSixtyTrades(nextPage, this.sixtyState.searchKey, true, this.StartDate, this.EndDate);
      }
    } else if (this.activeMenu === 'fifteen') {
      const nextPage = this.fifteenState.currentPage + 1;
      const totalPages = Math.ceil(this.fifteenState.totalCount / this.pageSize);
      if (nextPage <= totalPages) {
        this.FetchFifteenTrades(nextPage, this.fifteenState.searchKey, true, this.StartDate, this.EndDate);
      }
    }
    else if (this.activeMenu === 'one_twenty_five') {
      const nextPage = this.onetwentyfiveState.currentPage + 1;
      const totalPages = Math.ceil(this.onetwentyfiveState.totalCount / this.pageSize);
      if (nextPage <= totalPages) {
        this.Fetch125Trades(nextPage, this.onetwentyfiveState.searchKey, true, this.StartDate, this.EndDate);
      }
    }
    else if (this.activeMenu === 'two_forty') {
      const nextPage = this.twofortyState.currentPage + 1;
      const totalPages = Math.ceil(this.twofortyState.totalCount / this.pageSize);
      if (nextPage <= totalPages) {
        this.Fetch240Trades(nextPage, this.twofortyState.searchKey, true, this.StartDate, this.EndDate);
      }
    } else if (this.activeMenu === 'one_twenty') {
      const nextPage = this.onetwentyState.currentPage + 1;
      const totalPages = Math.ceil(this.onetwentyState.totalCount / this.pageSize);
      if (nextPage <= totalPages) {
        this.Fetch120Trades(nextPage, this.onetwentyState.searchKey, true, this.StartDate, this.EndDate);
      }
    } else if (this.activeMenu === 'seventy_five') {
      const nextPage = this.seventyfiveState.currentPage + 1;
      const totalPages = Math.ceil(this.seventyfiveState.totalCount / this.pageSize);
      if (nextPage <= totalPages) {
        this.Fetch75Trades(nextPage, this.seventyfiveState.searchKey, true, this.StartDate, this.EndDate);
      }
    }
    else if (this.activeMenu === 'twenty_five') {
      const nextPage = this.twentyfiveState.currentPage + 1;
      const totalPages = Math.ceil(this.twentyfiveState.totalCount / this.pageSize);
      if (nextPage <= totalPages) {
        this.Fetch25Trades(nextPage, this.twentyfiveState.searchKey, true, this.StartDate, this.EndDate);
      }
    }
  }

  goToPreviousPage() {
    if (this.activeMenu === 'daily' && this.dailyState.currentPage > 1) {
      this.FetchDailyTrades(this.dailyState.currentPage - 1, this.dailyState.searchKey, true, this.StartDate, this.EndDate);
    } else if (this.activeMenu === 'sixty' && this.sixtyState.currentPage > 1) {
      this.FetchSixtyTrades(this.sixtyState.currentPage - 1, this.sixtyState.searchKey, true, this.StartDate, this.EndDate);
    } else if (this.activeMenu === 'fifteen' && this.fifteenState.currentPage > 1) {
      this.FetchFifteenTrades(this.fifteenState.currentPage - 1, this.fifteenState.searchKey, true, this.StartDate, this.EndDate);
    } else if (this.activeMenu === 'one_twenty_five' && this.onetwentyfiveState.currentPage > 1) {
      this.Fetch125Trades(this.onetwentyfiveState.currentPage - 1, this.onetwentyfiveState.searchKey, true, this.StartDate, this.EndDate);
    } else if (this.activeMenu === 'two_forty' && this.twofortyState.currentPage > 1) {
      this.Fetch240Trades(this.twofortyState.currentPage - 1, this.twofortyState.searchKey, true, this.StartDate, this.EndDate);
    } else if (this.activeMenu === 'one_twenty' && this.onetwentyState.currentPage > 1) {
      this.Fetch120Trades(this.onetwentyState.currentPage - 1, this.onetwentyState.searchKey, true, this.StartDate, this.EndDate);
    } else if (this.activeMenu === 'seventy_five' && this.seventyfiveState.currentPage > 1) {
      this.Fetch75Trades(this.seventyfiveState.currentPage - 1, this.seventyfiveState.searchKey, true, this.StartDate, this.EndDate);
    }
    else if (this.activeMenu === 'twenty_five' && this.twentyfiveState.currentPage > 1) {
      this.Fetch25Trades(this.twentyfiveState.currentPage - 1, this.twentyfiveState.searchKey, true, this.StartDate, this.EndDate);
    }
  }

  getTotalPages(): number {
    const state = this.activeMenu === 'daily' ? this.dailyState
      : this.activeMenu === 'sixty' ? this.sixtyState
        : this.activeMenu === 'fifteen' ? this.fifteenState
          : this.activeMenu === 'one_twenty_five' ? this.onetwentyfiveState
            : this.activeMenu === 'two_forty' ? this.twofortyState
              : this.activeMenu === 'one_twenty' ? this.onetwentyState
                : this.activeMenu === 'seventy_five' ? this.seventyfiveState
                  : this.activeMenu === 'twenty_five' ? this.twentyfiveState
                    : this.dailyState;

    return Math.ceil(state.totalCount / this.pageSize);
  }

  getPageNumbers(): number[] {
    const totalPages = this.getTotalPages();

    const state = this.activeMenu === 'daily' ? this.dailyState
      : this.activeMenu === 'sixty' ? this.sixtyState
        : this.activeMenu === 'fifteen' ? this.fifteenState
          : this.activeMenu === 'one_twenty_five' ? this.onetwentyfiveState
            : this.activeMenu === 'two_forty' ? this.twofortyState
              : this.activeMenu === 'one_twenty' ? this.onetwentyState
                : this.activeMenu === 'seventy_five' ? this.seventyfiveState
                  : this.activeMenu === 'twenty_five' ? this.twentyfiveState
                    : this.dailyState; // fallback

    const currentPage = state.currentPage;
    const pageNumbers: number[] = [];

    const maxVisible = 5;
    let startPage = Math.max(currentPage - Math.floor(maxVisible / 2), 1);
    let endPage = Math.min(startPage + maxVisible - 1, totalPages);

    if (endPage - startPage < maxVisible - 1) {
      startPage = Math.max(endPage - maxVisible + 1, 1);
    }

    for (let i = startPage; i <= endPage; i++) {
      pageNumbers.push(i);
    }

    return pageNumbers;
  }

  getCurrentPage(): number {
    return this.activeMenu === 'daily' ? this.dailyState.currentPage
      : this.activeMenu === 'sixty' ? this.sixtyState.currentPage
        : this.activeMenu === 'one_twenty_five' ? this.onetwentyfiveState.currentPage
          : this.activeMenu === 'two_forty' ? this.twofortyState.currentPage
            : this.activeMenu === 'one_twenty' ? this.onetwentyState.currentPage
              : this.activeMenu === 'seventy_five' ? this.seventyfiveState.currentPage
                : this.activeMenu === 'twenty_five' ? this.twentyfiveState.currentPage
                  : this.fifteenState.currentPage;
  }

  goToPage(page: number) {
    if (this.activeMenu === 'daily') {
      this.FetchDailyTrades(page, this.dailyState.searchKey, true, this.StartDate, this.EndDate);
    } else if (this.activeMenu === 'sixty') {
      this.FetchSixtyTrades(page, this.sixtyState.searchKey, true, this.StartDate, this.EndDate);
    } else if (this.activeMenu === 'fifteen') {
      this.FetchFifteenTrades(page, this.fifteenState.searchKey, true, this.StartDate, this.EndDate);
    } else if (this.activeMenu === 'one_twenty_five') {
      this.Fetch125Trades(page, this.onetwentyfiveState.searchKey, true, this.StartDate, this.EndDate);
    } else if (this.activeMenu === 'two_forty') {
      this.Fetch240Trades(page, this.twofortyState.searchKey, true, this.StartDate, this.EndDate);
    } else if (this.activeMenu === 'one_twenty') {
      this.Fetch120Trades(page, this.onetwentyState.searchKey, true, this.StartDate, this.EndDate);
    } else if (this.activeMenu === 'seventy_five') {
      this.Fetch75Trades(page, this.seventyfiveState.searchKey, true, this.StartDate, this.EndDate);
    }
    else if (this.activeMenu === 'twenty_five') {
      this.Fetch25Trades(page, this.twentyfiveState.searchKey, true, this.StartDate, this.EndDate);
    }
  }

  stockDataFunc() {
    this.apiService.getStockList(this.SelectedCountryName).subscribe(
      (data) => {
        this.stockData = data.response;
      },
    );
  }

  convertToDateTimeLocalFormat(dateTimeString: string): string {
    return dateTimeString.replace(" ", "T").slice(0, 16);
  }

  closeNotification() {
    this.isNotificationVisible = false;
  }

  ngOnDestroy(): void {
    this.disconnectWebSocket();
  }

  disconnectWebSocket(): void {
    this.webSocketService.disconnectStock();
  }

  ViewGraph(stock_name: any, entry_price: any, stoploss_price: any, target_price: any, entry_timestamp: any, extendedtime: any, rrr: any, EXP_NUM: any, tradeId: any, tradeType: any, probability: any, prediction: any, stock_id: any = null, SetupTime: any = null): void {
    let container = document.getElementById('chart-container_new');
    if (container) {
      container.innerHTML = ''; // clears old chart
    }
    console.log("Setup Date Time", SetupTime)
    // const last_d_time = moment().format('YYYY-MM-DD HH:mm:ss')
    this.disconnectWebSocket()
    this.SelectedStockId = stock_id;
    this.selectedTradeId = tradeId;
    this.selectedTradeType = tradeType;
    this.SelectedExpiryDate = EXP_NUM;
    this.getReason()
    this.ChartRESPONSE = [];
    this.FullChartResponse = [];
    this.chart = null;
    this.RRR = rrr;
    this.spinner.show();
    this.SpinnerCounter = 0;
    this.SelectedStockName = stock_name;
    const currentDateTime = moment();
    const last_d_time = moment(SetupTime).format('YYYY-MM-DD HH:mm:ss');
    this.SETUPTYPE = tradeType;

    if (this.SelectedExchange_Name == "NSE") {
      if (this.activeMenu == "daily") {
        this.finData = {
          country: localStorage.getItem('selectedCountryName'),
          tick: stock_name,
          time_frame: 1,
          last_d_time: last_d_time
        }
      }
      if (this.activeMenu == "sixty") {
        this.finData = {
          country: localStorage.getItem('selectedCountryName'),
          tick: stock_name,
          time_frame: 2,
          last_d_time: last_d_time
        }
      }
      if (this.activeMenu == "fifteen") {
        this.finData = {
          country: localStorage.getItem('selectedCountryName'),
          tick: stock_name,
          time_frame: 3,
          last_d_time: last_d_time
        }
      }

      if (this.activeMenu == "seventy_five") {
        this.finData = {
          country: localStorage.getItem('selectedCountryName'),
          tick: stock_name,
          time_frame: 25,
          last_d_time: last_d_time
        }
      }
      if (this.activeMenu == "one_twenty_five") {
        this.finData = {
          country: localStorage.getItem('selectedCountryName'),
          tick: stock_name,
          time_frame: 5,
          last_d_time: last_d_time
        }
      }
      if (this.activeMenu == "twenty_five") {
        this.finData = {
          country: localStorage.getItem('selectedCountryName'),
          tick: stock_name,
          time_frame: 6,
          last_d_time: last_d_time
        }
      }

      this.FetchCandlesAndZones(entry_price, stoploss_price, target_price, entry_timestamp, extendedtime)
    }

    if (this.SelectedExchange_Name == "MCX") {
      const formattedDate = `${EXP_NUM.slice(0, 2)}-${EXP_NUM.slice(2, 4)}-${EXP_NUM.slice(4)}`;
      if (this.activeMenu == "daily") {
        this.finData = {
          st_sym: stock_name,
          exp_dt: formattedDate,
          last_d_time: last_d_time,
          time_frame: 1
        }
      }

      if (this.activeMenu == "sixty") {
        this.finData = {
          st_sym: stock_name,
          exp_dt: formattedDate,
          last_d_time: last_d_time,
          time_frame: 4
        }
      }

      if (this.activeMenu == "two_forty") {
        this.finData = {
          st_sym: stock_name,
          exp_dt: formattedDate,
          last_d_time: last_d_time,
          time_frame: 2
        }
      }

      if (this.activeMenu == "one_twenty") {
        this.finData = {
          st_sym: stock_name,
          exp_dt: formattedDate,
          last_d_time: last_d_time,
          time_frame: 3
        }
      }

      this.FetchCandleAndDataForMCX(entry_price, stoploss_price, target_price, entry_timestamp, extendedtime, EXP_NUM, SetupTime)
    }

    if (this.SelectedExchange_Name == "NSEFO") {
      const formattedDate = `${EXP_NUM.slice(0, 2)}-${EXP_NUM.slice(2, 4)}-${EXP_NUM.slice(4)}`;
      if (this.activeMenu == "daily") {
        this.finData = {
          st_sym: stock_name,
          exp_dt: formattedDate,
          last_d_time: last_d_time,
          time_frame: 1
        }
      }

      if (this.activeMenu == "sixty") {
        this.finData = {
          st_sym: stock_name,
          exp_dt: formattedDate,
          last_d_time: last_d_time,
          time_frame: 2
        }
      }

      if (this.activeMenu == "seventy_five") {
        this.finData = {
          st_sym: stock_name,
          exp_dt: formattedDate,
          last_d_time: last_d_time,
          time_frame: 25
        }
      }

      if (this.activeMenu == "fifteen") {
        this.finData = {
          st_sym: stock_name,
          exp_dt: formattedDate,
          last_d_time: last_d_time,
          time_frame: 3
        }
      }
      if (this.activeMenu == "one_twenty_five") {
        this.finData = {
          st_sym: stock_name,
          exp_dt: formattedDate,
          last_d_time: last_d_time,
          time_frame: 5
        }
      }
      if (this.activeMenu == "twenty_five") {
        this.finData = {
          st_sym: stock_name,
          exp_dt: formattedDate,
          last_d_time: last_d_time,
          time_frame: 6
        }
      }
      this.FetchCandleAndDataForNSEFO(entry_price, stoploss_price, target_price, entry_timestamp, extendedtime, EXP_NUM, SetupTime)
    }
    const Prob = probability !== null ? (probability * 100).toFixed(2) + '%' : 'NA';
    this.ModelPrediction = "PROBABILITY OF TRADE : " + prediction.toUpperCase() + " = " + Prob;
    this.Prediction = prediction;
    this.Probability = probability
    this.isNotificationVisible = true;
    // this.getStockTickbySymbol();     //nabonita
  }

  connectWebSocket(type: any): void {
    console.log("FIN DATA", this.finData)
    this.webSocketService.connect(this.finData.tick, this.finData.time_frame, this.SelectedStockId, type);
    this.webSocketService.getStockMessage().subscribe((data) => {
      this.realTimePrice = data;
      console.log("UPDATED DATA", data)
      const parsedData = JSON.parse(data);
      if (this.finData.tick === parsedData.data.stock_tick) {
        this.updateChart(data);
      }
    });
  }

  updateChart(data: any): void {
    const parsedData = JSON.parse(data);

    // Convert all fields to numbers
    const updatedCandle = {
      open: Number(parsedData.data.open),
      high: Number(parsedData.data.high),
      low: Number(parsedData.data.low),
      close: Number(parsedData.data.close),
      time: Number(parsedData.data.time),
    };

    // Get existing chart data
    const existingData = this.candlestickSeries.data();
    if (!existingData || existingData.length === 0) {
      // First candle
      this.candlestickSeries.setData([updatedCandle]);
    } else {
      // Remove last candle and append updated one
      const dataWithoutLast = existingData.slice(0, -1);
      const newSeriesData = [...dataWithoutLast, updatedCandle];

      // ---- Add postbars after last real candle ----
      const lastCandle = newSeriesData[newSeriesData.length - 1];
      const postbars = [...new Array(100)].map((_, i) => ({
        time: lastCandle.time + (i + 1) * this.xspan,
      }));

      // Combine
      // const finalSeries = [...newSeriesData, ...postbars];

      // Set to chart
      this.candlestickSeries.setData([...newSeriesData, ...postbars]);
    }

    // Update lastBar reference
    this.lastBar = updatedCandle;

    // Optional: update closing line
    this.CreateClosingLine(updatedCandle.close);
  }

  FetchCandleAndDataForNSEFO(entry_price: any, stoploss_price: any, target_price: any, entry_timestamp: any, extendedtime: any, EXP_NUM: any, SetupTime: any) {
    // const last_d_time = moment().format('YYYY-MM-DD HH:mm:ss')
    this.apiService.getFutureData(this.finData.st_sym, this.finData.exp_dt, this.finData.time_frame, SetupTime).subscribe(resp => {
      this.FullChartResponse = resp.response;
      const originalDateString = this.finData.last_d_time;
      const originalDate = new Date(originalDateString);
      const year = originalDate.getFullYear();
      const month = ('0' + (originalDate.getMonth() + 1)).slice(-2);
      const day = ('0' + originalDate.getDate()).slice(-2);
      const hours = ('0' + originalDate.getHours()).slice(-2);
      const minutes = ('0' + originalDate.getMinutes()).slice(-2);
      const seconds = ('0' + originalDate.getSeconds()).slice(-2);
      const formattedDateString = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
      this.finData.last_d_time = formattedDateString;
      if (this.activeMenu == "daily") {
        this.QualifiedZoneFlag = true;
        this.ChartRESPONSE = resp.response.daily;
        this.FullScreenModeValue = "daily";
        this.ModalHeader = "daily";
        // this.finData.time_frame = 1;
      }
      if (this.activeMenu == "sixty") {
        this.QualifiedZoneFlag = true;
        this.FullScreenModeValue = "sixty";
        this.ModalHeader = "60 minute";
        // this.finData.time_frame = 2;
        this.ChartRESPONSE = resp.response.sixty;
      }
      if (this.activeMenu == "fifteen") {
        this.QualifiedZoneFlag = true;
        this.FullScreenModeValue = "fifteen";
        this.ModalHeader = "15 minute";
        // this.finData.time_frame = 3;
        this.ChartRESPONSE = resp.response.fifteen;
      }
      if (this.activeMenu == "seventy_five") {
        this.QualifiedZoneFlag = true;
        this.FullScreenModeValue = "seventy_five";
        this.ModalHeader = "75 minute";
        // this.finData.time_frame = 25;
        this.ChartRESPONSE = resp.response.seventy_five;
      }
      if (this.activeMenu == "twenty_five") {
        this.QualifiedZoneFlag = true;
        this.FullScreenModeValue = "twenty_five";
        this.ModalHeader = "25 minute";
        // this.finData.time_frame = 25;
        this.ChartRESPONSE = resp.response.twenty_five;
      }
      if (this.activeMenu == "one_twenty_five") {
        this.QualifiedZoneFlag = true;
        this.FullScreenModeValue = "one_twenty_five";
        this.ModalHeader = "125 minute";
        // this.finData.time_frame = 25;
        this.ChartRESPONSE = resp.response.one_twenty_five;
      }
      this.previousHighServiceForMcxNsefo("futures")
      this.GetQualifiedZonesForNSEFO(),
        this.GetBaseCandleDataForNSEFO();
      this.OverLayFetchingForNSEFO();
      this.BadZonesForNSEFO()
      this.OptimizedBuySellZoneNSEFO();
      this.PricePercentageNsefo();
      this.lastRow = this.ChartRESPONSE[this.ChartRESPONSE.length - 1];
      this.lastTime = extendedtime;
      this.LoadChart(this.ChartRESPONSE, "chart-container_new");
      const dateandtime = moment().subtract(10, 'days').format("YYYY-MM-DD HH:mm:ss");
      this.purchased_date = this.convertToDateTimeLocalFormat(dateandtime);;
      this.entry_timestamp = entry_timestamp;
      this.entry_price = entry_price;
      this.stoploss_price = stoploss_price;
      this.target_price = target_price;
      this.getsetup(this.purchased_date, this.entry_timestamp, this.entry_price, this.stoploss_price, this.target_price)
    })

    this.chartContainer.nativeElement.addEventListener('contextmenu', (event: MouseEvent) => {

      event.preventDefault();
      this.showContextMenu(event.clientX, event.clientY);
    });
    document.addEventListener('click', () => this.hideContextMenu());
  }

  FetchCandleAndDataForMCX(entry_price: any, stoploss_price: any, target_price: any, entry_timestamp: any, extendedtime: any, EXP_NUM: any, SetupTime: any) {
    // const last_d_time = moment().format('YYYY-MM-DD HH:mm:ss')
    this.apiService.getMcxData(this.finData.st_sym, this.finData.exp_dt, this.finData.time_frame, SetupTime).subscribe(resp => {
      this.FullChartResponse = resp.response;
      const originalDateString = this.finData.last_d_time;
      const originalDate = new Date(originalDateString);
      const year = originalDate.getFullYear();
      const month = ('0' + (originalDate.getMonth() + 1)).slice(-2);
      const day = ('0' + originalDate.getDate()).slice(-2);
      const hours = ('0' + originalDate.getHours()).slice(-2);
      const minutes = ('0' + originalDate.getMinutes()).slice(-2);
      const seconds = ('0' + originalDate.getSeconds()).slice(-2);
      const formattedDateString = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
      this.finData.last_d_time = formattedDateString;
      if (this.activeMenu == "daily") {
        this.QualifiedZoneFlag = true;
        this.ChartRESPONSE = resp.response.daily;
        this.FullScreenModeValue = "daily";
        this.ModalHeader = "daily";
        // this.finData.time_frame = 1;
      }
      if (this.activeMenu == "sixty") {
        this.QualifiedZoneFlag = true;
        this.FullScreenModeValue = "sixty";
        this.ModalHeader = "60 minute";
        // this.finData.time_frame = 4;
        this.ChartRESPONSE = resp.response.sixty;
      }
      if (this.activeMenu == "two_forty") {
        this.QualifiedZoneFlag = true;
        this.FullScreenModeValue = "two_forty";
        this.ModalHeader = "240 minute";
        // this.finData.time_frame = 3;
        this.ChartRESPONSE = resp.response.two_forty;
      }
      if (this.activeMenu == "one_twenty") {
        this.QualifiedZoneFlag = true;
        this.FullScreenModeValue = "one_twenty";
        this.ModalHeader = "120 minute";
        // this.finData.time_frame = 3;
        this.ChartRESPONSE = resp.response.one_twenty;
      }
      if (this.activeMenu == "one_twenty_five") {
        this.QualifiedZoneFlag = true;
        this.FullScreenModeValue = "one_twenty_five";
        this.ModalHeader = "125 minute";
        // this.finData.time_frame = 25;
        this.ChartRESPONSE = resp.response.one_twenty_five;
      }
      if (this.activeMenu == "twenty_five") {
        this.QualifiedZoneFlag = true;
        this.FullScreenModeValue = "twenty_five";
        this.ModalHeader = "25 minute";
        // this.finData.time_frame = 25;
        this.ChartRESPONSE = resp.response.twenty_five;
      }
      this.previousHighServiceForMcxNsefo("commodity")
      this.PricePercentageMcx()
      this.GetQualifiedZonesForMcx(),
        this.GetBaseCandleDataForMcx();
      this.OverLayFetchingForMcx();
      this.BadZonesForMCX()
      this.OptimizedBuySellZoneMCX()
      this.lastRow = this.ChartRESPONSE[this.ChartRESPONSE.length - 1];
      this.lastTime = extendedtime;
      this.LoadChart(this.ChartRESPONSE, "chart-container_new");
      const dateandtime = moment().subtract(10, 'days').format("YYYY-MM-DD HH:mm:ss");
      this.purchased_date = this.convertToDateTimeLocalFormat(dateandtime);;
      this.entry_timestamp = entry_timestamp;
      this.entry_price = entry_price;
      this.stoploss_price = stoploss_price;
      this.target_price = target_price;
      this.getsetup(this.purchased_date, this.entry_timestamp, this.entry_price, this.stoploss_price, this.target_price)
    })

    this.chartContainer.nativeElement.addEventListener('contextmenu', (event: MouseEvent) => {

      event.preventDefault();
      this.showContextMenu(event.clientX, event.clientY);
    });
    document.addEventListener('click', () => this.hideContextMenu());
  }

  FetchCandlesAndZones(entry_price: any, stoploss_price: any, target_price: any, entry_timestamp: any, extendedtime: any) {
    this.apiService.fetchAvailableTradesCandleData(this.finData, this.SelectedExchange_Name).subscribe(resp => {
      this.FullChartResponse = resp.response;
      const originalDateString = this.finData.last_d_time;
      const originalDate = new Date(originalDateString);
      const year = originalDate.getFullYear();
      const month = ('0' + (originalDate.getMonth() + 1)).slice(-2);
      const day = ('0' + originalDate.getDate()).slice(-2);
      const hours = ('0' + originalDate.getHours()).slice(-2);
      const minutes = ('0' + originalDate.getMinutes()).slice(-2);
      const seconds = ('0' + originalDate.getSeconds()).slice(-2);
      const formattedDateString = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
      this.finData.last_d_time = formattedDateString;
      if (this.activeMenu == "daily") {
        this.QualifiedZoneFlag = true;
        this.ChartRESPONSE = resp.response.daily;
        this.FullScreenModeValue = "daily";
        this.ModalHeader = "daily"
      }
      if (this.activeMenu == "sixty") {
        this.QualifiedZoneFlag = true;
        this.FullScreenModeValue = "sixty";
        this.ModalHeader = "60 minute";
        this.ChartRESPONSE = resp.response.sixty;
      }
      if (this.activeMenu == "fifteen") {
        this.QualifiedZoneFlag = true;
        this.FullScreenModeValue = "fifteen";
        this.ModalHeader = "15 minute";
        this.ChartRESPONSE = resp.response.fifteen;
      }
      if (this.activeMenu == "seventy_five") {
        this.QualifiedZoneFlag = true;
        this.FullScreenModeValue = "seventy_five";
        this.ModalHeader = "75 minute";
        this.ChartRESPONSE = resp.response.seventy_five;
      }
      if (this.activeMenu == "one_twenty_five") {
        this.QualifiedZoneFlag = true;
        this.FullScreenModeValue = "one_twenty_five";
        this.ModalHeader = "125 minute";
        this.ChartRESPONSE = resp.response.one_twenty_five;
      }
      if (this.activeMenu == "twenty_five") {
        this.QualifiedZoneFlag = true;
        this.FullScreenModeValue = "twenty_five";
        this.ModalHeader = "25 minute";
        this.ChartRESPONSE = resp.response.twenty_five;
      }
      this.GetSetUpData()
      this.previousHighService()
      this.GetQualifiedZones(),
        this.GetBaseCandleData();
      this.GetBuyZoneData();
      this.GetSellZoneData();
      this.OverLayFetching()
      this.GetAllZones();
      this.BadZones();
      this.OptimizedBuySellZoneFunc(),
        this.PricePercentage()

      this.lastRow = this.ChartRESPONSE[this.ChartRESPONSE.length - 1];
      this.lastTime = extendedtime;
      this.LoadChart(this.ChartRESPONSE, "chart-container_new");

      const dateandtime = moment().subtract(10, 'days').format("YYYY-MM-DD HH:mm:ss");
      this.purchased_date = this.convertToDateTimeLocalFormat(dateandtime);;
      this.entry_timestamp = entry_timestamp;
      this.entry_price = entry_price;
      this.stoploss_price = stoploss_price;
      this.target_price = target_price;
      this.getsetup(this.purchased_date, this.entry_timestamp, this.entry_price, this.stoploss_price, this.target_price)
      this.connectWebSocket(this.activeMenu);
    })
    this.chartContainer.nativeElement.addEventListener('contextmenu', (event: MouseEvent) => {
      event.preventDefault();
      this.showContextMenu(event.clientX, event.clientY);
    });
    document.addEventListener('click', () => this.hideContextMenu());
  }

  GetSetUpData() {
    this.ScoreData = [];
    this.apiService.GetSetupDataService(this.finData).subscribe(resp => {
      this.ScoreData = resp.response
    })
  }

  previousHighServiceForMcxNsefo(exchange: any) {
    console.log("PH", this.finData)
    this.apiService.GetprevioushighDataMcxNsefoService(this.finData, exchange).subscribe(resp => {
      this.PreviousHighData = resp.response;
      this.addPreviousHighPriceLine(this.FullScreenModeValue);
      console.log(`RESPONSE 7 (PREVIOUS HIGH) :`, this.PreviousHighData);
    })
  }

  PricePercentage() {
    this.apiService.PricePercentageService(this.finData).subscribe(resp => {
      console.log("Price Percentage : ", resp);
      this.PricePercentageData = resp.response;
      this.PP_Analyze = this.PricePercentageData.analyze;
      this.PP_Evaluate = this.PricePercentageData.evaluate;
      this.PP_Execute = this.PricePercentageData.execute;
      this.PP_Reason = this.PricePercentageData.reason;
      this.PP_FinalDecision = this.PricePercentageData.final_decision
    });
  }

  PricePercentageNsefo() {
    console.log("FIN DATA FUTURE", this.finData)
    let obj = {
      country_name: this.SelectedCountryName,
      st_sym: this.finData.st_sym,
      time_frame: this.finData.time_frame,
      exp_dt: this.finData.exp_dt,
      last_d_time: this.finData.last_d_time,
      is_future: true
    }
    this.apiService.PricePercentageNsefoService(obj).subscribe(resp => {
      console.log("Price Percentage Future: ", resp);
      this.PricePercentageData = resp.response;
      // this.PP_Analyze = this.PricePercentageData.analyze;
      // this.PP_Evaluate = this.PricePercentageData.evaluate;
      // this.PP_Execute = this.PricePercentageData.execute;
      // this.PP_Reason = this.PricePercentageData.reason;
      // this.PP_FinalDecision = this.PricePercentageData.final_decision
    });
  }

  PricePercentageMcx() {
    let obj = {
      country_name: this.finData.country,
      tick: this.finData.st_sym,
      time_frame: this.finData.time_frame,
      exp_dt: this.finData.exp_dt,
      last_d_time: this.finData.last_d_time,
      is_future: false
    }
    this.apiService.PricePercentageNsefoService(obj).subscribe(resp => {
      console.log("Price Percentage MCX: ", resp);
      this.PricePercentageData = resp.response;
      // this.PP_Analyze = this.PricePercentageData.analyze;
      // this.PP_Evaluate = this.PricePercentageData.evaluate;
      // this.PP_Execute = this.PricePercentageData.execute;
      // this.PP_Reason = this.PricePercentageData.reason;
      // this.PP_FinalDecision = this.PricePercentageData.final_decision
    });
  }

  getRegimeClass(regime: string | null | undefined): string {
    const r = (regime || '').toUpperCase();

    if (r === 'UP') return 'regime-up';
    if (r === 'SW') return 'regime-sw';
    if (r === 'DOWN') return 'regime-down';
    return 'regime-neutral';
  }

  formatPct(value: number | null | undefined): string {
    if (value === null || value === undefined) return '%';
    return `${value.toFixed(1)}%`;
  }

  getZoneLine(zone: any): string {
    if (!zone) return '-';
    return `Prox ${zone.proximal ?? '-'} / Dist ${zone.distal ?? '-'} | ${zone.state ?? '-'}`;
  }

  getZoneMetaLine(zone: any): string {
    if (!zone) return '';
    return `Retests: ${zone.retest_count ?? 0} | Bars Since: ${zone.age_bars ?? 0} | Violation: ${zone.violation ?? 'NONE'}`;
  }

  closePopup() {
    this.showPopup = false;
  }

  openPopupPP() {
    this.centerModalA(850, 450);
    this.modalA.show();
  }

  private centerModalA(width: number, height: number) {
    // viewport size
    const vw = window.innerWidth;
    const vh = window.innerHeight;

    // if you have fixed header/navbar height, add it here (or keep 0)
    const safeTop = 8;     // keeps header always visible
    const safeLeft = 8;
    const safeRight = 8;
    const safeBottom = 8;

    // ideal center
    let left = Math.round((vw - width) / 2);
    let top = Math.round((vh - height) / 2);

    // clamp so it never goes out of screen
    left = Math.min(Math.max(left, safeLeft), vw - width - safeRight);
    top = Math.min(Math.max(top, safeTop), vh - height - safeBottom);

    this.modalAPos = { top, left };
  }

  exchange() {
    this.apiService.getUserExchanges(this.userId, this.countryId).subscribe(
      (res) => {
        if (res && res.response) {

          this.exchanges = res.response;
          if (this.SelectedCountryName == "India") {
            this.selectedExchange = this.exchanges.find((ex: { exchange_name: string; }) => ex.exchange_name === 'NSE');
            const matchedExchange = this.exchanges.find((ex: { exchange_name: string; }) => ex.exchange_name === "NSE");
            if (matchedExchange) {
              this.SelectedExchange_Id = matchedExchange.exchange_id;
              this.SelectedExchange_Name = matchedExchange.exchange_name;
            }
          }
          else {
            this.selectedExchange = this.exchanges.find((ex: { exchange_name: string; }) => ex.exchange_name === 'NASDAQ');
            const matchedExchange = this.exchanges.find((ex: { exchange_name: string; }) => ex.exchange_name === "NASDAQ");
            if (matchedExchange) {
              this.SelectedExchange_Id = matchedExchange.exchange_id;
              this.SelectedExchange_Name = matchedExchange.exchange_name;
            }
          }


          this.onExchangeChange();
        }
      });
  }

  GetQualifiedZones() {
    this.showmsg = "Fetching Data !";
    console.log("ggggggggggg", this.finData)
    this.apiService.GetQualifiedZoneService(this.finData).subscribe(resp => {
      this.QualifiedData = resp.response;
      // console.log("QUALIFIED STOCKS",this.QualifiedData)
      this.SpinnerCounter++;
      if (this.SpinnerCounter == 6) {
        this.spinner.hide();
      }
    });
  }

  viewReason() {
    this.showReasonPanel = true;
  }

  closePanel() {
    this.showReasonPanel = false;
  }

  getReason() {
    if (!this.selectedTradeId) {
      this.reasons = ['No trade selected'];
      return;
    }

    this.apiService.getReasonDataAvailableTrades(this.selectedTradeId).subscribe({
      next: (res: any) => {
        console.log("ressssssssss", res)
        if (res?.response && Object.keys(res.response).length > 0) {
          this.reasons = Object.entries(res.response).map(
            ([key, value]) => `${key} : ${value}`
          );
        } else {
          this.reasons = ['No data available'];
        }
      },
      error: (err) => {
        console.error('API Error:', err);
        this.reasons = ['Error fetching reasons'];
      }
    });
  }

  OptimizedBuySellZoneFunc() {
    this.apiService.GetOptimizedBuySellZoneService(this.finData).subscribe(resp => {
      this.OptimizedBuySellZoneData = resp.response;
      // console.log("OPTIMIZED BUY SELL STOCKS",this.OptimizedBuySellZoneData)
    });
  }

  OptimizedBuySellZoneMCX() {
    this.apiService.GetOptimizedBuySellZoneMCXService(this.finData).subscribe(resp => {
      this.OptimizedBuySellZoneData = resp.response;
      // console.log("OPTIMIZED BUY SELL MCX", this.OptimizedBuySellZoneData)
    });
  }

  OptimizedBuySellZoneNSEFO() {
    this.apiService.GetOptimizedBuySellZoneNSEFOervice(this.finData).subscribe(resp => {
      this.OptimizedBuySellZoneData = resp.response;
      // console.log("OPTIMIZED BUY SELL FUTURE", this.OptimizedBuySellZoneData)
    });
  }

  GetQualifiedZonesForMcx() {
    this.showmsg = "Fetching Data !";
    this.apiService.GetMcxQualifiedZoneCandleData(this.finData).subscribe(resp => {
      this.QualifiedData = resp.response;

      this.SpinnerCounter++;
    });
  }

  GetQualifiedZonesForNSEFO() {
    this.showmsg = "Fetching Data !";
    this.apiService.GetFutureQualifiedZoneCandleData(this.finData).subscribe(resp => {
      this.QualifiedData = resp.response;
      // console.log("QUALIFIED NSEFO",this.QualifiedData)
    });
  }

  GetBaseCandleData() {
    this.apiService.GetBaseCandleData(this.finData).subscribe(resp => {
      this.BaseCandleData = resp.response
      // console.log("BASE CANDLE STOCKS",this.BaseCandleData)
      this.SpinnerCounter++;
      if (this.SpinnerCounter == 6) {
        this.spinner.hide();
      }
    })
  }

  GetBaseCandleDataForMcx() {
    this.apiService.GetMcxBaseCandleData(this.finData).subscribe(resp => {
      this.BaseCandleData = resp.response
      // console.log("BASE CANDLE MCX",this.BaseCandleData)
    })
  }

  GetBaseCandleDataForNSEFO() {
    this.apiService.GetFutureBaseCandleData(this.finData).subscribe(resp => {
      this.BaseCandleData = resp.response
      // console.log("BASE CANDLE FUTURE",this.BaseCandleData)
    })
  }

  GetBuyZoneData() {
    this.apiService.GetBuyZoneDataService(this.finData).subscribe(resp => {
      this.BuyZoneData = resp.response
      // console.log("BUY ZONE DATA STOCKS",this.BuyZoneData)
      this.SpinnerCounter++;
      if (this.SpinnerCounter == 6) {
        this.spinner.hide();
      }
    })
  }

  GetSellZoneData() {
    this.apiService.GetSellZoneDataService(this.finData).subscribe(resp => {
      this.SellZoneData = resp.response
      // console.log("SELL ZONE DATA STOCKS",this.SellZoneData)
      this.SpinnerCounter++;
      if (this.SpinnerCounter == 6) {
        this.spinner.hide();
      }
    })
  }

  OverLayFetching() {
    this.apiService.fetchingOverlayService(this.finData).subscribe((resp: any) => {
      this.OverLayCandleData = resp.response
      // console.log("OVERLAY DATA STOCKS",this.OverLayCandleData)
      this.BuyOverlayData = this.OverLayCandleData.Buy;
      this.SellOverlayData = this.OverLayCandleData.Sell;
      this.SpinnerCounter++;
      if (this.SpinnerCounter == 6) {
        this.spinner.hide();
      }
    })
  }

  OverLayFetchingForMcx() {
    this.apiService.GetMcxOverLayZoneService(this.finData).subscribe((resp: any) => {
      this.OverLayCandleData = resp.response
      // console.log("OVERLAY DATA MCX",this.OverLayCandleData)
      this.BuyOverlayData = this.OverLayCandleData.Buy;
      this.SellOverlayData = this.OverLayCandleData.Sell;
      this.spinner.hide()
    })
  }

  OverLayFetchingForNSEFO() {
    this.apiService.GetOverLayZoneService(this.finData).subscribe((resp: any) => {
      this.OverLayCandleData = resp.response
      // console.log("OVERLAY DATA NSEFO",this.OverLayCandleData)
      this.BuyOverlayData = this.OverLayCandleData.Buy;
      this.SellOverlayData = this.OverLayCandleData.Sell;
      this.spinner.hide()
    })
  }

  GetAllZones() {
    this.apiService.GetAllZonesData(this.finData).subscribe(resp => {
      this.AllZonesData = resp.response
      this.SpinnerCounter++;
      if (this.SpinnerCounter == 6) {
        this.spinner.hide();
      }
    })
  }

  BadZones() {
    this.BadZoneData = []
    // this.showmsg = "Fetching Bad Zone Data !";
    this.apiService.GetBadZoneDataService(this.finData).subscribe(resp => {
      this.BadZoneData = resp.response;
    });
  }

  BadZonesForMCX() {
    this.BadZoneData = []
    this.showmsg = "Fetching Bad Zone Data !";
    this.apiService.GetMcxBadZoneCandleData(this.finData).subscribe(resp => {
      this.BadZoneData = resp.response;
    });
  }

  BadZonesForNSEFO() {
    this.BadZoneData = []
    this.showmsg = "Fetching Bad Zone Data !";
    this.apiService.GetFutureBadZoneCandleData(this.finData).subscribe(resp => {
      this.BadZoneData = resp.response;
    });
  }

  getsetup(purchased_date: any, entry_timestamp: any, entry_price: any, stoploss_price: any, target_price: any) {
    console.log("Purchased Date", purchased_date)
    console.log("Entry Timestamp", entry_timestamp)
    const entryddateObject3 = new Date(purchased_date + 'Z');
    const istOffset3 = 5.5 * 60 * 60 * 1000;
    const istDateObject3 = new Date(entryddateObject3.getTime() + istOffset3);
    const year1 = istDateObject3.getUTCFullYear();
    const month1 = String(istDateObject3.getUTCMonth() + 1).padStart(2, '0');
    const day1 = String(istDateObject3.getUTCDate()).padStart(2, '0');
    const purchaseddateOnly1 = `${year1}-${month1}-${day1}`;
    const PurchaseddateObjectNumber = new Date(purchaseddateOnly1);
    const timestampInMilliseconds = PurchaseddateObjectNumber.getTime();
    const timestampInSeconds_purchased = Math.floor(timestampInMilliseconds / 1000);
    console.log("timestampInSeconds_purchased", timestampInSeconds_purchased)

    const entryddateObject = new Date(entry_timestamp + 'Z');
    const istOffset = 5.5 * 60 * 60 * 1000;
    const istDateObject = new Date(entryddateObject.getTime() + istOffset);
    // Extract both date and time components
    const year = istDateObject.getUTCFullYear();
    const month = String(istDateObject.getUTCMonth() + 1).padStart(2, '0'); // Months are 0-based
    const day = String(istDateObject.getUTCDate()).padStart(2, '0');
    const hours = String(istDateObject.getUTCHours()).padStart(2, '0');
    const minutes = String(istDateObject.getUTCMinutes()).padStart(2, '0');
    const seconds = String(istDateObject.getUTCSeconds()).padStart(2, '0');
    const entryddateOnly = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
    const entrydateObjectNumber = new Date(entryddateOnly);
    const timestampInMillisecondsss = entrydateObjectNumber.getTime();
    const timestampInSeconds_entry = Math.floor(timestampInMillisecondsss / 1000);
    // console.log("timestampInSeconds_entry",timestampInSeconds_entry)
    //  if (this.buylineSeries && !this.buylineSeries.isDisposed) {
    //     this.buylineSeries.setMarkers([]);
    //     this.buylineSeries.setData([]);
    //   }
    //   if (this.targetlineSeries) {
    //     this.targetlineSeries.setMarkers([]);
    //     this.targetlineSeries.setData([])
    //   }
    //   if (this.stoplosslineSeries) {
    //     this.stoplosslineSeries.setMarkers([]);
    //     this.stoplosslineSeries.setData([])
    //   }
    // if (this.status == null) {
    this.addEntryPriceLine(entry_price, entry_timestamp, this.lastTime)
    this.addStoplossPriceLine(stoploss_price, entry_timestamp, this.lastTime)
    this.addTargetPriceLine(target_price, entry_timestamp, this.lastTime)
    // }
  }

  calculateRRR(): number {
    // Calculate risk and reward using absolute values
    const risk = Math.abs(this.EntryPrice - this.StoplossPrice); // Calculate risk
    const reward = Math.abs(this.TargetPrice - this.EntryPrice); // Calculate reward

    // Check to avoid division by zero
    if (risk === 0) {
      return Infinity; // or return null or handle as needed
    }

    const riskToRewardRatio = reward / risk; // Calculate the risk-to-reward ratio
    return riskToRewardRatio; // Return the risk-to-reward ratio
  }

  updateMarkers(price: number, RRR: number, time: any) {
    this.buylineSeries.setMarkers([
      {
        time: time,
        position: 'aboveBar',
        color: 'blue',
        text: `R-R :  ${RRR.toFixed(2)}`
      },
      {
        time: time,
        position: 'aboveBar',
        color: 'blue',
        text: `Entry : ${price.toFixed(2)}`
      }
    ]);
  }

  addEntryPriceLine(price: number, time: any, extendedtime: any) {
    this.buylineSeries = this.chart.addLineSeries({
      color: 'blue',
      lineWidth: 2,
      priceLineVisible: false,
      priceLineColor: 'blue',
      priceLineWidth: 5,
    });

    // Initial line setup
    const lineData = [
      { time: time, value: price },
      { time: time + extendedtime, value: price }
    ];

    this.buylineSeries.setData(lineData);
    this.buylineSeries.setMarkers([
      {
        time: time,
        position: 'aboveBar',
        color: 'blue',
        text: `R-R: ${this.RRR}\nEntry: ${price.toFixed(2)}`,
        size: 2
      },
    ]);

    // Enable dragging functionality
    this.EntryPrice = price;
    this.EntryTime = time;
    this.makeLineDraggable(price, time, extendedtime);
  }

  makeLineDraggable(initialPrice: number, initialStartTime: any, initialEndTime: any) {
    let isDragging = false;
    let currentPrice = initialPrice;
    let currentStartTime = initialStartTime;
    let currentEndTime = initialEndTime;
    let clickOffsetPrice = 0;
    let clickOffsetTime = 0;
    const pixelThreshold = 6; // Replaces clickThreshold in price units
    const chartElement = document.getElementById("chart-container_new");

    const disableChartInteractions = () => {
      this.chart.applyOptions({ handleScroll: false, handleScale: false });
    };

    const enableChartInteractions = () => {
      this.chart.applyOptions({ handleScroll: true, handleScale: true });
    };

    chartElement?.addEventListener("mousedown", (event) => {
      const chartRect = chartElement.getBoundingClientRect();
      const yCoordinate = event.clientY - chartRect.top;
      const xCoordinate = event.clientX - chartRect.left;

      const mousePrice = this.buylineSeries.coordinateToPrice(yCoordinate);
      const mouseTime = this.chart.timeScale().coordinateToTime(xCoordinate);
      const lineY = this.buylineSeries.priceToCoordinate(currentPrice);

      if (
        Math.abs(yCoordinate - lineY) < pixelThreshold &&
        mouseTime >= currentStartTime && mouseTime <= currentEndTime
      ) {
        isDragging = true;
        clickOffsetPrice = currentPrice - mousePrice;
        clickOffsetTime = currentStartTime - mouseTime;
        disableChartInteractions();
      }
    });

    chartElement?.addEventListener("mousemove", (event) => {
      if (!isDragging) return;

      const chartRect = chartElement.getBoundingClientRect();
      const yCoordinate = event.clientY - chartRect.top;
      const xCoordinate = event.clientX - chartRect.left;

      let newPrice = this.buylineSeries.coordinateToPrice(yCoordinate) + clickOffsetPrice;
      let newTime = this.chart.timeScale().coordinateToTime(xCoordinate) + clickOffsetTime;

      this.buylineSeries.setData([
        { time: currentStartTime, value: newPrice },
        { time: currentEndTime, value: newPrice }
      ]);



      this.updateModelPredictionFlag = true;
      currentPrice = newPrice;
      currentStartTime = newTime;
      this.EntryPrice = newPrice;
      // this.UpdateTradeFlag=true;
      this.EntryTime = newTime;
      this.fincreateformForPanel.patchValue({
        entry_price: this.EntryPrice.toFixed(2),
      });
      const RRR = this.calculateRRR();
      this.buylineSeries.setMarkers([
        {
          time: newTime,
          position: 'aboveBar',
          color: 'green',
          text: `R-R: ${this.RRR}\nEntry: ${newPrice.toFixed(2)}`,
        }
      ]);
      this.updateMarkers(this.EntryPrice, RRR, this.EntryTime);
    });

    chartElement?.addEventListener("mouseup", () => {
      if (isDragging) {
        isDragging = false;
        enableChartInteractions();
      }
    });

    chartElement?.addEventListener("mouseleave", () => {
      if (isDragging) {
        isDragging = false;
        enableChartInteractions();
      }
    });
  }

  addTargetPriceLine(price: number, time: any, extendedtime: any) {
    this.targetlineSeries = this.chart.addLineSeries({
      color: 'green',
      lineWidth: 2,
      priceLineVisible: false,
      priceLineColor: 'green',
      priceLineWidth: 2,
    });

    this.targetlineSeries.setData([
      { time: time, value: price },
      { time: extendedtime, value: price }
    ]);

    this.targetlineSeries.setMarkers([
      {
        time: time,
        position: 'aboveBar',
        color: 'green',
        text: `Target : ${price.toFixed(2)}`
      }
    ]);
    this.TargetPrice = price;
    // Make the target price line draggable
    this.makeTargetLineDraggable(price, time, extendedtime);
  }

  makeTargetLineDraggable(initialPrice: number, initialStartTime: any, initialEndTime: any) {
    let isDragging = false;
    let currentPrice = initialPrice;
    let currentStartTime = initialStartTime;
    let currentEndTime = initialEndTime;
    let clickOffsetPrice = 0;
    let clickOffsetTime = 0;
    const pixelThreshold = 6; // Replaces clickThreshold in price units
    const chartElement = document.getElementById("chart-container_new");

    // Disable chart panning, scrolling, and auto-scaling
    const disableChartInteractions = () => {
      this.chart.applyOptions({
        handleScroll: false,
        handleScale: false,
        priceScale: {
          autoScale: false,
          mode: 1,
          lockScale: true,
        },
      });
    };

    // Enable chart panning, scrolling, and auto-scaling
    const enableChartInteractions = () => {
      this.chart.applyOptions({
        handleScroll: true,
        handleScale: true,
        priceScale: {
          autoScale: true,
        },
      });
    };

    // Event handler when mouse button is pressed
    chartElement?.addEventListener("mousedown", (event) => {
      const chartRect = chartElement.getBoundingClientRect();
      const yCoordinate = event.clientY - chartRect.top;
      const xCoordinate = event.clientX - chartRect.left;

      const mousePrice = this.targetlineSeries.coordinateToPrice(yCoordinate);
      const mouseTime = this.chart.timeScale().coordinateToTime(xCoordinate);
      const lineY = this.targetlineSeries.priceToCoordinate(currentPrice);

      if (
        Math.abs(yCoordinate - lineY) < pixelThreshold &&
        mouseTime >= currentStartTime && mouseTime <= currentEndTime
      ) {
        isDragging = true;
        clickOffsetPrice = currentPrice - mousePrice;
        clickOffsetTime = currentStartTime - mouseTime;
        disableChartInteractions();
      }
    });

    // Event handler for mouse movement
    chartElement?.addEventListener("mousemove", (event) => {
      if (!isDragging) return;

      const chartRect = chartElement.getBoundingClientRect();
      const yCoordinate = event.clientY - chartRect.top;
      const xCoordinate = event.clientX - chartRect.left;

      const newPrice = this.targetlineSeries.coordinateToPrice(yCoordinate) + clickOffsetPrice;
      const newTime = this.chart.timeScale().coordinateToTime(xCoordinate) + clickOffsetTime;

      this.targetlineSeries.setData([
        { time: currentStartTime, value: newPrice },
        { time: currentEndTime, value: newPrice },
      ]);



      this.updateModelPredictionFlag = true;
      currentPrice = newPrice;
      currentStartTime = newTime;
      this.TargetPrice = newPrice;
      // this.UpdateTradeFlag=true;
      this.fincreateformForPanel.patchValue({
        target_price: this.TargetPrice.toFixed(2),
      });
      const RRR = this.calculateRRR();
      this.targetlineSeries.setMarkers([
        {
          time: newTime,
          position: 'aboveBar',
          color: 'green',
          text: `Target: ${newPrice.toFixed(2)}`,
        },
      ]);
      this.updateMarkers(this.EntryPrice, RRR, this.EntryTime);
    });

    // Event handler when mouse button is released
    chartElement?.addEventListener("mouseup", () => {
      if (isDragging) {
        isDragging = false;
        enableChartInteractions();
      }
    });

    // Handle when the mouse leaves the chart area
    chartElement?.addEventListener("mouseleave", () => {
      if (isDragging) {
        isDragging = false;
        enableChartInteractions();
      }
    });
  }

  addStoplossPriceLine(price: number, time: any, extendedtime: any) {
    this.stoplosslineSeries = this.chart.addLineSeries({
      color: 'red',
      lineWidth: 2,
      priceLineVisible: false,
      priceLineColor: 'red',
      priceLineWidth: 2,
    });

    this.stoplosslineSeries.setData([
      { time: time, value: price },
      { time: extendedtime, value: price }
    ]);

    this.stoplosslineSeries.setMarkers([
      {
        time: time,
        position: 'belowBar',
        color: 'red',
        text: `Stoploss : ${price.toFixed(2)}`
      }
    ]);
    this.StoplossPrice = price;
    this.makeStoplossLineDraggable(price, time, extendedtime);
  }

  makeStoplossLineDraggable(initialPrice: number, initialStartTime: any, initialEndTime: any) {
    let isDragging = false;
    let currentPrice = initialPrice;
    let currentStartTime = initialStartTime;
    let currentEndTime = initialEndTime;
    let clickOffsetPrice = 0;
    let clickOffsetTime = 0;
    const pixelThreshold = 6; // Pixel-based proximity for easier clicking
    const chartElement = document.getElementById("chart-container_new");

    const disableChartInteractions = () => {
      this.chart.applyOptions({
        handleScroll: false,
        handleScale: false,
        priceScale: {
          autoScale: false,
          mode: 1,
          lockScale: true,
        },
      });
    };

    const enableChartInteractions = () => {
      this.chart.applyOptions({
        handleScroll: true,
        handleScale: true,
        priceScale: {
          autoScale: true,
        },
      });
    };

    chartElement?.addEventListener("mousedown", (event) => {
      const chartRect = chartElement.getBoundingClientRect();
      const yCoordinate = event.clientY - chartRect.top;
      const xCoordinate = event.clientX - chartRect.left;

      const mousePrice = this.stoplosslineSeries.coordinateToPrice(yCoordinate);
      const mouseTime = this.chart.timeScale().coordinateToTime(xCoordinate);
      const lineY = this.stoplosslineSeries.priceToCoordinate(currentPrice);

      if (
        Math.abs(yCoordinate - lineY) < pixelThreshold &&
        mouseTime >= currentStartTime && mouseTime <= currentEndTime
      ) {
        isDragging = true;
        clickOffsetPrice = currentPrice - mousePrice;
        clickOffsetTime = currentStartTime - mouseTime;
        disableChartInteractions();
      }
    });

    chartElement?.addEventListener("mousemove", (event) => {
      if (!isDragging) return;

      const chartRect = chartElement.getBoundingClientRect();
      const yCoordinate = event.clientY - chartRect.top;
      const xCoordinate = event.clientX - chartRect.left;

      const newPrice = this.stoplosslineSeries.coordinateToPrice(yCoordinate) + clickOffsetPrice;
      const newTime = this.chart.timeScale().coordinateToTime(xCoordinate) + clickOffsetTime;

      this.stoplosslineSeries.setData([
        { time: currentStartTime, value: newPrice },
        { time: currentEndTime, value: newPrice },
      ]);

      this.stoplosslineSeries.setMarkers([
        {
          time: newTime,
          position: 'belowBar',
          color: 'red',
          text: `Stoploss: ${newPrice.toFixed(2)}`,
        },
      ]);

      this.updateModelPredictionFlag = true;
      currentPrice = newPrice;
      currentStartTime = newTime;
      this.StoplossPrice = newPrice;
      // this.UpdateTradeFlag=true;
      this.fincreateformForPanel.patchValue({
        stoploss_price: this.StoplossPrice.toFixed(2),
      });
      const RRR = this.calculateRRR();
      this.updateMarkers(this.EntryPrice, RRR, this.EntryTime);
    });

    chartElement?.addEventListener("mouseup", () => {
      if (isDragging) {
        isDragging = false;
        enableChartInteractions();
      }
    });

    chartElement?.addEventListener("mouseleave", () => {
      if (isDragging) {
        isDragging = false;
        enableChartInteractions();
      }
    });
  }


  entryMark(entry_timestamp: any, exit_timestamp: any, order_type: any) {
    const buyZoneMarkers = [];
    if (order_type == "Sell") {
      buyZoneMarkers.push({
        time: entry_timestamp,
        position: 'aboveBar',
        color: 'green',
        shape: 'arrowDown',
        text: "Trade Started",
      });

      // Conditionally push the exit marker if the status is not "pending"
      if (this.status !== "pending") {
        buyZoneMarkers.push({
          time: exit_timestamp,
          position: 'belowBar',
          color: 'red',
          shape: 'arrowUp',
          text: "Trade Exited",
        });
      }
    }
    else {
      // First, push the entry marker
      buyZoneMarkers.push({
        time: entry_timestamp,
        position: 'belowBar',
        color: 'green',
        shape: 'arrowUp',
        text: "Trade Started"
      });

      // Conditionally push the exit marker if the status is not "pending"
      if (this.status !== "pending") {
        buyZoneMarkers.push({
          time: exit_timestamp,
          position: 'aboveBar',
          color: 'red',
          shape: 'arrowDown',
          text: "Trade Exited"
        });
      }

    }
    if (this.selectedOptions['base_candle']) {
      this.showmsg = "Fetching Base Candle Data !";
      this.spinner.show()
      this.ModelPrediction = "";
      const fillColor = 'rgba(51,153,255,0.3)';
      const array = this.BaseCandleData[this.FullScreenModeValue];
      for (let item of array) {
        buyZoneMarkers.push({
          time: item,
          position: 'aboveBar',
          color: 'blue',
          shape: 'arrowDown',
          text: "B",
        });
      }
      this.spinner.hide()
    }
    buyZoneMarkers.sort((a, b) => a.time - b.time);
    this.candlestickSeries.setMarkers(buyZoneMarkers);
  }

  stoplossMark(entry_timestamp: any, exit_timestamp: any, order_type: any) {
    const buyZoneMarkers = [];
    if (order_type == "Sell") {
      buyZoneMarkers.push(
        {
          time: entry_timestamp,
          position: 'aboveBar',
          color: 'green',
          shape: 'arrowDown',
          text: "Trade Started",
        },
        {
          time: exit_timestamp,
          position: 'belowBar',
          color: 'red',
          shape: 'arrowUp',
          text: "Stop Loss Hit",
        }
      )
    }
    else {
      buyZoneMarkers.push(
        {
          time: entry_timestamp,
          position: 'belowBar',
          color: 'green',
          shape: 'arrowUp',
          text: "Trade Started"
        },
        {
          time: exit_timestamp,
          position: 'aboveBar',
          color: 'red',
          shape: 'arrowDown',
          text: "Stop Loss Hit"
        }
      );
    }
    if (this.selectedOptions['base_candle']) {
      this.showmsg = "Fetching Base Candle Data !";
      this.spinner.show()
      this.ModelPrediction = "";
      const fillColor = 'rgba(51,153,255,0.3)';
      const array = this.BaseCandleData[this.FullScreenModeValue];
      for (let item of array) {
        buyZoneMarkers.push({
          time: item,
          position: 'aboveBar',
          color: 'blue',
          shape: 'arrowDown',
          text: "B",
        });
      }
      this.spinner.hide()
    }
    buyZoneMarkers.sort((a, b) => a.time - b.time);
    this.candlestickSeries.setMarkers(buyZoneMarkers);
  }

  LoadChart(data: any, chartId: any) {
    //  data = data.slice(0, -1);
    let chart = null;
    const chartProperties = {
      timeScale: {
        timeVisible: true,
        secondsVisible: false,
        rightOffset: 0,
      },
      crosshair: {
        mode: CrosshairMode.Normal
      },
    }

    chart = createChart(document.getElementById(chartId)!, {
      ...chartProperties,
      layout: {
        background: {
          color: '#f0ffff',
        },
      },
    });

    chart.applyOptions({
      watermark: {
        visible: true,
        fontSize: 20,
        horzAlign: 'left',
        vertAlign: 'top',
        color: 'rgb(128, 128, 128)',
        text: this.SelectedStockName.toUpperCase() + " | " + this.ModalHeader.toUpperCase() + " | " + this.selectedTradeType.toUpperCase(),
      },
      grid: {
        vertLines: { visible: false },
        horzLines: { visible: false },
      },
    });

    this.areaSeries = chart.addAreaSeries({
      lineColor: '#2962FF', topColor: '#2962FF',
      bottomColor: 'rgba(41, 98, 255, 0.28)',
    });

    this.candlestickSeries = chart.addCandlestickSeries({
      upColor: '#1B880C', downColor: '#D90000', borderVisible: false,
      wickUpColor: '#26a69a', wickDownColor: '#ef5350',
    });

    const postbars = [...new Array(100)].map((_, i) => ({
      time: data[data.length - 1].time + (i + 1) * this.xspan,
    }));

    // Adjust the price scale to "squeeze" the chart vertically, increasing candle height
    chart.priceScale('right').applyOptions({
      scaleMargins: {
        top: 0.01, // Reduce the top margin for the price scale
        bottom: 0.01, // Reduce the bottom margin to squeeze candles vertically
      },
      autoScale: true, // Ensure auto-scaling continues to work
    });

    const now = new Date();
    const dayOfWeek = now.getDay();
    const hours = now.getHours();
    const minutes = now.getMinutes();
    // this.candlestickSeries.setData([...data]);
    this.candlestickSeries.setData([...data, ...postbars]);

    chart.timeScale().fitContent();
    this.rectangleTool = new RectangleDrawingTool(chart,
      this.candlestickSeries,
      document.querySelector<HTMLDivElement>('#toolbar')!,
      {
        showLabels: false,
      });
    // EMA
    const maData = this.calculateMovingAverageSeriesData(data, 20);

    const maSeries = chart.addLineSeries({ color: '#2962FF', lineWidth: 1 });
    maSeries.setData(maData);

    // const candlestickSeries = chart.addCandlestickSeries({
    //   upColor: '#1B880C',
    //   downColor: '#D90000',
    //   borderVisible: false,
    //   wickUpColor: '#26a69a',
    //   wickDownColor: '#ef5350',
    // });
    // candlestickSeries.setData(data);
    // EMA END

    // TOOLTIP START
    chart.subscribeCrosshairMove(param => {
      if (param.time) {
        const seriesPrices = param.seriesData.get(this.candlestickSeries);
        if (seriesPrices) {
          this.toolTipData = seriesPrices;
          this.Open = this.toolTipData.open.toFixed(2);
          this.Close = this.toolTipData.close.toFixed(2);
          this.High = this.toolTipData.high.toFixed(2);
          this.Low = this.toolTipData.low.toFixed(2);
          if (this.Close > this.Open) {
            this.CandleColor = "green";
          } else {
            this.CandleColor = "red";
          }
        }
        else {
          this.Open = "";
          this.Close = "";
          this.High = "";
          this.Low = "";
        }
      }
    });
    // TOOLTIP END
    this.chart = chart;
    const lastRow = data.slice(-1)[0];
    this.CreateClosingLine(lastRow.close)
  }

  CreateClosingLine(price: any) {
    if (this.lastCMPLine) {
      this.candlestickSeries.removePriceLine(this.lastCMPLine);
    }
    const ClosingPrice = price;
    const ClosingPriceLine = {
      price: ClosingPrice,
      color: 'green',
      lineWidth: 1,
      lineStyle: 1,
      axisLabelVisible: true,
      title: 'CMP',
    };
    this.lastCMPLine = this.candlestickSeries.createPriceLine(ClosingPriceLine);
  }

  calculateMovingAverageSeriesData(candleData: any, maLength: any) {
    const maData = [];
    for (let i = 0; i < candleData.length; i++) {
      if (i < maLength) {
        maData.push({ time: candleData[i].time });
      } else {
        let sum = 0;
        for (let j = 0; j < maLength; j++) {
          sum += candleData[i - j].close;
        }
        const maValue = sum / maLength;
        maData.push({ time: candleData[i].time, value: maValue });
      }
    }
    return maData;
  }

  // toggleBar() {
  //   const leftBar = document.getElementById('leftBar');
  //   if (leftBar) {
  //     const windowHeight: number = window.innerHeight;
  //     const targetHeight: number = 80;
  //     leftBar.style.top = `${targetHeight}px`;
  //     leftBar.style.height = `${windowHeight - targetHeight}px`;
  //     leftBar.style.overflowY = 'auto';
  //     if (leftBar.classList.contains('open')) {
  //       leftBar.classList.remove('open');
  //     } else {
  //       leftBar.classList.add('open');
  //     }
  //   }
  // }


  // openBar(isOpen: boolean) {
  //   const leftPanel = document.getElementById('leftPanel');
  //   if (leftPanel) {
  //     leftPanel.classList.remove('open');
  //   }

  //   const leftBar = document.getElementById('leftBar');
  //   if (!leftBar) return;

  //   if (isOpen) {
  //     const windowHeight: number = window.innerHeight;
  //     const targetHeight: number = 80;
  //     leftBar.style.top = `${targetHeight}px`;
  //     leftBar.style.height = `${windowHeight - targetHeight}px`;
  //     leftBar.style.overflowY = 'auto';
  //     leftBar.classList.add('open');
  //   } else {
  //     leftBar.classList.remove('open');
  //   }
  // }

  openBar(isOpen: boolean): void {
    this.isLeftBarOpen = isOpen;
  }

  toggleLeftBar(): void {
    if (window.innerWidth <= 767.98) {
      this.isLeftBarOpen = !this.isLeftBarOpen;
    } else {
      this.isLeftBarOpen = true;
    }
  }

  handleSettingsEnter(): void {
    if (window.innerWidth > 767.98) {
      this.openBar(true);
    }
  }

  handleSettingsLeave(): void {
    // keep empty or remove this if not needed
  }

  handleLeftBarEnter(): void {
    if (window.innerWidth > 767.98) {
      this.openBar(true);
    }
  }

  handleLeftBarLeave(): void {
    if (window.innerWidth > 767.98) {
      this.openBar(false);
    }
  }




  // closeBar() {
  //   const leftBar = document.getElementById('leftBar');
  //   if (leftBar) {
  //     leftBar.classList.remove('open');  // CLOSE
  //   }
  // }

  CloseFullModal() {
    this.UpdateTradeFlag = false;
    this.isNotificationVisible = false;
    this.ModelPrediction = "";
    this.cleanupChart();
    this.disconnectWebSocket()
    // this.selectedOption = '';
    this.dropdownShow = false;
    this.selectedOptions = {
      base_candle: false,
      buy_sell_zone: false,
      bad_zone: false,
      setup: false,
    };
    const leftBar = document.getElementById('leftBar');
    if (leftBar!.classList.contains('open')) {
      leftBar!.classList.remove('open');
    }
    this.modalalert.hide();
    this.submitStock = false;
  }

  cleanupChart() {
    if (this.chart) {
      this.chart.remove();
      this.chart = null;
    }
  }

  GetChartData(stock_name: any, time_frame: any) {
    const currentDateTime = moment();
    const last_d_time = currentDateTime.format("YYYY-MM-DD HH:mm:ss");
    let obj = {
      tick: stock_name,
      time_frame: time_frame,
      last_d_time: last_d_time
    }
    this.apiService.fetchCandleData(obj).subscribe(resp => {

    })
  }

  checkOptions(): boolean {
    for (let key in this.selectedOptions) {
      if (this.selectedOptions[key]) {
        return false;
      }
    }
    return true;
  }

  private getZoneBounds(zone: any[]) {
    if (!Array.isArray(zone) || zone.length < 2) {
      return null;
    }

    const p1 = zone[0];
    const p2 = zone[1];

    return {
      startTime: Math.min(p1.time, p2.time),
      endTime: Math.max(p1.time, p2.time),
      bottom: Math.min(p1.price, p2.price),
      top: Math.max(p1.price, p2.price)
    };
  }

  isOverlapping(zone1: any[], zone2: any[]): boolean {
    const z1 = this.getZoneBounds(zone1);
    const z2 = this.getZoneBounds(zone2);

    if (!z1 || !z2) {
      return false;
    }

    const priceOverlap =
      z1.top >= z2.bottom &&
      z2.top >= z1.bottom;

    const timeOverlap =
      z1.startTime <= z2.endTime &&
      z2.startTime <= z1.endTime;

    return priceOverlap && timeOverlap;
  }

  markOverlappingZones(zones: any[]) {
    const overlappingIndexes = new Set<number>();

    for (let i = 0; i < zones.length; i++) {
      for (let j = i + 1; j < zones.length; j++) {
        if (this.isOverlapping(zones[i], zones[j])) {
          overlappingIndexes.add(i);
          overlappingIndexes.add(j);

          console.log('Overlap found:', i, j);
          console.log('Zone 1:', this.getZoneBounds(zones[i]));
          console.log('Zone 2:', this.getZoneBounds(zones[j]));
        }
      }
    }

    return overlappingIndexes;
  }

  checkboxClicked(option: string) {
    const buyfillColor = 'rgba(16, 185, 129, 0.10)';
    const buyoutlineColor = '#059669';
    const buytextColor = '#065f46';
    const sellfillColor = 'rgba(225, 29, 72, 0.10)';
    const selloutlineColor = '#be123c';
    const selltextColor = '#881337';
    this.candlestickSeries.setMarkers([]);
    this.selectedOptions[option] = !this.selectedOptions[option];
    let result = this.checkOptions();
    if (result == false) {
      this.rectangleTool.removeAllRectangles()

      if (this.selectedOptions['score']) {
        const buyfillColor = 'rgba(0, 255, 0, 0)';
        const buytextColor = '#08431d';

        const sellfillColor = 'rgba(255, 51, 51, 0)';
        const selltextColor = '#991b1b';

        const buyZones = this.ScoreData?.ZONES_X?.Buy || [];
        const sellZones = this.ScoreData?.ZONES_X?.Sell || [];

        if (buyZones.length > 0) {
          for (const item of buyZones) {
            this.rectangleTool.addRectanglesFromData(item.range, {
              fillColor: buyfillColor,
              text: `${item.meta?.final_weighted_score ?? ''}`,
              textColor: buytextColor
            });
          }
        }

        if (sellZones.length > 0) {
          for (const item of sellZones) {
            this.rectangleTool.addRectanglesFromData(item.range, {
              fillColor: sellfillColor,
              text: `${item.meta?.final_weighted_score ?? ''}`,
              textColor: selltextColor
            });
          }
        }
      }

      // if (this.selectedOptions['qualified_zones']) {
      //   this.showmsg = "Fetching All Zones Data !";
      //   const buy_array = this.QualifiedData["Buy"];
      //   const fillColorBuy = 'rgba(0,255,0,0.2)';
      //   for (let item of Object.values(buy_array)) {
      //     this.rectangleTool.addRectanglesFromData(item,{ fillColor: fillColorBuy });
      //   }
      //   const fillColorSell = 'rgba(255,51,51,0.2)';
      //   var sell_array = this.QualifiedData["Sell"];
      //   for (let item of Object.values(sell_array)) {
      //     this.rectangleTool.addRectanglesFromData(item, { fillColor: fillColorSell });
      //   }

      // }

      if (this.selectedOptions['qualified_zones']) {
        this.showmsg = "Fetching All Zones Data !";

        const buy_array = Object.values(this.QualifiedData["Buy"] || {});
        const sell_array = Object.values(this.QualifiedData["Sell"] || {});

        const buyOverlap = this.markOverlappingZones(buy_array);
        const sellOverlap = this.markOverlappingZones(sell_array);

        // BUY zones
        buy_array.forEach((item: any, index: number) => {
          const isOverlap = buyOverlap.has(index);

          this.rectangleTool.addRectanglesFromData(item, {
            fillColor: isOverlap
              ? 'rgba(0, 200, 120, 0.35)'   // overlap green shade
              : 'rgba(0,255,0,0.2)',        // normal green
            outlineColor: isOverlap
              ? 'rgba(0, 255, 170, 0.95)'   // bright outline
              : 'rgba(0, 255, 0, 0.45)',
            outlineWidth: isOverlap ? 1 : 0
          });
        });

        // SELL zones
        sell_array.forEach((item: any, index: number) => {
          const isOverlap = sellOverlap.has(index);

          this.rectangleTool.addRectanglesFromData(item, {
            fillColor: isOverlap
              ? 'rgba(220, 38, 38, 0.35)'   // overlap sell
              : 'rgba(255, 51, 51, 0.2)',   // normal sell
            outlineColor: isOverlap
              ? 'rgba(153, 27, 27, 1)'      // dark red outline
              : 'rgba(255, 51, 51, 0.45)',
            outlineWidth: isOverlap ? 1 : 0
          });
        });
      }

      if (this.selectedOptions['all_zones']) {
        this.showmsg = "Fetching All Zones Data !";
        const array = this.AllZonesData[this.FullScreenModeValue];
        const fillColorBuy = 'rgba(50,50,50,0.5)';
        var buy_array = array['Buy'];
        for (let item of Object.values(buy_array)) {
          this.rectangleTool.addRectanglesFromData(item, { fillColor: fillColorBuy });
        }
        const fillColorSell = 'rgba(50,50,50,0.5)';
        var sell_array = array['Sell'];
        for (let item of Object.values(sell_array)) {
          this.rectangleTool.addRectanglesFromData(item, { fillColor: fillColorSell });
        }
        // this.getsetup(this.purchased_date, this.entry_timestamp, this.entry_price, this.stoploss_price, this.target_price)
      }

      if (this.selectedOptions['base_candle']) {
        this.showmsg = "Fetching Base Candle Data !";
        const BaseMarkers = [];
        const fillColor = 'rgba(51,153,255,0.3)';
        const array = this.BaseCandleData[this.FullScreenModeValue];
        for (let item of array) {
          BaseMarkers.push({
            time: item,
            position: 'aboveBar',
            color: 'blue',
            shape: 'arrowDown',
            text: "B",
          });
        }
        this.candlestickSeries.setMarkers(BaseMarkers);
        // this.getsetup(this.purchased_date, this.entry_timestamp, this.entry_price, this.stoploss_price, this.target_price)
      }

      if (this.selectedOptions['buy_sell_zone']) {
        this.showmsg = "Fetching Buy/Sell Zone !";
        const fillColorBuy = 'rgba(0,255,0,0.2)';
        var buy_array = this.BuyZoneData[this.FullScreenModeValue];
        for (let item of Object.values(buy_array)) {
          this.rectangleTool.addRectanglesFromData(item, { fillColor: fillColorBuy });
        }
        const fillColorSell = 'rgba(255,51,51,0.2)';
        var sell_array = this.SellZoneData[this.FullScreenModeValue];
        for (let item of Object.values(sell_array)) {
          this.rectangleTool.addRectanglesFromData(item, { fillColor: fillColorSell });
        }
        // this.getsetup(this.purchased_date, this.entry_timestamp, this.entry_price, this.stoploss_price, this.target_price)
      }

      if (this.selectedOptions['bad_zone']) {
        let array = this.BadZoneData[this.FullScreenModeValue]
        const fillColor = "rgba(41, 3, 3, 0.21)"
        for (let item of Object.values(array)) {
          this.rectangleTool.addRectanglesFromData(item, { fillColor: fillColor });
        }
        // this.getsetup(this.purchased_date, this.entry_timestamp, this.entry_price, this.stoploss_price, this.target_price)
      }

      if (this.selectedOptions['optimized_buy_sell_zone']) {
        const fillColorBuy = 'rgba(0,255,0,0.2)';
        console.log(this.FullScreenModeValue);
        var buy_array = this.OptimizedBuySellZoneData[this.FullScreenModeValue];
        console.log("BUY", buy_array.BUY);
        for (let item of Object.values(buy_array.Buy)) {
          this.rectangleTool.addRectanglesFromData(item, { fillColor: fillColorBuy });
        }
        const fillColorSell = 'rgba(255,51,51,0.2)';
        var sell_array = this.OptimizedBuySellZoneData[this.FullScreenModeValue];
        console.log("SELL", sell_array);
        for (let item of Object.values(sell_array.Sell)) {
          this.rectangleTool.addRectanglesFromData(item, { fillColor: fillColorSell });
        }
      }

      if (this.selectedOptions['overlap_evaluate']) {

        if (this.SelectedExchange_Name == "NSE") {

          if (this.finData.time_frame == 1) {
            var buy_array = this.BuyOverlayData['monthly'];
            for (let item of Object.values(buy_array)) {
              this.rectangleTool.addRectanglesFromData(item, { fillColor: buyfillColor, outlineColor: buyoutlineColor, outlineWidth: 0.5, text: "Monthly", textColor: buytextColor });
            }
            var sell_array = this.SellOverlayData['monthly'];
            for (let item of Object.values(sell_array)) {
              this.rectangleTool.addRectanglesFromData(item, { fillColor: sellfillColor, outlineColor: selloutlineColor, outlineWidth: 0.5, text: "Monthly", textColor: selltextColor });
            }
            // this.getsetup(this.purchased_date, this.entry_timestamp, this.completed_on, this.entry_price, this.stoploss_price, this.target_price, this.order_type)
          }

          if (this.finData.time_frame == 2) {
            var buy_array = this.BuyOverlayData['weekly'];
            for (let item of Object.values(buy_array)) {
              this.rectangleTool.addRectanglesFromData(item, { fillColor: buyfillColor, outlineColor: buyoutlineColor, outlineWidth: 0.5, text: "Weekly", textColor: buytextColor });
            }
            var sell_array = this.SellOverlayData['weekly'];
            for (let item of Object.values(sell_array)) {
              this.rectangleTool.addRectanglesFromData(item, { fillColor: sellfillColor, outlineColor: selloutlineColor, outlineWidth: 0.5, text: "Weekly", textColor: selltextColor });
            }
            // this.getsetup(this.purchased_date, this.entry_timestamp, this.completed_on, this.entry_price, this.stoploss_price, this.target_price, this.order_type)
          }

          if (this.finData.time_frame == 3) {
            var buy_array = this.BuyOverlayData['daily'];
            for (let item of Object.values(buy_array)) {
              this.rectangleTool.addRectanglesFromData(item, { fillColor: buyfillColor, outlineColor: buyoutlineColor, outlineWidth: 0.5, text: "Daily", textColor: buytextColor });
            }
            var sell_array = this.SellOverlayData['daily'];
            for (let item of Object.values(sell_array)) {
              this.rectangleTool.addRectanglesFromData(item, { fillColor: sellfillColor, outlineColor: selloutlineColor, outlineWidth: 0.5, text: "Daily", textColor: selltextColor });
            }
            // this.getsetup(this.purchased_date, this.entry_timestamp, this.completed_on, this.entry_price, this.stoploss_price, this.target_price, this.order_type)
          }

          if (this.finData.time_frame == 25) {
            var buy_array = this.BuyOverlayData['weekly'];
            for (let item of Object.values(buy_array)) {
              this.rectangleTool.addRectanglesFromData(item, { fillColor: buyfillColor, outlineColor: buyoutlineColor, outlineWidth: 0.5, text: "Weekly", textColor: buytextColor });
            }

            var sell_array = this.SellOverlayData['weekly'];
            for (let item of Object.values(sell_array)) {
              this.rectangleTool.addRectanglesFromData(item, { fillColor: sellfillColor, outlineColor: selloutlineColor, outlineWidth: 0.5, text: "Weekly", textColor: selltextColor });
            }
            // this.getsetup(this.purchased_date, this.entry_timestamp, this.completed_on, this.entry_price, this.stoploss_price, this.target_price, this.order_type)
          }

          if (this.finData.time_frame == 5) {
            var buy_array = this.BuyOverlayData['weekly'];
            for (let item of Object.values(buy_array)) {
              this.rectangleTool.addRectanglesFromData(item, { fillColor: buyfillColor, outlineColor: buyoutlineColor, outlineWidth: 0.5, text: "Weekly", textColor: buytextColor });
            }
            var sell_array = this.SellOverlayData['weekly'];
            for (let item of Object.values(sell_array)) {
              this.rectangleTool.addRectanglesFromData(item, { fillColor: sellfillColor, outlineColor: selloutlineColor, outlineWidth: 0.5, text: "Weekly", textColor: selltextColor });
            }
            // this.getsetup(this.purchased_date, this.entry_timestamp, this.completed_on, this.entry_price, this.stoploss_price, this.target_price, this.order_type)
          }

          if (this.finData.time_frame == 6) {
            var buy_array = this.BuyOverlayData['daily'];
            for (let item of Object.values(buy_array)) {
              this.rectangleTool.addRectanglesFromData(item, { fillColor: buyfillColor, outlineColor: buyoutlineColor, outlineWidth: 0.5, text: "Daily", textColor: buytextColor });
            }
            var sell_array = this.SellOverlayData['daily'];
            for (let item of Object.values(sell_array)) {
              this.rectangleTool.addRectanglesFromData(item, { fillColor: sellfillColor, outlineColor: selloutlineColor, outlineWidth: 0.5, text: "Daily", textColor: selltextColor });
            }
            // this.getsetup(this.purchased_date, this.entry_timestamp, this.completed_on, this.entry_price, this.stoploss_price, this.target_price, this.order_type)
          }

        }

        if (this.SelectedExchange_Name == "MCX") {

          if (this.finData.time_frame == 1) {
            var buy_array = this.BuyOverlayData['monthly'];
            for (let item of Object.values(buy_array)) {
              this.rectangleTool.addRectanglesFromData(item, { fillColor: buyfillColor, outlineColor: buyoutlineColor, outlineWidth: 0.5, text: "Monthly", textColor: buytextColor });
            }

            var sell_array = this.SellOverlayData['monthly'];
            for (let item of Object.values(sell_array)) {
              this.rectangleTool.addRectanglesFromData(item, { fillColor: sellfillColor, outlineColor: selloutlineColor, outlineWidth: 0.5, text: "Monthly", textColor: selltextColor });
            }
            // this.getsetup(this.purchased_date, this.entry_timestamp, this.completed_on, this.entry_price, this.stoploss_price, this.target_price, this.order_type)
          }

          if (this.finData.time_frame == 2) {
            var buy_array = this.BuyOverlayData['weekly'];
            for (let item of Object.values(buy_array)) {
              this.rectangleTool.addRectanglesFromData(item, { fillColor: buyfillColor, outlineColor: buyoutlineColor, outlineWidth: 0.5, text: "Weekly", textColor: buytextColor });
            }
            var sell_array = this.SellOverlayData['weekly'];
            for (let item of Object.values(sell_array)) {
              this.rectangleTool.addRectanglesFromData(item, { fillColor: sellfillColor, outlineColor: selloutlineColor, outlineWidth: 0.5, text: "Weekly", textColor: selltextColor });
            }
            // this.getsetup(this.purchased_date, this.entry_timestamp, this.completed_on, this.entry_price, this.stoploss_price, this.target_price, this.order_type)
          }

          if (this.finData.time_frame == 3) {
            var buy_array = this.BuyOverlayData['daily'];
            for (let item of Object.values(buy_array)) {
              this.rectangleTool.addRectanglesFromData(item, { fillColor: buyfillColor, outlineColor: buyoutlineColor, outlineWidth: 0.5, text: "Daily", textColor: buytextColor });
            }
            var sell_array = this.SellOverlayData['daily'];
            for (let item of Object.values(sell_array)) {
              this.rectangleTool.addRectanglesFromData(item, { fillColor: sellfillColor, outlineColor: selloutlineColor, outlineWidth: 0.5, text: "Daily", textColor: selltextColor });
            }
            // this.getsetup(this.purchased_date, this.entry_timestamp, this.completed_on, this.entry_price, this.stoploss_price, this.target_price, this.order_type)

          }

          if (this.finData.time_frame == 4) {
            var buy_array = this.BuyOverlayData['daily'];
            for (let item of Object.values(buy_array)) {
              this.rectangleTool.addRectanglesFromData(item, { fillColor: buyfillColor, outlineColor: buyoutlineColor, outlineWidth: 0.5, text: "Daily", textColor: buytextColor });
            }
            var sell_array = this.SellOverlayData['daily'];
            for (let item of Object.values(sell_array)) {
              this.rectangleTool.addRectanglesFromData(item, { fillColor: sellfillColor, outlineColor: selloutlineColor, outlineWidth: 0.5, text: "Daily", textColor: selltextColor });
            }
            // this.getsetup(this.purchased_date, this.entry_timestamp, this.completed_on, this.entry_price, this.stoploss_price, this.target_price, this.order_type)

          }
        }

        if (this.SelectedExchange_Name == "NSEFO") {

          if (this.finData.time_frame == 1) {
            var buy_array = this.BuyOverlayData['monthly'];
            for (let item of Object.values(buy_array)) {
              this.rectangleTool.addRectanglesFromData(item, { fillColor: buyfillColor, outlineColor: buyoutlineColor, outlineWidth: 0.5, text: "Monthly", textColor: buytextColor });
            }
            var sell_array = this.SellOverlayData['monthly'];
            for (let item of Object.values(sell_array)) {
              this.rectangleTool.addRectanglesFromData(item, { fillColor: sellfillColor, outlineColor: selloutlineColor, outlineWidth: 0.5, text: "Monthly", textColor: selltextColor });
            }
            // this.getsetup(this.purchased_date, this.entry_timestamp, this.completed_on, this.entry_price, this.stoploss_price, this.target_price, this.order_type)
          }

          if (this.finData.time_frame == 2) {
            var buy_array = this.BuyOverlayData['weekly'];
            for (let item of Object.values(buy_array)) {
              this.rectangleTool.addRectanglesFromData(item, { fillColor: buyfillColor, outlineColor: buyoutlineColor, outlineWidth: 0.5, text: "Weekly", textColor: buytextColor });
            }
            var sell_array = this.SellOverlayData['weekly'];
            for (let item of Object.values(sell_array)) {
              this.rectangleTool.addRectanglesFromData(item, { fillColor: sellfillColor, outlineColor: selloutlineColor, outlineWidth: 0.5, text: "Weekly", textColor: selltextColor });
            }
            // this.getsetup(this.purchased_date, this.entry_timestamp, this.completed_on, this.entry_price, this.stoploss_price, this.target_price, this.order_type)
          }

          if (this.finData.time_frame == 3) {
            var buy_array = this.BuyOverlayData['daily'];
            for (let item of Object.values(buy_array)) {
              this.rectangleTool.addRectanglesFromData(item, { fillColor: buyfillColor, outlineColor: buyoutlineColor, outlineWidth: 0.5, text: "Daily", textColor: buytextColor });
            }
            var sell_array = this.SellOverlayData['daily'];
            for (let item of Object.values(sell_array)) {
              this.rectangleTool.addRectanglesFromData(item, { fillColor: sellfillColor, outlineColor: selloutlineColor, outlineWidth: 0.5, text: "Daily", textColor: selltextColor });
            }
            // this.getsetup(this.purchased_date, this.entry_timestamp, this.completed_on, this.entry_price, this.stoploss_price, this.target_price, this.order_type)
          }

          if (this.finData.time_frame == 25) {

            var buy_array = this.BuyOverlayData['weekly'];
            for (let item of Object.values(buy_array)) {
              this.rectangleTool.addRectanglesFromData(item, { fillColor: buyfillColor, outlineColor: buyoutlineColor, outlineWidth: 0.5, text: "Weekly", textColor: buytextColor });
            }
            var sell_array = this.SellOverlayData['weekly'];
            for (let item of Object.values(sell_array)) {
              this.rectangleTool.addRectanglesFromData(item, { fillColor: sellfillColor, outlineColor: selloutlineColor, outlineWidth: 0.5, text: "Weekly", textColor: selltextColor });
            }
            // this.getsetup(this.purchased_date, this.entry_timestamp, this.completed_on, this.entry_price, this.stoploss_price, this.target_price, this.order_type)
          }

        }

      }

      if (this.selectedOptions['overlap_analyze']) {

        if (this.SelectedExchange_Name == "NSE") {

          if (this.finData.time_frame == 1) {
            var buy_array = this.BuyOverlayData['weekly'];
            for (let item of Object.values(buy_array)) {
              this.rectangleTool.addRectanglesFromData(item, { fillColor: buyfillColor, outlineColor: buyoutlineColor, outlineWidth: 0.5, text: "Weekly", textColor: buytextColor });
            }
            var sell_array = this.SellOverlayData['weekly'];
            for (let item of Object.values(sell_array)) {
              this.rectangleTool.addRectanglesFromData(item, { fillColor: sellfillColor, outlineColor: selloutlineColor, outlineWidth: 0.5, text: "Weekly", textColor: selltextColor });
            }
            // this.getsetup(this.purchased_date, this.entry_timestamp, this.entry_price, this.stoploss_price, this.target_price)
          }

          if (this.finData.time_frame == 2) {
            var buy_array = this.BuyOverlayData['daily'];
            for (let item of Object.values(buy_array)) {
              this.rectangleTool.addRectanglesFromData(item, { fillColor: buyfillColor, outlineColor: buyoutlineColor, outlineWidth: 0.5, text: "Daily", textColor: buytextColor });
            }
            var sell_array = this.SellOverlayData['daily'];
            for (let item of Object.values(sell_array)) {
              this.rectangleTool.addRectanglesFromData(item, { fillColor: sellfillColor, outlineColor: selloutlineColor, outlineWidth: 0.5, text: "Daily", textColor: selltextColor });
            }
            // this.getsetup(this.purchased_date, this.entry_timestamp, this.entry_price, this.stoploss_price, this.target_price)
          }

          if (this.finData.time_frame == 3) {
            var buy_array = this.BuyOverlayData['sixty'];
            for (let item of Object.values(buy_array)) {
              this.rectangleTool.addRectanglesFromData(item, { fillColor: buyfillColor, outlineColor: buyoutlineColor, outlineWidth: 0.5, text: "60 Min", textColor: buytextColor });
            }
            var sell_array = this.SellOverlayData['sixty'];
            for (let item of Object.values(sell_array)) {
              this.rectangleTool.addRectanglesFromData(item, { fillColor: sellfillColor, outlineColor: selloutlineColor, outlineWidth: 0.5, text: "60 Min", textColor: selltextColor });
            }
            // this.getsetup(this.purchased_date, this.entry_timestamp, this.entry_price, this.stoploss_price, this.target_price)
          }

          if (this.finData.time_frame == 25) {
            var buy_array = this.BuyOverlayData['daily'];
            for (let item of Object.values(buy_array)) {
              this.rectangleTool.addRectanglesFromData(item, { fillColor: buyfillColor, outlineColor: buyoutlineColor, outlineWidth: 0.5, text: "Daily", textColor: buytextColor });
            }
            var sell_array = this.SellOverlayData['daily'];
            for (let item of Object.values(sell_array)) {
              this.rectangleTool.addRectanglesFromData(item, { fillColor: sellfillColor, outlineColor: selloutlineColor, outlineWidth: 0.5, text: "Daily", textColor: selltextColor });
            }
            // this.getsetup(this.purchased_date, this.entry_timestamp, this.completed_on, this.entry_price, this.stoploss_price, this.target_price, this.order_type)
          }

          if (this.finData.time_frame == 5) {
            var buy_array = this.BuyOverlayData['daily'];
            for (let item of Object.values(buy_array)) {
              this.rectangleTool.addRectanglesFromData(item, { fillColor: buyfillColor, outlineColor: buyoutlineColor, outlineWidth: 0.5, text: "Daily", textColor: buytextColor });
            }
            var sell_array = this.SellOverlayData['daily'];
            for (let item of Object.values(sell_array)) {
              this.rectangleTool.addRectanglesFromData(item, { fillColor: sellfillColor, outlineColor: selloutlineColor, outlineWidth: 0.5, text: "Daily", textColor: selltextColor });
            }
            // this.getsetup(this.purchased_date, this.entry_timestamp, this.entry_price, this.stoploss_price, this.target_price)
          }

          if (this.finData.time_frame == 6) {
            var buy_array = this.BuyOverlayData['one_twenty_five'];
            for (let item of Object.values(buy_array)) {
              this.rectangleTool.addRectanglesFromData(item, { fillColor: buyfillColor, outlineColor: buyoutlineColor, outlineWidth: 0.5, text: "125 Min", textColor: buytextColor });
            }
            var sell_array = this.SellOverlayData['one_twenty_five'];
            for (let item of Object.values(sell_array)) {
              this.rectangleTool.addRectanglesFromData(item, { fillColor: sellfillColor, outlineColor: selloutlineColor, outlineWidth: 0.5, text: "125 Min", textColor: selltextColor });
            }
            // this.getsetup(this.purchased_date, this.entry_timestamp, this.entry_price, this.stoploss_price, this.target_price)
          }
        }

        if (this.SelectedExchange_Name == "MCX") {

          if (this.finData.time_frame == 1) {
            var buy_array = this.BuyOverlayData['weekly'];
            for (let item of Object.values(buy_array)) {
              this.rectangleTool.addRectanglesFromData(item, { fillColor: buyfillColor, outlineColor: buyoutlineColor, outlineWidth: 0.5, text: "Weekly", textColor: buytextColor });
            }
            var sell_array = this.SellOverlayData['weekly'];
            for (let item of Object.values(sell_array)) {
              this.rectangleTool.addRectanglesFromData(item, { fillColor: sellfillColor, outlineColor: selloutlineColor, outlineWidth: 0.5, text: "Weekly", textColor: selltextColor });
            }
            // this.getsetup(this.purchased_date, this.entry_timestamp, this.entry_price, this.stoploss_price, this.target_price)
          }

          if (this.finData.time_frame == 2) {
            var buy_array = this.BuyOverlayData['daily'];
            for (let item of Object.values(buy_array)) {
              this.rectangleTool.addRectanglesFromData(item, { fillColor: buyfillColor, outlineColor: buyoutlineColor, outlineWidth: 0.5, text: "Daily", textColor: buytextColor });
            }
            var sell_array = this.SellOverlayData['daily'];
            for (let item of Object.values(sell_array)) {
              this.rectangleTool.addRectanglesFromData(item, { fillColor: sellfillColor, outlineColor: selloutlineColor, outlineWidth: 0.5, text: "Daily", textColor: selltextColor });
            }
            // this.getsetup(this.purchased_date, this.entry_timestamp, this.entry_price, this.stoploss_price, this.target_price)
          }

          if (this.finData.time_frame == 3) {
            var buy_array = this.BuyOverlayData['two_forty'];
            for (let item of Object.values(buy_array)) {
              this.rectangleTool.addRectanglesFromData(item, { fillColor: buyfillColor, outlineColor: buyoutlineColor, outlineWidth: 0.5, text: "240 Min", textColor: buytextColor });
            }
            var sell_array = this.SellOverlayData['two_forty'];
            for (let item of Object.values(sell_array)) {
              this.rectangleTool.addRectanglesFromData(item, { fillColor: sellfillColor, outlineColor: selloutlineColor, outlineWidth: 0.5, text: "240 Min", textColor: selltextColor });
            }
            // this.getsetup(this.purchased_date, this.entry_timestamp, this.entry_price, this.stoploss_price, this.target_price)
          }

          if (this.finData.time_frame == 4) {
            var buy_array = this.BuyOverlayData['two_forty'];
            for (let item of Object.values(buy_array)) {
              this.rectangleTool.addRectanglesFromData(item, { fillColor: buyfillColor, outlineColor: buyoutlineColor, outlineWidth: 0.5, text: "240 Min", textColor: buytextColor });
            }
            var sell_array = this.SellOverlayData['two_forty'];
            for (let item of Object.values(sell_array)) {
              this.rectangleTool.addRectanglesFromData(item, { fillColor: sellfillColor, outlineColor: selloutlineColor, outlineWidth: 0.5, text: "240 Min", textColor: selltextColor });
            }
            // this.getsetup(this.purchased_date, this.entry_timestamp, this.entry_price, this.stoploss_price, this.target_price)
          }

        }

        if (this.SelectedExchange_Name == "NSEFO") {

          if (this.finData.time_frame == 1) {
            var buy_array = this.BuyOverlayData['weekly'];
            for (let item of Object.values(buy_array)) {
              this.rectangleTool.addRectanglesFromData(item, { fillColor: buyfillColor, outlineColor: buyoutlineColor, outlineWidth: 0.5, text: "Weekly", textColor: buytextColor });
            }
            var sell_array = this.SellOverlayData['weekly'];
            for (let item of Object.values(sell_array)) {
              this.rectangleTool.addRectanglesFromData(item, { fillColor: sellfillColor, outlineColor: selloutlineColor, outlineWidth: 0.5, text: "Weekly", textColor: selltextColor });
            }
            // this.getsetup(this.purchased_date, this.entry_timestamp, this.entry_price, this.stoploss_price, this.target_price)
          }

          if (this.finData.time_frame == 2) {
            var buy_array = this.BuyOverlayData['daily'];
            for (let item of Object.values(buy_array)) {
              this.rectangleTool.addRectanglesFromData(item, { fillColor: buyfillColor, outlineColor: buyoutlineColor, outlineWidth: 0.5, text: "Daily", textColor: buytextColor });
            }
            var sell_array = this.SellOverlayData['daily'];
            for (let item of Object.values(sell_array)) {
              this.rectangleTool.addRectanglesFromData(item, { fillColor: sellfillColor, outlineColor: selloutlineColor, outlineWidth: 0.5, text: "Daily", textColor: selltextColor });
            }
            // this.getsetup(this.purchased_date, this.entry_timestamp, this.entry_price, this.stoploss_price, this.target_price)
          }

          if (this.finData.time_frame == 3) {
            var buy_array = this.BuyOverlayData['sixty'];
            for (let item of Object.values(buy_array)) {
              this.rectangleTool.addRectanglesFromData(item, { fillColor: buyfillColor, outlineColor: buyoutlineColor, outlineWidth: 0.5, text: "60 Min", textColor: buytextColor });
            }
            var sell_array = this.SellOverlayData['sixty'];
            for (let item of Object.values(sell_array)) {
              this.rectangleTool.addRectanglesFromData(item, { fillColor: sellfillColor, outlineColor: selloutlineColor, outlineWidth: 0.5, text: "60 Min", textColor: selltextColor });
            }
            // this.getsetup(this.purchased_date, this.entry_timestamp, this.entry_price, this.stoploss_price, this.target_price)
          }

          if (this.finData.time_frame == 25) {
            var buy_array = this.BuyOverlayData['daily'];
            for (let item of Object.values(buy_array)) {
              this.rectangleTool.addRectanglesFromData(item, { fillColor: buyfillColor, outlineColor: buyoutlineColor, outlineWidth: 0.5, text: "Daily", textColor: buytextColor });
            }
            var sell_array = this.SellOverlayData['daily'];
            for (let item of Object.values(sell_array)) {
              this.rectangleTool.addRectanglesFromData(item, { fillColor: sellfillColor, outlineColor: selloutlineColor, outlineWidth: 0.5, text: "Daily", textColor: selltextColor });
            }
            // this.getsetup(this.purchased_date, this.entry_timestamp, this.entry_price, this.stoploss_price, this.target_price)
          }
        }

      }
    }
    else {
      this.dropdownShow = false;
      this.candlestickSeries.setMarkers([]);
      this.rectangleTool.removeAllRectangles()
      // if (this.buylineSeries) {
      //   this.buylineSeries.setMarkers([]);
      //   this.buylineSeries.setData([]);
      // }
      // if (this.targetlineSeries) {
      //   this.targetlineSeries.setMarkers([]);
      //   this.targetlineSeries.setData([]);
      // }
      // if (this.stoplosslineSeries) {
      //   this.stoplosslineSeries.setMarkers([]);
      //   this.stoplosslineSeries.setData([]);
      // }
      // this.getsetup(this.purchased_date, this.entry_timestamp, this.entry_price, this.stoploss_price, this.target_price)
    }
  }

  slectedStock(item: any, key: any, tradeId: any, probability: any, prediction: any, exp_num: any, trade_id: any) {
    // let orderTimeFrame=null;
    this.EXP_NUM = exp_num;
    this.SelectedStock = item.STOCK_NAME;
    this.Probability = probability;
    this.Prediction = prediction;
    this.selectedTradeId = trade_id;
    //  if(this.SelectedExchange_Name == "NSE")
    // {

    //   if (this.activeMenu == "daily") {
    //     orderTimeFrame=1
    //   }
    //   if (this.activeMenu == "sixty") {
    //     orderTimeFrame=2;
    //   }
    //   if (this.activeMenu == "fifteen") {
    //      orderTimeFrame=3;
    //   }
    //    if (this.activeMenu == "seventy_five") {
    //       orderTimeFrame=25;
    //   }
    // }
    // if(this.SelectedExchange_Name == "MCX")
    // {
    //    if (this.activeMenu == "daily") {
    //     orderTimeFrame=1;
    //   }
    //   if (this.activeMenu == "sixty") {
    //      orderTimeFrame=4;
    //   }
    //   if (this.activeMenu == "two_forty") {
    //     orderTimeFrame=2;
    //   }
    //   if (this.activeMenu == "one_twenty") {
    //     orderTimeFrame=3;
    //   }
    // }
    // if(this.SelectedExchange_Name == "NSEFO")
    // {
    //   if (this.activeMenu == "daily") {
    //     orderTimeFrame=1; 
    //   }
    //   if (this.activeMenu == "sixty") {
    //     orderTimeFrame=2; 
    //   }
    //   if (this.activeMenu == "fifteen") {
    //     orderTimeFrame=3; 
    //   }
    //   if (this.activeMenu == "seventy_five") {
    //     orderTimeFrame=25; 
    //   }
    // }
    const timeFrameMap: any = {
      NSE: {
        daily: 1,
        sixty: 2,
        fifteen: 3,
        seventy_five: 25,
        one_twenty_five: 5,
        twenty_five: 6
      },
      MCX: {
        daily: 1,
        sixty: 4,
        two_forty: 2,
        one_twenty: 3
      },
      NSEFO: {
        daily: 1,
        sixty: 2,
        fifteen: 3,
        seventy_five: 25,
        one_twenty_five: 5,
        twenty_five: 6
      }
    };
    let orderTimeFrame = timeFrameMap[this.SelectedExchange_Name]?.[this.activeMenu] ?? null;
    this.apiService.OnGetStockIdByTradeidService(tradeId).subscribe(resp => {
      this.stockId = resp.response.stock_id;
      this.fincreateform.patchValue({
        stock_tick: item.STOCK_NAME,
        order_type: key,
        entry_price: item[key]?.entry_price.toFixed(2),
        stoploss_price: item[key]?.stop_loss.toFixed(2),
        target_price: item[key]?.target_price.toFixed(2),
        purchased_cmp_date: this.getCurrentDateTime(),
        time_frame: orderTimeFrame,
        country_id: this.countryId,
        stock_id: this.stockId.toString()
      });
    })


  }

  getCurrentDateTime(): string {
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0'); // Months are 0-based
    const day = String(now.getDate()).padStart(2, '0');
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const seconds = String(now.getSeconds()).padStart(2, '0');
    return `${year}-${month}-${day}T${hours}:${minutes}`;
  }

  create(type: any) {
    this.showmsg = "Please Wait !!"
    this.submitted = true;
    this.fincreateform.markAllAsTouched();
    if (this.fincreateform.invalid) {
      return;
    }

    if (this.fincreateform.valid) {
      this.spinner.show();
      this.fincreateform.patchValue({
        prediction: this.Prediction,
        probability: this.Probability
      })
      this.fincreateorderData = this.fincreateform.value
      if (this.SelectedExchange_Name == "NSE") {
        this.fincreateorderData = {
          ...this.fincreateorderData,
          trade_id: this.selectedTradeId
        };
        if (type == "demo") {
          this.apiService.createorder(this.fincreateorderData).subscribe(resp => {
            if (resp.msg == "success") {
              // this.closemodal.nativeElement.click();
              this.spinner.hide();
              this.FetchDailyTrades(this.dailyState.currentPage, this.dailyState.searchKey, true, this.StartDate, this.EndDate);
              this.FetchSixtyTrades(this.sixtyState.currentPage, this.dailyState.searchKey, true, this.StartDate, this.EndDate);
              this.FetchFifteenTrades(this.fifteenState.currentPage, this.dailyState.searchKey, true, this.StartDate, this.EndDate);
              this.Fetch75Trades(this.seventyfiveState.currentPage, this.dailyState.searchKey, true, this.StartDate, this.EndDate);
              this.Fetch240Trades(this.twofortyState.currentPage, this.dailyState.searchKey, true, this.StartDate, this.EndDate);
              this.Fetch120Trades(this.onetwentyState.currentPage, this.dailyState.searchKey, true, this.StartDate, this.EndDate);
              this.toastr.success("Order Created Successfully ", 'ALERT !');
              this.submitted = false;
              this.fincreateform.reset();
              this.showCreateOrderModalforButtonClick = false;
            }
            else {
              this.spinner.hide();
              this.toastr.error(resp.response, 'ALERT !');
            }
          })
        }
        else {
          this.apiService.createBucketOrdersService(this.fincreateorderData).subscribe(resp => {
            if (resp.msg == "success") {
              this.spinner.hide();
              this.FetchDailyTrades(this.dailyState.currentPage, this.dailyState.searchKey, true, this.StartDate, this.EndDate);
              this.FetchSixtyTrades(this.sixtyState.currentPage, this.dailyState.searchKey, true, this.StartDate, this.EndDate);
              this.FetchFifteenTrades(this.fifteenState.currentPage, this.dailyState.searchKey, true, this.StartDate, this.EndDate);
              this.Fetch75Trades(this.seventyfiveState.currentPage, this.dailyState.searchKey, true, this.StartDate, this.EndDate);
              this.Fetch240Trades(this.twofortyState.currentPage, this.dailyState.searchKey, true, this.StartDate, this.EndDate);
              this.Fetch120Trades(this.onetwentyState.currentPage, this.dailyState.searchKey, true, this.StartDate, this.EndDate);
              this.toastr.success("Order Created Successfully ", 'ALERT !');
              this.submitted = false;
              this.fincreateform.reset();
              this.showCreateOrderModalforButtonClick = false;
            }
            else {
              this.spinner.hide();
              this.toastr.error(resp.response, 'ALERT !');
            }
          })
        }

      }

      if (this.SelectedExchange_Name == "MCX") {
        const formattedDate = `${this.EXP_NUM.slice(0, 2)}-${this.EXP_NUM.slice(2, 4)}-${this.EXP_NUM.slice(4)}`;
        this.fincreateorderData = {
          ...this.fincreateorderData,
          exp_date: formattedDate,
          trade_id: this.selectedTradeId
        };

        this.apiService.createorderForMCXservice(this.fincreateorderData).subscribe(resp => {
          if (resp.msg == "success") {
            // this.closemodal.nativeElement.click();
            this.spinner.hide();
            this.toastr.success("Order Created Successfully ", 'ALERT !');
            this.FetchDailyTrades(this.dailyState.currentPage, this.dailyState.searchKey, true, this.StartDate, this.EndDate);
            this.FetchSixtyTrades(this.sixtyState.currentPage, this.dailyState.searchKey, true, this.StartDate, this.EndDate);
            this.FetchFifteenTrades(this.fifteenState.currentPage, this.dailyState.searchKey, true, this.StartDate, this.EndDate);
            this.Fetch75Trades(this.seventyfiveState.currentPage, this.dailyState.searchKey, true, this.StartDate, this.EndDate);
            this.Fetch240Trades(this.twofortyState.currentPage, this.dailyState.searchKey, true, this.StartDate, this.EndDate);
            this.Fetch120Trades(this.onetwentyState.currentPage, this.dailyState.searchKey, true, this.StartDate, this.EndDate);
            this.submitted = false;
            this.fincreateform.reset();
            this.showCreateOrderModalforButtonClick = false;
          }
          else {
            this.spinner.hide();
            this.toastr.error(resp.msg, 'ALERT !');
          }
        })
      }

      if (this.SelectedExchange_Name == "NSEFO") {
        const formattedDate = `${this.EXP_NUM.slice(0, 2)}-${this.EXP_NUM.slice(2, 4)}-${this.EXP_NUM.slice(4)}`;
        this.fincreateorderData = {
          ...this.fincreateorderData,
          exp_date: formattedDate,
          trade_id: this.selectedTradeId
        };
        this.apiService.createorderForNSEFOservice(this.fincreateorderData).subscribe(resp => {
          if (resp.msg == "success") {
            // this.closemodal.nativeElement.click();
            this.spinner.hide();
            this.toastr.success("Order Created Successfully ", 'ALERT !');
            this.submitted = false;
            this.FetchDailyTrades(this.dailyState.currentPage, this.dailyState.searchKey, true, this.StartDate, this.EndDate);
            this.FetchSixtyTrades(this.sixtyState.currentPage, this.dailyState.searchKey, true, this.StartDate, this.EndDate);
            this.FetchFifteenTrades(this.fifteenState.currentPage, this.dailyState.searchKey, true, this.StartDate, this.EndDate);
            this.Fetch75Trades(this.seventyfiveState.currentPage, this.dailyState.searchKey, true, this.StartDate, this.EndDate);
            this.Fetch240Trades(this.twofortyState.currentPage, this.dailyState.searchKey, true, this.StartDate, this.EndDate);
            this.Fetch120Trades(this.onetwentyState.currentPage, this.dailyState.searchKey, true, this.StartDate, this.EndDate);
            this.fincreateform.reset();
            this.showCreateOrderModalforButtonClick = false;
          }
          else {
            this.spinner.hide();
            this.toastr.error(resp.response, 'ALERT !');
          }
        })
      }

    }
  }

  createOrderForPanel(type: any) {
    this.showmsg = "Please Wait !!"
    this.submit = true;
    this.fincreateformForPanel.markAllAsTouched();
    if (this.fincreateformForPanel.invalid) {
      return;
    }

    if (this.fincreateformForPanel.valid) {
      this.spinner.show();
      this.fincreateformForPanel.patchValue({
        prediction: this.Prediction,
        probability: this.Probability
      })
      this.fincreateorderData = this.fincreateformForPanel.value
      if (this.SelectedExchange_Name == "NSE") {
        this.fincreateorderData = {
          ...this.fincreateorderData,
          trade_id: this.selectedTradeId
        };
        if (type == "demo") {
          this.apiService.createorder(this.fincreateorderData).subscribe(resp => {
            if (resp.msg == "success") {
              // this.closemodal.nativeElement.click();
              this.spinner.hide();
              this.FetchDailyTrades(this.dailyState.currentPage, this.dailyState.searchKey, true, this.StartDate, this.EndDate);
              this.FetchSixtyTrades(this.sixtyState.currentPage, this.dailyState.searchKey, true, this.StartDate, this.EndDate);
              this.FetchFifteenTrades(this.fifteenState.currentPage, this.dailyState.searchKey, true, this.StartDate, this.EndDate);
              this.Fetch75Trades(this.seventyfiveState.currentPage, this.dailyState.searchKey, true, this.StartDate, this.EndDate);
              this.Fetch240Trades(this.twofortyState.currentPage, this.dailyState.searchKey, true, this.StartDate, this.EndDate);
              this.Fetch120Trades(this.onetwentyState.currentPage, this.dailyState.searchKey, true, this.StartDate, this.EndDate);
              this.toastr.success("Order Created Successfully ", 'ALERT !');
              this.submit = false;
              this.fincreateformForPanel.reset();
              this.showCreateOrderModal = false;
            }
            else {
              this.spinner.hide();
              this.toastr.error(resp.response, 'ALERT !');
            }
          })
        }
        else {
          this.apiService.createBucketOrdersService(this.fincreateorderData).subscribe(resp => {
            if (resp.msg == "success") {
              this.spinner.hide();
              this.FetchDailyTrades(this.dailyState.currentPage, this.dailyState.searchKey, true, this.StartDate, this.EndDate);
              this.FetchSixtyTrades(this.sixtyState.currentPage, this.dailyState.searchKey, true, this.StartDate, this.EndDate);
              this.FetchFifteenTrades(this.fifteenState.currentPage, this.dailyState.searchKey, true, this.StartDate, this.EndDate);
              this.Fetch75Trades(this.seventyfiveState.currentPage, this.dailyState.searchKey, true, this.StartDate, this.EndDate);
              this.Fetch240Trades(this.twofortyState.currentPage, this.dailyState.searchKey, true, this.StartDate, this.EndDate);
              this.Fetch120Trades(this.onetwentyState.currentPage, this.dailyState.searchKey, true, this.StartDate, this.EndDate);
              this.toastr.success("Order Created Successfully ", 'ALERT !');
              this.submitted = false;
              this.fincreateform.reset();
              this.showCreateOrderModalforButtonClick = false;
            }
            else {
              this.spinner.hide();
              this.toastr.error(resp.response, 'ALERT !');
            }
          })
        }

      }

      if (this.SelectedExchange_Name == "MCX") {
        const formattedDate = `${this.EXP_NUM.slice(0, 2)}-${this.EXP_NUM.slice(2, 4)}-${this.EXP_NUM.slice(4)}`;
        this.fincreateorderData = {
          ...this.fincreateorderData,
          exp_date: formattedDate,
          trade_id: this.selectedTradeId
        };
        this.apiService.createorderForMCXservice(this.fincreateorderData).subscribe(resp => {
          if (resp.msg == "success") {
            // this.closemodal.nativeElement.click();
            this.spinner.hide();
            this.FetchDailyTrades(this.dailyState.currentPage, this.dailyState.searchKey, true, this.StartDate, this.EndDate);
            this.FetchSixtyTrades(this.sixtyState.currentPage, this.dailyState.searchKey, true, this.StartDate, this.EndDate);
            this.FetchFifteenTrades(this.fifteenState.currentPage, this.dailyState.searchKey, true, this.StartDate, this.EndDate);
            this.Fetch75Trades(this.seventyfiveState.currentPage, this.dailyState.searchKey, true, this.StartDate, this.EndDate);
            this.Fetch240Trades(this.twofortyState.currentPage, this.dailyState.searchKey, true, this.StartDate, this.EndDate);
            this.Fetch120Trades(this.onetwentyState.currentPage, this.dailyState.searchKey, true, this.StartDate, this.EndDate);
            this.toastr.success("Order Created Successfully ", 'ALERT !');
            this.submit = false;
            this.fincreateformForPanel.reset();
            this.showCreateOrderModal = false;
          }
          else {
            this.spinner.hide();
            this.toastr.error(resp.msg, 'ALERT !');
          }
        })
      }

      if (this.SelectedExchange_Name == "NSEFO") {
        const formattedDate = `${this.EXP_NUM.slice(0, 2)}-${this.EXP_NUM.slice(2, 4)}-${this.EXP_NUM.slice(4)}`;
        this.fincreateorderData = {
          ...this.fincreateorderData,
          exp_date: formattedDate,
          trade_id: this.selectedTradeId
        };
        this.apiService.createorderForNSEFOservice(this.fincreateorderData).subscribe(resp => {
          if (resp.msg == "success") {
            // this.closemodal.nativeElement.click();
            this.spinner.hide();
            this.FetchDailyTrades(this.dailyState.currentPage, this.dailyState.searchKey, true, this.StartDate, this.EndDate);
            this.FetchSixtyTrades(this.sixtyState.currentPage, this.dailyState.searchKey, true, this.StartDate, this.EndDate);
            this.FetchFifteenTrades(this.fifteenState.currentPage, this.dailyState.searchKey, true, this.StartDate, this.EndDate);
            this.Fetch75Trades(this.seventyfiveState.currentPage, this.dailyState.searchKey, true, this.StartDate, this.EndDate);
            this.Fetch240Trades(this.twofortyState.currentPage, this.dailyState.searchKey, true, this.StartDate, this.EndDate);
            this.Fetch120Trades(this.onetwentyState.currentPage, this.dailyState.searchKey, true, this.StartDate, this.EndDate);
            this.toastr.success("Order Created Successfully ", 'ALERT !');
            this.submit = false;
            this.fincreateformForPanel.reset();
            this.showCreateOrderModal = false;
          }
          else {
            this.spinner.hide();
            this.toastr.error(resp.response, 'ALERT !');
          }
        })
      }

    }
  }

  // sortData(column: string) {
  //   if (this.sortColumn === column) {
  //     this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
  //   } else {
  //     this.sortColumn = column;
  //     this.sortDirection = 'asc';
  //   }

  //   let tradeList: any[] = [];

  //   if (this.activeMenu === 'daily') {
  //     tradeList = [...this.DailyTrades];
  //   } else if (this.activeMenu === 'sixty') {
  //     tradeList = [...this.SixtyTrades];
  //   } else if (this.activeMenu === 'fifteen') {
  //     tradeList = [...this.FifteenTrades];
  //   }
  //   else if (this.activeMenu === 'seventy_five') {
  //     tradeList = [...this.SeventyFiveTrades];
  //   }
  //   else if (this.activeMenu === 'two_forty') {
  //     tradeList = [...this.TwoFortyTrades];
  //   }
  //   else if (this.activeMenu === 'one_twenty') {
  //     tradeList = [...this.OneTwentyTrades];
  //   }
  //   else if (this.activeMenu === 'one_twenty_five') {
  //     tradeList = [...this.OneTwentyFiveTrades];
  //   }
  //   else if (this.activeMenu === 'twenty_five') {
  //     tradeList = [...this.TwentyFiveTrades];
  //   }
  //   else {
  //     return;
  //   }

  //   tradeList.sort((a, b) => {
  //     const aKey = this.getTradeKey(a);
  //     const bKey = this.getTradeKey(b);

  //     let valA: any;
  //     let valB: any;

  //     if (column === 'TRADE_TYPE') {
  //       valA = aKey;
  //       valB = bKey;
  //     } else if (['entry_price', 'target_price', 'stop_loss'].includes(column)) {
  //       valA = a[aKey]?.[column] ?? 0;
  //       valB = b[bKey]?.[column] ?? 0;
  //     } else {
  //       valA = a[column];
  //       valB = b[column];
  //     }

  //     if (typeof valA === 'string') {
  //       return this.sortDirection === 'asc'
  //         ? valA.localeCompare(valB)
  //         : valB.localeCompare(valA);
  //     }

  //     return this.sortDirection === 'asc'
  //       ? (valA ?? 0) - (valB ?? 0)
  //       : (valB ?? 0) - (valA ?? 0);
  //   });

  //   // Reassign to trigger Angular's change detection
  //   if (this.activeMenu === 'daily') {
  //     this.DailyTrades = [...tradeList];
  //     setTimeout(() => {
  //       this.DailyTrades = [...this.DailyTrades]; // force re-render
  //     }, 0);
  //   } else if (this.activeMenu === 'sixty') {
  //     this.SixtyTrades = [...tradeList];
  //     setTimeout(() => {
  //       this.SixtyTrades = [...this.SixtyTrades];
  //     }, 0);
  //   } else if (this.activeMenu === 'fifteen') {
  //     this.FifteenTrades = [...tradeList];
  //     setTimeout(() => {
  //       this.FifteenTrades = [...this.FifteenTrades];
  //     }, 0);
  //   }
  //   else if (this.activeMenu === 'seventy_five') {
  //     this.SeventyFiveTrades = [...tradeList];
  //     setTimeout(() => {
  //       this.SeventyFiveTrades = [...this.SeventyFiveTrades];
  //     }, 0);
  //   }
  //   else if (this.activeMenu === 'two_forty') {
  //     this.TwoFortyTrades = [...tradeList];
  //     setTimeout(() => {
  //       this.TwoFortyTrades = [...this.TwoFortyTrades];
  //     }, 0);
  //   }
  //   else if (this.activeMenu === 'one_twenty') {
  //     this.OneTwentyTrades = [...tradeList];
  //     setTimeout(() => {
  //       this.OneTwentyTrades = [...this.OneTwentyTrades];
  //     }, 0);
  //   }
  //   else if (this.activeMenu === 'one_twenty_five') {
  //     this.OneTwentyFiveTrades = [...tradeList];
  //     setTimeout(() => {
  //       this.OneTwentyFiveTrades = [...this.OneTwentyFiveTrades];
  //     }, 0);
  //   }
  //   else if (this.activeMenu === 'twenty_five') {
  //     this.TwentyFiveTrades = [...tradeList];
  //     setTimeout(() => {
  //       this.TwentyFiveTrades = [...this.TwentyFiveTrades];
  //     }, 0);
  //   }
  // }

  sortData(column: string) {
    if (this.sortColumn === column) {
      this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
    } else {
      this.sortColumn = column;
      this.sortDirection = 'asc';
    }

    const tradeList = this.getActiveTradeList();
    const sortedList = this.applySorting(tradeList);
    this.setActiveTradeList(sortedList);
  }

  getActiveTradeList(): any[] {
    switch (this.activeMenu) {
      case 'daily':
        return [...this.DailyTrades];
      case 'sixty':
        return [...this.SixtyTrades];
      case 'fifteen':
        return [...this.FifteenTrades];
      case 'seventy_five':
        return [...this.SeventyFiveTrades];
      case 'two_forty':
        return [...this.TwoFortyTrades];
      case 'one_twenty':
        return [...this.OneTwentyTrades];
      case 'one_twenty_five':
        return [...this.OneTwentyFiveTrades];
      case 'twenty_five':
        return [...this.TwentyFiveTrades];
      default:
        return [];
    }
  }

  setActiveTradeList(tradeList: any[]): void {
    switch (this.activeMenu) {
      case 'daily':
        this.DailyTrades = [...tradeList];
        break;
      case 'sixty':
        this.SixtyTrades = [...tradeList];
        break;
      case 'fifteen':
        this.FifteenTrades = [...tradeList];
        break;
      case 'seventy_five':
        this.SeventyFiveTrades = [...tradeList];
        break;
      case 'two_forty':
        this.TwoFortyTrades = [...tradeList];
        break;
      case 'one_twenty':
        this.OneTwentyTrades = [...tradeList];
        break;
      case 'one_twenty_five':
        this.OneTwentyFiveTrades = [...tradeList];
        break;
      case 'twenty_five':
        this.TwentyFiveTrades = [...tradeList];
        break;
    }
  }

  applySorting(tradeList: any[]): any[] {
    if (!this.sortColumn) {
      return [...tradeList];
    }

    return [...tradeList].sort((a, b) => {
      const aKey = this.getTradeKey(a);
      const bKey = this.getTradeKey(b);

      let valA: any;
      let valB: any;

      if (this.sortColumn === 'TRADE_TYPE') {
        valA = aKey ?? '';
        valB = bKey ?? '';
      } else if (['entry_price', 'target_price', 'stop_loss'].includes(this.sortColumn)) {
        valA = a[aKey]?.[this.sortColumn] ?? 0;
        valB = b[bKey]?.[this.sortColumn] ?? 0;
      } else {
        valA = a[this.sortColumn];
        valB = b[this.sortColumn];
      }

      if (typeof valA === 'string') valA = valA.toLowerCase();
      if (typeof valB === 'string') valB = valB.toLowerCase();

      if (typeof valA === 'string' || typeof valB === 'string') {
        return this.sortDirection === 'asc'
          ? String(valA).localeCompare(String(valB))
          : String(valB).localeCompare(String(valA));
      }

      return this.sortDirection === 'asc'
        ? (valA ?? 0) - (valB ?? 0)
        : (valB ?? 0) - (valA ?? 0);
    });
  }

  getTradeKey(obj: any): string {
    return obj.BUY ? 'BUY' : obj.SELL ? 'SELL' : '';
  }

  isHighlighted(stockName: string): boolean {
    return this.highlightedStockNames
      .some(name => name.toLowerCase() === stockName.toLowerCase());
  }

  isHighlightedsixty(stockName: string): boolean {
    return this.highlightedStockNamesSixty
      .some(name => name.toLowerCase() === stockName.toLowerCase());
  }


  isHighlightedfifteen(stockName: string): boolean {
    return this.highlightedStockNamesFifteen
      .some(name => name.toLowerCase() === stockName.toLowerCase());
  }

  isHighlightedseventy_five(stockName: string): boolean {
    return this.highlightedStockNames75
      .some(name => name.toLowerCase() === stockName.toLowerCase());
  }

  isHighlighted240(stockName: string): boolean {
    return this.highlightedStockNames240
      .some(name => name.toLowerCase() === stockName.toLowerCase());
  }

  isHighlighted120(stockName: string): boolean {
    return this.highlightedStockNames120
      .some(name => name.toLowerCase() === stockName.toLowerCase());
  }
  isHighlighted125(stockName: string): boolean {
    return this.highlightedStockNames125
      .some(name => name.toLowerCase() === stockName.toLowerCase());
  }
  ishighlighted25(stockName: string): boolean {
    return this.highlightedStockNames25
      .some(name => name.toLowerCase() === stockName.toLowerCase());
  }

  keyboardFunction() {
    let buffer = '';
    let lastKeyTime = Date.now();

    this.keySub = fromEvent<KeyboardEvent>(window, 'keydown').pipe(
      filter(e => e.key.length === 1 || e.key === 'Backspace' || e.key === ' '),
      map(e => {
        const now = Date.now();
        const gap = now - lastKeyTime;
        lastKeyTime = now;

        if (gap > 1500) {
          buffer = '';
        }

        if (e.key === ' ') {
          buffer = '';
          this.highlightedStockNames = [];
          this.highlightedStockNamesSixty = [];
          this.highlightedStockNamesFifteen = []
          this.typedText = '';
          return '';
        }

        if (e.key === 'Backspace') {
          buffer = buffer.slice(0, -1);
        } else {
          buffer += e.key.toLowerCase();
        }
        return buffer;
      }),
      debounceTime(400)
    ).subscribe(value => {
      this.typedText = value;

      if (this.activeMenu === 'daily') {
        this.dailyState.searchKey = value;
        // this.FetchDailyTrades('', value, true);
      } else if (this.activeMenu === 'sixty') {
        this.sixtyState.searchKey = value;
        // this.FetchSixtyTrades('', value, true);
      } else if (this.activeMenu === 'fifteen') {
        this.fifteenState.searchKey = value;
        // this.FetchFifteenTrades('', value, true);
      }
      else if (this.activeMenu === 'seventy_five') {
        this.seventyfiveState.searchKey = value;
        // this.Fetch75Trades('', value, true);
      }
      else if (this.activeMenu === 'two_forty') {
        this.twofortyState.searchKey = value;
        // this.Fetch240Trades('', value, true);
      }
      else if (this.activeMenu === 'one_twenty') {
        this.onetwentyState.searchKey = value;
        // this.Fetch120Trades('', value, true);
      }
      else if (this.activeMenu === 'one_twenty_five') {
        this.onetwentyfiveState.searchKey = value;
        // this.Fetch120Trades('', value, true);
      }
      else if (this.activeMenu === 'twenty_five') {
        this.twentyfiveState.searchKey = value;
        // this.Fetch120Trades('', value, true);
      }
    });
  }

  showContextMenu(x: number, y: number): void {
    const menu = document.getElementById('customContextMenu');
    if (menu) {
      menu.style.display = 'block';
      menu.style.top = `${y}px`;
      menu.style.left = `${x}px`;
    }
  }

  hideContextMenu(): void {
    const menu = document.getElementById('customContextMenu');
    if (menu) {
      menu.style.display = 'none';
    }
  }

  showAlert(): void {

    this.alertForm.get('trigger_price')?.valueChanges.subscribe(() => {
      this.calculateMinMax();
    });

    this.alertForm.get('threshold')?.valueChanges.subscribe(() => {
      this.calculateMinMax();
    });
    this.alertForm.patchValue({
      exchange: this.SelectedExchange_Name,
      stock_symbol: this.SelectedStockName.toUpperCase(),
      timeframe: this.time_frame.toString()

    })

    this.modalalert.show();
    this.hideContextMenu();
  }

  onSubmitSetAlert() {
    this.submitStock = true;
    this.alertForm.markAllAsTouched();
    if (this.alertForm.invalid) {
      this.toastr.error("This fields are required !")
      return;
    }
    else {
      this.spinner.show();
      const setAlertData = this.alertForm.value;
      this.apiService.onSubmitSetAlertService(setAlertData).subscribe(resp => {
        if (resp.msg == "success") {
          this.spinner.hide();
          this.toastr.success(resp.response.message);
          this.submitStock = false;
          this.alertForm.get('trigger_price')?.reset();
          this.alertForm.get('target_percentage')?.reset();
          this.alertForm.get('threshold')?.reset();
          this.alertForm.get('price_range_min')?.reset();
          this.alertForm.get('price_range_max')?.reset();
          this.alertForm.get('cooldown_minutes')?.reset();
          this.alertForm.get('note')?.reset();
          this.alertForm.get('alert_type')?.setValue('');
          this.getAllSetAlerts();
        }
        else {
          this.spinner.hide();
          return;
        }
      });
    };
  }

  getAllSetAlerts() {
    this.apiService.getAllSetAlertsService(this.userId).subscribe(resp => {
      if (resp.msg = "success") {
        this.allSetAlerts = resp.response;
      }
      else {
        console.log(resp);
      }
    });
  }

  deleteAlert(alertid: any) {
    const confirmation = window.confirm("Are you sure , you want to delete?");
    if (confirmation) {
      this.spinner.show();
      this.apiService.deleteAlertService(alertid).subscribe(data => {
        this.showmsg = data.msg;
        if (this.showmsg == "success") {
          this.spinner.hide();
          this.toastr.success('Alert Deleted Successfully');
          this.getAllSetAlerts();
        }
        else {
          this.spinner.hide();
          this.toastr.error('Alert Deletion Failed');
        }
      });
    }
  }

  openCreateOrderPanel() {
    this.showCreateOrderModal = true;
    this.apiService.OnGetStockIdByTradeidService(this.selectedTradeId).subscribe(resp => {
      this.stockId = resp.response.stock_id;
      this.fincreateformForPanel.patchValue({
        stock_tick: this.SelectedStockName,
        order_type: this.selectedTradeType,
        entry_price: this.EntryPrice.toFixed(2),
        stoploss_price: this.StoplossPrice.toFixed(2),
        target_price: this.TargetPrice.toFixed(2),
        purchased_cmp_date: this.getCurrentDateTime(),
        time_frame: this.time_frame,
        country_id: this.countryId,
        stock_id: this.stockId.toString()
      });
    });
    this.fincreateorderData = this.fincreateformForPanel.value
  }

  closeCreateOrderPanel() {
    this.showCreateOrderModal = false;
    this.fincreateformForPanel.reset();
    this.submit = false;
  }

  onSubmitofPanelOrder(type: any) {
    this.createOrderForPanel(type);
  }

  openCreateOrderPanelforButton() {
    this.showCreateOrderModalforButtonClick = true;
  }

  closeCreateOrderPanelforButton() {
    this.showCreateOrderModalforButtonClick = false;
    this.fincreateform.reset();
    this.submitted = false;
  }

  formatExpiry(expNum: string): string {
    if (!expNum || expNum.length !== 8) return expNum;

    // Extract DDMMYYYY
    const day = expNum.substring(0, 2);
    const month = expNum.substring(2, 4);
    const year = expNum.substring(4, 8);

    // Create date string in ISO format (YYYY-MM-DD)
    const dateStr = `${year}-${month}-${day}`;
    const date = new Date(dateStr);

    // Format nicely (e.g., 19-Sep-2025)
    return date.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
  }

  UpdatePrediction() {
    this.spinner.show()
    let data = null;
    if (this.SelectedExchange_Name == "NSE") {
      data = {
        "order_type": this.SETUPTYPE,
        "entry_price": this.EntryPrice,
        "target_price": this.TargetPrice,
        "stoploss_price": this.StoplossPrice,
        "last_d_time": this.finData.last_d_time,
        "time_frame": this.finData.time_frame,
        "tick": this.finData.tick,
        country_id: localStorage.getItem('selectedCountryId')
      }
      this.apiService.getModelPredictionService(data).subscribe(resp => {
        this.ModelPrediction = "PROBABILITY OF TRADE : " + resp.msg.toUpperCase() + " = " + resp.response.probability + " %";
        this.Prediction = resp.msg;
        this.Probability = resp.response.probability;
        this.showMarketAlert(this.ModelPrediction)
        this.UpdateTradeFlag = true;
        this.spinner.hide()
      })
    }
    if (this.SelectedExchange_Name == "MCX") {
      data = {
        "order_type": this.SETUPTYPE,
        "entry_price": this.EntryPrice,
        "target_price": this.TargetPrice,
        "stoploss_price": this.StoplossPrice,
        "last_d_time": this.finData.last_d_time,
        "time_frame": this.finData.time_frame,
        "tick": this.finData.st_sym,
        country_id: localStorage.getItem('selectedCountryId')
      }
      this.apiService.getMCXModelPredictionService(data, this.SelectedExpiryDate, "commodity").subscribe(resp => {
        this.ModelPrediction = "PROBABILITY OF TRADE : " + resp.msg.toUpperCase() + " = " + resp.response.probability + " %";
        this.Prediction = resp.msg;
        this.Probability = resp.response.probability;
        this.showMarketAlert(this.ModelPrediction)
        this.UpdateTradeFlag = true;
        this.spinner.hide();
      })
    }
    if (this.SelectedExchange_Name == "NSEFO") {
      data = {
        "order_type": this.SETUPTYPE,
        "entry_price": this.EntryPrice,
        "target_price": this.TargetPrice,
        "stoploss_price": this.StoplossPrice,
        "last_d_time": this.finData.last_d_time,
        "time_frame": this.finData.time_frame,
        "tick": this.finData.st_sym,
        country_id: localStorage.getItem('selectedCountryId')
      }
      this.apiService.getMCXModelPredictionService(data, this.SelectedExpiryDate, "futures").subscribe(resp => {
        this.ModelPrediction = "PROBABILITY OF TRADE : " + resp.msg.toUpperCase() + " = " + resp.response.probability + " %";
        this.Prediction = resp.msg;
        this.Probability = resp.response.probability;
        this.showMarketAlert(this.ModelPrediction)
        this.UpdateTradeFlag = true;
        this.spinner.hide();
      })
    }
  }

  showMarketAlert(TrandeMessage: any) {
    this.isNotificationVisible = true;
  }

  UpdateAlert() {
    this.spinner.show();
    this.showmsg = "Updating Alerts .....";
    const data = {
      "order_type": this.SETUPTYPE,
      "entry_price": this.EntryPrice,
      "target_price": this.TargetPrice,
      "stoploss_price": this.StoplossPrice,
      "last_d_time": this.finData.last_d_time,
      "time_frame": this.finData.time_frame,
      "tick": this.finData.tick,
      country_id: localStorage.getItem('selectedCountryId')

    }
    this.apiService.getModelPredictionService(data).subscribe(resp => {
      this.ModelPrediction = "PROBABILITY OF TRADE : " + resp.msg.toUpperCase() + " = " + resp.response.probability + " %";
      this.Prediction = resp.msg;
      this.Probability = resp.response.probability;
      this.showMarketAlert(this.ModelPrediction)
      let obj = {
        trade_id: this.selectedTradeId,
        entry: this.EntryPrice,
        stop_loss: this.StoplossPrice,
        target: this.TargetPrice,
        prediction: this.Prediction,
        probability: this.Probability / 100
      }
      this.apiService.upadteAlertService(obj).subscribe(resp => {
        if (resp.msg = "success") {
          this.FetchDailyTrades(this.dailyState.currentPage, null, false, this.StartDate, this.EndDate);
          this.FetchSixtyTrades(this.sixtyState.currentPage, null, false, this.StartDate, this.EndDate);
          this.FetchFifteenTrades(this.fifteenState.currentPage, null, false, this.StartDate, this.EndDate);
          this.Fetch75Trades(1, null, false, this.StartDate, this.EndDate);
          this.Fetch240Trades(1, null, false, this.StartDate, this.EndDate);
          this.Fetch120Trades(1, null, false, this.StartDate, this.EndDate);
          this.Fetch125Trades(1, null, false, this.StartDate, this.EndDate);
          this.Fetch25Trades(1, null, false, this.StartDate, this.EndDate);
          this.toastr.success("Trade Updated !")
          this.spinner.hide()
        }
        else {
          this.toastr.error("Something Went Wrong !")
          this.spinner.hide()
        }

      })
    })

  }

  deleteTrade(TradeId: any) {
    const confirmation = window.confirm("Are you sure , you want to delete?");
    if (confirmation) {
      this.apiService.deleteTRadeService(TradeId).subscribe(data => {
        if (data.msg == "success") {
          this.toastr.success('Trade Deleted Successfully');
          this.FetchDailyTrades(this.dailyState.currentPage, this.dailyState.searchKey, true, this.StartDate, this.EndDate);
          this.FetchSixtyTrades(this.sixtyState.currentPage, this.dailyState.searchKey, true, this.StartDate, this.EndDate);
          this.FetchFifteenTrades(this.fifteenState.currentPage, this.dailyState.searchKey, true, this.StartDate, this.EndDate);
          this.Fetch75Trades(this.seventyfiveState.currentPage, this.dailyState.searchKey, true, this.StartDate, this.EndDate);
          this.Fetch240Trades(this.twofortyState.currentPage, this.dailyState.searchKey, true, this.StartDate, this.EndDate);
          this.Fetch120Trades(this.onetwentyState.currentPage, this.dailyState.searchKey, true, this.StartDate, this.EndDate);
          this.Fetch125Trades(this.onetwentyfiveState.currentPage, this.dailyState.searchKey, true, this.StartDate, this.EndDate);
          this.Fetch25Trades(this.twentyfiveState.currentPage, this.dailyState.searchKey, true, this.StartDate, this.EndDate);
        }

        else {
          this.toastr.error('Trade Deletion Failed');
        }
      });
    }
  }

  onDateToggle(event: Event) {
    this.isChecked = (event.target as HTMLInputElement).checked;
    console.log('Date Sort is:', this.isChecked); // true or false
    if (this.isChecked) {
      this.isCheckedForCMP = false; // turn off CMP toggle
    }
    this.FetchDailyTrades(1, null, false, this.StartDate, this.EndDate);
    this.FetchSixtyTrades(1, null, false, this.StartDate, this.EndDate);
    this.FetchFifteenTrades(1, null, false, this.StartDate, this.EndDate);
    this.Fetch75Trades(1, null, false, this.StartDate, this.EndDate);
    this.Fetch240Trades(1, null, false, this.StartDate, this.EndDate);
    this.Fetch120Trades(1, null, false, this.StartDate, this.EndDate);
    this.Fetch25Trades(1, null, false, this.StartDate, this.EndDate);
    this.Fetch125Trades(1, null, false, this.StartDate, this.EndDate);
  }

  onCMPtoggle(event: Event) {
    this.isCheckedForCMP = (event.target as HTMLInputElement).checked;
    console.log('CMP Sort is:', this.isCheckedForCMP); // true or false
    if (this.isCheckedForCMP) {
      this.isChecked = false; // turn off Date toggle
    }
    this.FetchDailyTrades(1, null, false, this.StartDate, this.EndDate);
    this.FetchSixtyTrades(1, null, false, this.StartDate, this.EndDate);
    this.FetchFifteenTrades(1, null, false, this.StartDate, this.EndDate);
    this.Fetch75Trades(1, null, false, this.StartDate, this.EndDate);
    this.Fetch240Trades(1, null, false, this.StartDate, this.EndDate);
    this.Fetch120Trades(1, null, false, this.StartDate, this.EndDate);
    this.Fetch25Trades(1, null, false, this.StartDate, this.EndDate);
    this.Fetch125Trades(1, null, false, this.StartDate, this.EndDate);
  }

  // togglePopsup() {
  //   this.isPopupOpen = !this.isPopupOpen;
  // }

  // openPopup() {
  //   this.isPopupOpen = true;
  // }

  closeFilterPopup() {
    this.isPopupOpen = false;
  }

  toggleFilterPopup() {
    this.isPopupOpen = !this.isPopupOpen;
    console.log('isPopupOpen =', this.isPopupOpen);
  }

  resetFilter() {
    this.isChecked = false;
    this.isCheckedForCMP = false;
    this.selectTradeType = "all";
    const exchange = this.exchanges.find((ex: { exchange_name: string; }) => ex.exchange_name === 'NSE');
    this.selectedExchange = exchange
    this.SelectedExchange_Id = exchange.exchange_id
    this.selectedDateRange = {
      startDate: moment().startOf('year'),     // January 1st, current year
      endDate: moment().endOf('year')          // December 31st, current year
    };
    this.StartDate = this.selectedDateRange.startDate.format('YYYY-MM-DD');
    this.EndDate = this.selectedDateRange.endDate.format('YYYY-MM-DD');
    this.FetchDailyTrades(1, null, false, this.StartDate, this.EndDate);
    this.FetchSixtyTrades(1, null, false, this.StartDate, this.EndDate);
    this.FetchFifteenTrades(1, null, false, this.StartDate, this.EndDate);
    this.Fetch75Trades(1, null, false, this.StartDate, this.EndDate);
    this.Fetch240Trades(1, null, false, this.StartDate, this.EndDate);
    this.Fetch120Trades(1, null, false, this.StartDate, this.EndDate);
    this.Fetch25Trades(1, null, false, this.StartDate, this.EndDate);
    this.Fetch125Trades(1, null, false, this.StartDate, this.EndDate);

  }

  isTradeSignalHighlighted(item: any): boolean {
    return item.TRADE_SIGNAL_ID != null; // highlight only if not null
  }

  vieworder(trade_id: any) {
    localStorage.removeItem('SelectedTrade');
    this.apiService.getCurrentStatus(trade_id, this.selectedExchange.exchange_name).subscribe(resp => {
      console.log("RESPNSE", resp)
      if (resp.msg == "success") {
        let obj = {
          Trade_id: trade_id,
          ExchangeName: this.selectedExchange.exchange_name,
          ActiveMenu: resp.response.order_status
        }
        localStorage.setItem('SelectedTrade', JSON.stringify(obj));
        this.router.navigate(['orderlist'])
      }
      else {
        this.toastr.error("No Order Found")
      }
    });

  }

  addPreviousHighPriceLine(key: any) {
    // Check if data exists for the given key
    if (!this.PreviousHighData || !this.PreviousHighData[key]) {
      return; // key not found, bypass silently
    }

    const previousHigh = this.PreviousHighData[key].previous_high;

    // Extra safeguard if previous_high is missing
    if (!previousHigh || previousHigh.price == null) {
      return;
    }

    const myPriceLine = {
      price: previousHigh.price,
      color: '#f5d131',
      lineWidth: 2,
      lineStyle: 2,
      axisLabelVisible: true,
      title: 'Previous High',
    };

    this.candlestickSeries.createPriceLine(myPriceLine);
  }

}
