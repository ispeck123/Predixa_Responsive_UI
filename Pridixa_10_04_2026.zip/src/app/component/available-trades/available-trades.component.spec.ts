import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AvailableTradesComponent } from './available-trades.component';

describe('AvailableTradesComponent', () => {
  let component: AvailableTradesComponent;
  let fixture: ComponentFixture<AvailableTradesComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AvailableTradesComponent]
    });
    fixture = TestBed.createComponent(AvailableTradesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
