import { Component, ElementRef, HostListener, QueryList, ViewChildren } from '@angular/core';
import { Router } from '@angular/router';
import moment from 'moment';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { debounceTime, Subject, Subscription } from 'rxjs';
import { ApiService } from 'src/app/services/api.service';
import { WebSocketService } from 'src/app/services/web-socket.service';

@Component({
  selector: 'app-current-holdings',
  templateUrl: './current-holdings.component.html',
  styleUrls: ['./current-holdings.component.css']
})
export class CurrentHoldingsComponent {

  Role: any;
  isAdmin: any;
  UserName: any;
  pageSize = 10;
  SelectedCountryId: any;
  SelectedCountryName: any;
  selectedDateRange: any;
  StartDate: any;
  EndDate: any
  showmsg: any;
  UserID: any;
  searchText: string = '';
  currentPage: any = 1;
  AllHoldings: any;
  overAll: any;
  colorInterval: any;
  TotalCount: any = 0;
  pageSizeOptions = [2, 10, 25, 50, 100, 500];
  SearchDebounceFlag: boolean = false;
  highlightedStockNames: string[] = [];
  MatchedCount: number = 0;
  candles: { color: string; height: number, wickHeight: number }[] = [];
  searchSubject: Subject<string> = new Subject<string>();
  currentStatus: any="running";
  isPopupOpen = false;
  IsLoadingVisible: boolean = false;

  @ViewChildren('stockCell') stockCells!: QueryList<ElementRef>;
  private searchSubscription: Subscription;
  constructor(private webSocketService: WebSocketService, private apiService: ApiService, private router: Router, private spinner: NgxSpinnerService, private toastr: ToastrService) { }

  ngOnDestroy(): void {
    this.disconnectWebSocket();
  }

  disconnectWebSocket(): void {
    this.webSocketService.disconnectHoldingListSocket();
  }

  ngOnInit(): void {
    this.SelectedCountryId = localStorage.getItem('selectedCountryId')
    this.SelectedCountryName = localStorage.getItem('selectedCountryName')
    this.selectedDateRange = {
      startDate: moment().startOf('year'),     // January 1st, current year
      endDate: moment().endOf('year')          // December 31st, current year
    };
    this.StartDate = this.selectedDateRange.startDate.format('YYYY-MM-DD');
    this.EndDate = this.selectedDateRange.endDate.format('YYYY-MM-DD');
    this.Role = localStorage.getItem('role');
    if (this.Role == "admin") {
      this.isAdmin = true;
    }
    else {
      this.isAdmin = false;
    }
    this.UserName = localStorage.getItem('UserName');
    this.UserID = localStorage.getItem('UserId');
    this.PrepDebounce();
    this.connectWebSocket(false);
  }

  @HostListener('document:click', ['$event'])
  onClickOutside(event: MouseEvent) {
    const clickedInsidePopup = (event.target as HTMLElement).closest('.filter-popup');
    const clickedOnButton = (event.target as HTMLElement).closest('.filter-btn');

    if (!clickedInsidePopup && !clickedOnButton) {
      this.isPopupOpen = false;
    }
  }

  connectWebSocket(highlight: boolean = false) {
    // this.filteredListData = [];
    this.webSocketService.disconnectHoldingListSocket();
    this.IsLoadingVisible = true;

    this.webSocketService.connectHoldinglistOrders(this.searchText, this.currentPage, this.pageSize);

    this.webSocketService.getHoldingListData().subscribe((data) => {
      console.log('📥 Received WebSocket data:', data);
      try {
        const parsedData = typeof data === 'string' ? JSON.parse(data) : data;

        this.AllHoldings = parsedData.holdings || [];
        this.TotalCount = parsedData.overall.count_total || 0;
        this.overAll = parsedData.overall || 0;
        this.IsLoadingVisible = false;
        console.log('📥 Received WebSocket data:', this.AllHoldings);

        if (highlight && this.searchText) {
          const lowerSearch = this.searchText.trim().toLowerCase();

          const matches = this.AllHoldings.filter((item: { symbol: string }) =>
            item.symbol?.toLowerCase().includes(lowerSearch)
          );

          this.MatchedCount = matches.length;
          this.highlightedStockNames = matches.map((item: { symbol: any; }) => item.symbol);

          if (matches.length > 0) {
            const firstMatchName = matches[0].symbol;

            setTimeout(() => {
              const target = this.stockCells.find(cell =>
                cell.nativeElement
                  .getAttribute('data-stock')
                  ?.toLowerCase() === firstMatchName.toLowerCase()
              );

              if (target) {
                this.currentPage = parsedData.page_no
                target.nativeElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
              }
            });
          } else {
            this.highlightedStockNames = [];
          }
        } else {
          this.highlightedStockNames = [];
          this.MatchedCount = 0;
        }

      } catch (error) {
        console.error("Error parsing WebSocket data:", error);
        this.AllHoldings = [];
        this.IsLoadingVisible = false;
      }
    });
  }

  isHighlighted(stockName: string): boolean {
    return this.highlightedStockNames
      .some(name => name.toLowerCase() === stockName.toLowerCase());
  }

  goToNextPage() {
    const totalPages = this.getTotalPages();
    if (this.currentPage < totalPages) {
      this.currentPage++;
      this.connectWebSocket(true);
    }
  }

  goToPreviousPage() {
    this.currentPage--;
    this.connectWebSocket(true);
  }

  getTotalPages(): number {
    const total = this.TotalCount || 0;
    return Math.ceil(total / this.pageSize);
  }

  getPageNumbers(): number[] {
    const totalPages = this.getTotalPages();
    const currentPage = this.getCurrentPage();

    const maxVisible = 5;
    let startPage = Math.max(currentPage - Math.floor(maxVisible / 2), 1);
    let endPage = Math.min(startPage + maxVisible - 1, totalPages);

    if (endPage - startPage < maxVisible - 1) {
      startPage = Math.max(endPage - maxVisible + 1, 1);
    }

    const pageNumbers: number[] = [];
    for (let i = startPage; i <= endPage; i++) {
      pageNumbers.push(i);
    }

    return pageNumbers;
  }

  getCurrentPage(): number {
    return this.currentPage;
  }

  goToPage(page: number) {
    this.currentPage = page;
    this.connectWebSocket(true);
  }

  onPageSizeChange() {
    this.currentPage = 1;
    this.connectWebSocket(true);
  }

    PrepDebounce() {
    this.searchSubject.pipe(
      debounceTime(400)
    ).subscribe((value: string) => {
      const trimmed = value.trim().toLowerCase();
      this.searchText = trimmed;
      this.currentPage = null;
      this.connectWebSocket(true);
    });
  }

  onSearchInput(value: string) {
    // this.SearchDebounceFlag = true;
    this.searchSubject.next(value);
  }

    onCurrentStatusTypeChange() { 
    if(this.currentStatus=="running")
    {
      this.connectWebSocket(false);
    }
    else
    {

    }

  }

  togglePopsup() {
    this.isPopupOpen = !this.isPopupOpen;
  }

  openPopup() {
    this.isPopupOpen = true;
  }

  resetFilter() {
  }


  initializeCandles(): void {
    this.candles = Array.from({ length: 10 }, () => ({
      color: 'green',
      height: this.getRandomHeight(),
      wickHeight: this.getRandomWickHeight()
    }));
  }

  getRandomWickHeight(): number {
    return Math.floor(Math.random() * 30) + 10;
  }

  getRandomHeight(): number {
    return Math.floor(Math.random() * 50) + 20;
  }

  startRandomColorToggle(): void {
    this.colorInterval = setInterval(() => {
      this.candles = this.candles.map((candle) => ({
        color: Math.random() > 0.5 ? 'green' : 'red',
        height: this.getRandomHeight(),
        wickHeight: this.getRandomWickHeight()
      }));
    }, 500);
  }

}
