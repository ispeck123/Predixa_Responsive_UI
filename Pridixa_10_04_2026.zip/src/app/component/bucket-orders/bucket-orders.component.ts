import { Component, ElementRef, HostListener, OnInit, QueryList, ViewChildren } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { createChart, CrosshairMode } from 'lightweight-charts';
import moment from 'moment';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { debounceTime, Subject, Subscription } from 'rxjs';
import { ApiService } from 'src/app/services/api.service';
import { RectangleDrawingTool } from './rectangle-drawing-tool';
import { WebSocketService } from 'src/app/services/web-socket.service';


type Patch = Partial<{
  optimized_buy_sell_zone: boolean;
  qualified_zones: boolean;
}>;

const MENU_RULES: Record<string, {
  base: string; // where overlap checkboxes are valid (same as activeMenu)
  overlap_evaluate?: Record<string, Patch>;
  overlap_analyze?: Record<string, Patch>;
}> = {
  daily: {
    base: "daily",
    overlap_evaluate: {
      monthly: { qualified_zones: false, optimized_buy_sell_zone: true },
    },
    overlap_analyze: {
      weekly: { qualified_zones: false, optimized_buy_sell_zone: true },
    }
  },

  sixty: {
    base: "sixty",
    overlap_evaluate: {
      weekly: { optimized_buy_sell_zone: true },
      seventy_five: { optimized_buy_sell_zone: true },
    },
    overlap_analyze: {
      daily: { optimized_buy_sell_zone: true },
      seventy_five: { optimized_buy_sell_zone: true },
    }
  },

  fifteen: {
    base: "fifteen",
    overlap_evaluate: {
      daily: { optimized_buy_sell_zone: true },
    },
    overlap_analyze: {
      sixty: { optimized_buy_sell_zone: true },
    }
  },

  one_twenty_five: {
    base: "one_twenty_five",
    overlap_evaluate: {
      weekly: { optimized_buy_sell_zone: true },
    },
    overlap_analyze: {
      daily: { optimized_buy_sell_zone: true },
    }
  },

  seventy_five: {
    base: "seventy_five",
    overlap_evaluate: {
      weekly: { optimized_buy_sell_zone: true },
    },
    overlap_analyze: {
      daily: { optimized_buy_sell_zone: true },
    }
  },

  twenty_five: {
    base: "twenty_five",
    overlap_evaluate: {
      daily: { optimized_buy_sell_zone: true },
    },
    overlap_analyze: {
      one_twenty_five: { optimized_buy_sell_zone: true },
    }
  },
};


@Component({
  selector: 'app-bucket-orders',
  templateUrl: './bucket-orders.component.html',
  styleUrls: ['./bucket-orders.component.css']
})
export class BucketOrdersComponent implements OnInit {

  private viewGraphOverlapMemory: Record<number, { evaluate: boolean; analyze: boolean;qualified:boolean  }> = {};
  @ViewChildren('stockCell') stockCells!: QueryList<ElementRef>;
  Role: any;
  isAdmin: any;
  UserName: any;
  pageSize = 10;
  SelectedCountryId: any;
  SelectedCountryName: any;
  selectedDateRange: any;
  StartDate: any;
  EndDate: any
  showmsg: any;
  colorInterval: any;
  searchText: string = '';
  predictionFilter: any = null;
  statusFilter: any = null;
  selectTradeType: any = "all";
  isChecked: boolean = true;
  SearchDebounceFlag: boolean = false;
  timeframe_forOrderList: any = null;
  searchSubject: Subject<string> = new Subject<string>();
  candles: { color: string; height: number, wickHeight: number }[] = [];
  AllbucketListOrders: any;
  isPopupOpen = false;
  activeTab: string = 'Stocks'; // Default tab
  SelectedStockName: any;
  ModalHeader: any;
  SelectedExpiry: any;
  CandleColor: any;
  Open: any;
  High: any;
  Low: any;
  Close: any;
  dropdownShow: any;
  chart: any;
  FullScreenModeValue: any;
  FullChartResponse: any;
  allData: any;
  preBars: any;
  postBars: any;
  reasons: string[] = [];
  QualifiedZoneFlag = false;
  ViewGraphTimeFrame: any;
  ModelPrediction: any;
  ReplayFlag = false;
  entry_price: any;
  stoploss_price: any;
  target_price: any;
  order_type: any;
  selectedOrderId: any;
  RRR: any;
  SpinnerCounter: any = 0;
  ChartRESPONSE: any;
  timestampInSeconds_completed: any
  SETUPREQ = true;
  purchased_date: any;
  entry_timestamp: any;
  completed_on: any;
  finData: any;
  activeMenu: string = 'Success';
  activeMenuCommodity: string = 'Success';
  activeMenuFuture: string = 'Success';
  today: any;
  xspan: any;
  sevenDaysAgo: any;
  searchDataForm: FormGroup;
  // successPage: string = "1";
  successPage: number = 1;
  SuccessCount: number = 0;
  pageSizeOptions = [2,10, 25, 50, 100, 500];
  lastCMPLine: any = null;
  rectangleTool: any;
  UserID: any;
  toolTipData: any;
  lastTime: any;
  UpdateCnadleStockId: any;
  realTimePrice: any;
  lastBar: any;
  PreviousHighData: any;
  selectedOptions: any = {
    base_candle: false,
    buy_sell_zone: false,
    bad_zone: false,
    setup: false,
    overlap_evaluate: false,
    overlap_analyze: false
  };
   AllZonesData: any;
  BaseCandleData: any;
  BuyZoneData: any;
  SellZoneData: any;
  BadZoneData: any;
  BuyOverlayData: any;
  SellOverlayData: any;
  suggestion: any;
  OverLayCandleData: any;
  QualifiedData: any;
  OptimizedBuySellZoneData: any;
  TotalCount: any = 0;
  successOrders: any;
  highlightedStockTick: string = '';
  MatchedCount: number = 0;
  highlightedTradeId: any=null;
  highlightedIndex: number = -1;
  highlightedStockNames: string[] = [];

  ranges: any = {
    'All': [moment('2019-01-01'), moment()],
    'Today': [moment(), moment()],
    'Last 7 Days': [moment().subtract(6, 'days'), moment()],
    'Last 15 Days': [moment().subtract(14, 'days'), moment()],
    'This Month': [moment().startOf('month'), moment().endOf('month')],
    'Last 3 Months': [moment().subtract(3, 'months').startOf('month'), moment().subtract(1, 'month').endOf('month')], // Last 3 months excluding current month
    'Last 6 Months': [moment().subtract(6, 'months').startOf('month'), moment().subtract(1, 'month').endOf('month')]
  }
  invalidDates: moment.Moment[] = [moment().add(2, 'days'), moment().add(3, 'days'), moment().add(5, 'days')];
  isInvalidDate = (m: moment.Moment) => {
    return this.invalidDates.some(d => d.isSame(m, 'day'))
  }

  private candlestickSeries: any;
  private searchSubscription: Subscription;
  constructor(private webSocketService: WebSocketService, private apiService: ApiService, private router: Router, private spinner: NgxSpinnerService, private toastr: ToastrService) { }

  @HostListener('document:click', ['$event'])
  onClickOutside(event: MouseEvent) {
    const clickedInsidePopup = (event.target as HTMLElement).closest('.filter-popup');
    const clickedOnButton = (event.target as HTMLElement).closest('.filter-btn');

    if (!clickedInsidePopup && !clickedOnButton) {
      this.isPopupOpen = false;
    }
  }

  togglePopup(event: MouseEvent) {
    event.stopPropagation(); // prevent immediate close
    this.isPopupOpen = !this.isPopupOpen;
  }

  @HostListener('window:keydown', ['$event'])
  handleKeyDown(event: KeyboardEvent): void {
    switch (event.key) {
      case 'ArrowLeft':
        this.shiftChart(-10);
        break;
      case 'ArrowRight':
        this.shiftChart(10);
        break;
      case '+':
      case '=':
        this.scaleChart(1 / 8, true);
        break;
      case '-':
        this.scaleChart(1 / 8, false);
        break;
      case 'Escape':
        this.cleanupChart();
        break;
    }
    let dataPresent = false;

    if (this.activeTab === 'Stocks') {
      if (this.ViewGraphTimeFrame == 1) {
        switch (event.key) {
          case 'm':
          case 'M':
            dataPresent = !!this.FullChartResponse['monthly'];
            if (dataPresent) {
              // this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = false;
              this.ChangeScreenMode('monthly', 'chart-container_new', false);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
          case 'd':
          case 'D':
            dataPresent = !!this.FullChartResponse['daily'];
            if (dataPresent) {
              this.QualifiedZoneFlag = true;
              // this.selectedOptions = []
              this.dropdownShow = false;
              this.ChangeScreenMode('daily', 'chart-container_new', true);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
          case 'w':
          case 'W':
            dataPresent = !!this.FullChartResponse['weekly'];
            if (dataPresent) {
              // this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = false;
              this.ChangeScreenMode('weekly', 'chart-container_new', false);
            }
            else {
              this.toastr.error(`No Data Found !`);
            }
            break;
        }
      }

      if (this.ViewGraphTimeFrame == 2) {

        switch (event.key) {
          case 'w':
          case 'W':
            dataPresent = !!this.FullChartResponse['weekly'];
            if (dataPresent) {
              // this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = false;
              this.ChangeScreenMode('weekly', 'chart-container_new', false);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
          case 'd':
          case 'D':
            dataPresent = !!this.FullChartResponse['daily'];
            if (dataPresent) {
              // this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = false;
              this.ChangeScreenMode('daily', 'chart-container_new', false);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
          case '6':
            dataPresent = !!this.FullChartResponse['sixty'];
            if (dataPresent) {
              // this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = true;
              this.ChangeScreenMode('sixty', 'chart-container_new', true);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
        }
      }

      if (this.ViewGraphTimeFrame == 3) {
        switch (event.key) {
          case '5':
            dataPresent = !!this.FullChartResponse['fifteen'];
            if (dataPresent) {
              // this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = true;
              this.ChangeScreenMode('fifteen', 'chart-container_new', true);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
          case 'd':
          case 'D':
            dataPresent = !!this.FullChartResponse['daily'];
            if (dataPresent) {
              // this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = false;
              this.ChangeScreenMode('daily', 'chart-container_new', false);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
          case '6':
            dataPresent = !!this.FullChartResponse['sixty'];
            if (dataPresent) {
              // this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = false;
              this.ChangeScreenMode('sixty', 'chart-container_new', false);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
        }
      }

      if (this.ViewGraphTimeFrame == 25) {
        switch (event.key) {
          case 'w':
          case 'W':
            dataPresent = !!this.FullChartResponse['weekly'];
            if (dataPresent) {
              // this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = false;
              this.ChangeScreenMode('weekly', 'chart-container_new', false);
            }
            else {
              this.toastr.error(`No Data Found !`);
            }
            break;
          case 'd':
          case 'D':
            dataPresent = !!this.FullChartResponse['daily'];
            if (dataPresent) {
              // this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = false;
              this.ChangeScreenMode('daily', 'chart-container_new', false);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
          case '7':
            dataPresent = !!this.FullChartResponse['seventy_five'];
            if (dataPresent) {
              // this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = true;
              this.ChangeScreenMode('seventy_five', 'chart-container_new', true);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
        }
      }

      if (this.ViewGraphTimeFrame == 5) {
        switch (event.key) {
          case '1':
            dataPresent = !!this.FullChartResponse['one_twenty_five'];
            if (dataPresent) {
              // this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = true;
              this.ChangeScreenMode('one_twenty_five', 'chart-container_new', true);
            }
            else {
              this.toastr.error(`No Data Found !`);
            }
            break;
          case 'd':
          case 'D':
            dataPresent = !!this.FullChartResponse['daily'];
            if (dataPresent) {
              // this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = false;
              this.ChangeScreenMode('daily', 'chart-container_new', false);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
          case 'w':
          case 'W':
            dataPresent = !!this.FullChartResponse['weekly'];
            if (dataPresent) {
              // this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = false;
              this.ChangeScreenMode('weekly', 'chart-container_new', false);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
          case 'm':
          case 'M':
            dataPresent = !!this.FullChartResponse['monthly'];
            if (dataPresent) {
              // this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = false;
              this.ChangeScreenMode('monthly', 'chart-container_new', false);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
        }
      }

      if (this.ViewGraphTimeFrame == 6) {
        switch (event.key) {
          case '2':
            dataPresent = !!this.FullChartResponse['twenty_five'];
            if (dataPresent) {
              // this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = true;
              this.ChangeScreenMode('twenty_five', 'chart-container_new', true);
            }
            else {
              this.toastr.error(`No Data Found !`);
            }
            break;
          case '1':
            dataPresent = !!this.FullChartResponse['one_twenty_five'];
            if (dataPresent) {
              // this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = false;
              this.ChangeScreenMode('one_twenty_five', 'chart-container_new', false);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
          case 'd':
          case 'D':
            dataPresent = !!this.FullChartResponse['daily'];
            if (dataPresent) {
              // this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = false;
              this.ChangeScreenMode('daily', 'chart-container_new', false);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
        }
      }
    }

    else if (this.activeTab === 'Commodity') {
      if (this.ViewGraphTimeFrame == 1) {
        switch (event.key) {
          case 'm':
          case 'M':
            dataPresent = !!this.FullChartResponse['monthly'];
            if (dataPresent) {
              this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = false;
              this.ChangeScreenMode('monthly', 'chart-container_new', false);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
          case 'd':
          case 'D':
            dataPresent = !!this.FullChartResponse['daily'];
            if (dataPresent) {
              this.QualifiedZoneFlag = true;
              this.selectedOptions = []
              this.dropdownShow = false;
              this.ChangeScreenMode('daily', 'chart-container_new', true);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
          case 'w':
          case 'W':
            dataPresent = !!this.FullChartResponse['weekly'];
            if (dataPresent) {
              this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = false;
              this.ChangeScreenMode('weekly', 'chart-container_new', false);
            }
            else {
              this.toastr.error(`No Data Found !`);
            }
            break;
        }
      }

      if (this.ViewGraphTimeFrame == 2) {

        switch (event.key) {
          case 'w':
          case 'W':
            dataPresent = !!this.FullChartResponse['weekly'];
            if (dataPresent) {
              this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = false;
              this.ChangeScreenMode('weekly', 'chart-container_new', false);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
          case 'd':
          case 'D':
            dataPresent = !!this.FullChartResponse['daily'];
            if (dataPresent) {
              this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = false;
              this.ChangeScreenMode('daily', 'chart-container_new', false);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
          case '4':
            dataPresent = !!this.FullChartResponse['two_forty'];
            if (dataPresent) {
              this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = true;
              this.ChangeScreenMode('two_forty', 'chart-container_new', true);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
        }
      }

      if (this.ViewGraphTimeFrame == 3) {
        switch (event.key) {
          case 'd':
          case 'D':
            dataPresent = !!this.FullChartResponse['daily'];
            if (dataPresent) {
              this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = false;
              this.ChangeScreenMode('daily', 'chart-container_new', false);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
          case '4':
            dataPresent = !!this.FullChartResponse['two_forty'];
            if (dataPresent) {
              this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = false;
              this.ChangeScreenMode('two_forty', 'chart-container_new', false);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
          case '2':
            dataPresent = !!this.FullChartResponse['one_twenty'];
            if (dataPresent) {
              this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = true;
              this.ChangeScreenMode('one_twenty', 'chart-container_new', true);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
        }
      }

      if (this.ViewGraphTimeFrame == 4) {
        switch (event.key) {
          case 'd':
          case 'D':
            dataPresent = !!this.FullChartResponse['daily'];
            if (dataPresent) {
              this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = false;
              this.ChangeScreenMode('daily', 'chart-container_new', false);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
          case '4':
            dataPresent = !!this.FullChartResponse['two_forty'];
            if (dataPresent) {
              this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = false;
              this.ChangeScreenMode('two_forty', 'chart-container_new', false);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
          case '6':
            dataPresent = !!this.FullChartResponse['sixty'];
            if (dataPresent) {
              this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = true;
              this.ChangeScreenMode('sixty', 'chart-container_new', true);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
        }
      }

    }

    else if (this.activeTab === 'Future') {
      if (this.ViewGraphTimeFrame == 1) {
        switch (event.key) {
          case 'm':
          case 'M':
            dataPresent = !!this.FullChartResponse['monthly'];
            if (dataPresent) {
              this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = false;
              this.ChangeScreenMode('monthly', 'chart-container_new', false);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
          case 'd':
          case 'D':
            dataPresent = !!this.FullChartResponse['daily'];
            if (dataPresent) {
              this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = true;
              this.ChangeScreenMode('daily', 'chart-container_new', true);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
          case 'w':
          case 'W':
            dataPresent = !!this.FullChartResponse['weekly'];
            if (dataPresent) {
              this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = false;
              this.ChangeScreenMode('weekly', 'chart-container_new', false);
            }
            else {
              this.toastr.error(`No Data Found !`);
            }
            break;
        }
      }

      if (this.ViewGraphTimeFrame == 2) {
        switch (event.key) {
          case 'w':
          case 'W':
            dataPresent = !!this.FullChartResponse['weekly'];
            if (dataPresent) {
              this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = false;
              this.ChangeScreenMode('weekly', 'chart-container_new', false);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
          case 'd':
          case 'D':
            dataPresent = !!this.FullChartResponse['daily'];
            if (dataPresent) {
              this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = false;
              this.ChangeScreenMode('daily', 'chart-container_new', false);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
          case '6':
            dataPresent = !!this.FullChartResponse['sixty'];
            if (dataPresent) {
              this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = true;
              this.ChangeScreenMode('sixty', 'chart-container_new', true);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
        }
      }

      if (this.ViewGraphTimeFrame == 3) {
        switch (event.key) {
          case '5':
            dataPresent = !!this.FullChartResponse['fifteen'];
            if (dataPresent) {
              this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = true;
              this.ChangeScreenMode('fifteen', 'chart-container_new', true);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
          case 'd':
          case 'D':
            dataPresent = !!this.FullChartResponse['daily'];
            if (dataPresent) {
              this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = false;
              this.ChangeScreenMode('daily', 'chart-container_new', false);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
          case '6':
            dataPresent = !!this.FullChartResponse['sixty'];
            if (dataPresent) {
              this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = false;
              this.ChangeScreenMode('sixty', 'chart-container_new', false);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
        }
      }

      if (this.ViewGraphTimeFrame == 25) {
        switch (event.key) {
          case 'w':
          case 'W':
            dataPresent = !!this.FullChartResponse['weekly'];
            if (dataPresent) {
              this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = false;
              this.ChangeScreenMode('weekly', 'chart-container_new', false);
            }
            else {
              this.toastr.error(`No Data Found !`);
            }
            break;
          case 'd':
          case 'D':
            dataPresent = !!this.FullChartResponse['daily'];
            if (dataPresent) {
              this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = false;
              this.ChangeScreenMode('daily', 'chart-container_new', false);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
          case '7':
            dataPresent = !!this.FullChartResponse['seventy_five'];
            if (dataPresent) {
              this.selectedOptions = []
              this.dropdownShow = false;
              this.QualifiedZoneFlag = true;
              this.ChangeScreenMode('seventy_five', 'chart-container_new', true);
            }
            else {
              this.toastr.error(`No Data Found !`)
            }
            break;
        }
      }
    }
  }

  ChangeScreenMode(type: any, chartId: any, setupReq: boolean) {
    const prevFullScreen = this.FullScreenModeValue;
    this.disconnectWebSocket();
    const dataPresent: boolean = !!this.FullChartResponse[type];
    if (dataPresent) {
      switch (type) {
        case "monthly":
          this.ModalHeader = type;
          this.FullScreenModeValue = type;
          break;
        case "weekly":
          this.ModalHeader = type;
          this.FullScreenModeValue = type;
          break;
        case "daily":
          this.ModalHeader = type;
          this.FullScreenModeValue = type;
          break;
        case "seventy_five":
          this.ModalHeader = "75 Minute";
          this.FullScreenModeValue = type;
          break;
        case "sixty":
          this.ModalHeader = "60 Minute";
          this.FullScreenModeValue = type;
          break;
        case "fifteen":
          this.ModalHeader = "15 Minute";
          this.FullScreenModeValue = type;
          break;
        case "two_forty":
          this.ModalHeader = "240 Minute";
          this.FullScreenModeValue = type;
          break;
        case "one_twenty":
          this.ModalHeader = "120 Minute";
          this.FullScreenModeValue = type;
          break;
        case "one_twenty_five":
          this.ModalHeader = "125 Minute";
          this.FullScreenModeValue = type;
          break;
        case "twenty_five":
          this.ModalHeader = "25 Minute";
          this.FullScreenModeValue = type;
          break;
      }
      const PREPOSTDATA = this.FullChartResponse[type];
      const CHARTDATA = [...PREPOSTDATA.PRE, ...PREPOSTDATA.POST]
      this.preBars = PREPOSTDATA.PRE;
      this.postBars = PREPOSTDATA.POST;
      this.cleanup();
      this.LoadChart(CHARTDATA, chartId);
      this.applyViewGraphOverlapLogic(prevFullScreen); // ✅ NEW
      this.checkboxClicked(this.selectedOptions)
       this.addPreviousHighPriceLine(type);
      const lastRow = CHARTDATA.slice(-1)[0];
      this.CreateClosingLine(lastRow.close)
      this.connectWebSocket(type)

      if (setupReq) {
        this.SETUPREQ = true;
        this.getsetup(this.purchased_date, this.entry_timestamp, this.completed_on, this.entry_price, this.stoploss_price, this.target_price, this.order_type)
      }
      else {

        this.SETUPREQ = false;
      }
    }
    else {
      this.toastr.error(`No Data found !`)
      return;
    }
  }

  private applyViewGraphOverlapLogic(prevFullScreen: string) {
    const tf = this.ViewGraphTimeFrame as number;

    // Map ViewGraphTimeFrame -> base fullscreen timeframe where overlaps are allowed
    // (Adjust if your mapping differs)
    const baseMap: Record<number, string> = {
      1: "daily",          // you said 1 is daily
      2: "sixty",
      3: "fifteen",
      5: "one_twenty_five",          // from your logic (targets monthly/weekly), base seems daily
      25: "seventy_five",
      6: "twenty_five",
    };

    const base = baseMap[tf];
    if (!base) return;

    // init memory
    if (!this.viewGraphOverlapMemory[tf]) {
      this.viewGraphOverlapMemory[tf] = { evaluate: false, analyze: false,qualified:false};
    }

    // 1) If leaving base -> remember BOTH selections
    if (prevFullScreen === base) {
      this.viewGraphOverlapMemory[tf] = {
        evaluate: !!this.selectedOptions["overlap_evaluate"],
        analyze: !!this.selectedOptions["overlap_analyze"],
        qualified: !!this.selectedOptions["qualified_zones"]
      };
    }

    const mem = this.viewGraphOverlapMemory[tf];

    // 2) If returned to base -> restore BOTH, else clear UI flags (memory stays)
    if (this.FullScreenModeValue === base) {
      this.selectedOptions["overlap_evaluate"] = mem.evaluate;
      this.selectedOptions["overlap_analyze"] = mem.analyze;
       this.selectedOptions["qualified_zones"]  = mem.qualified;
    } else {
      this.selectedOptions["overlap_evaluate"] = false;
      this.selectedOptions["overlap_analyze"] = false;
       this.selectedOptions["qualified_zones"]  = false;
    }

    // 3) Calculate optimized dynamically (OR logic, both can trigger)
    this.selectedOptions.optimized_buy_sell_zone = false;

    // ---- ViewGraphTimeFrame == 2 ----

    if (tf === 1) {
      if (mem.evaluate && this.FullScreenModeValue === "monthly") this.selectedOptions.optimized_buy_sell_zone = true;
      if (mem.analyze && this.FullScreenModeValue === "weekly") this.selectedOptions.optimized_buy_sell_zone = true;
    }

    if (tf === 2) {
      if (mem.evaluate && this.FullScreenModeValue === "weekly") this.selectedOptions.optimized_buy_sell_zone = true;
      if (mem.analyze && this.FullScreenModeValue === "daily") this.selectedOptions.optimized_buy_sell_zone = true;
    }

    // ---- ViewGraphTimeFrame == 3 ----
    if (tf === 3) {
      if (mem.evaluate && this.FullScreenModeValue === "daily") this.selectedOptions.optimized_buy_sell_zone = true;
      if (mem.analyze && this.FullScreenModeValue === "sixty") this.selectedOptions.optimized_buy_sell_zone = true;
    }

    // ---- ViewGraphTimeFrame == 4 ----
    if (tf === 5) {
      if (mem.evaluate && this.FullScreenModeValue === "weekly") this.selectedOptions.optimized_buy_sell_zone = true;
      if (mem.analyze && this.FullScreenModeValue === "daily") this.selectedOptions.optimized_buy_sell_zone = true;
    }

    // ---- ViewGraphTimeFrame == 5 ----
    if (tf === 25) {
      if (mem.evaluate && this.FullScreenModeValue === "weekly") this.selectedOptions.optimized_buy_sell_zone = true;
      if (mem.analyze && this.FullScreenModeValue === "daily") this.selectedOptions.optimized_buy_sell_zone = true;
    }

    // ---- ViewGraphTimeFrame == 6 ----
    if (tf === 6) {
      if (mem.evaluate && this.FullScreenModeValue === "daily") this.selectedOptions.optimized_buy_sell_zone = true;
      if (mem.analyze && this.FullScreenModeValue === "one_twenty_five") this.selectedOptions.optimized_buy_sell_zone = true;
    }
  }

  cleanup(): void {
    if (this.chart) {
      this.chart.remove();
    }
  }

  shiftChart(diff: any) {
    const currentPos = this.chart.timeScale().scrollPosition();
    this.chart.timeScale().scrollToPosition(currentPos + diff, false);
  }

  scaleChart(pct: any, zoomIn: any) {
    const currentRange = this.chart.timeScale().getVisibleLogicalRange();
    if (currentRange) {
      const bars = currentRange.to - currentRange.from;
      const direction = zoomIn ? -1 : 1;
      const newRangeBars = bars * pct * direction + bars;
      this.chart.timeScale().setVisibleLogicalRange({
        to: currentRange.to,
        from: currentRange.to - newRangeBars,
      });
    }
  }

  private buildForm() {
    this.today = new Date();
    this.sevenDaysAgo = new Date();
    this.sevenDaysAgo.setDate(this.today.getDate() - 7);
    this.searchDataForm = new FormGroup({
      tick: new FormControl(""),
      selected: new FormControl({
        startDate: moment().subtract(1900, 'days'),
        endDate: moment()
      })
    });
  }

  ngOnDestroy(): void {
    this.disconnectWebSocket();
  }

  disconnectWebSocket(): void {
    this.webSocketService.disconnectStock();
  }

  ngOnInit(): void {
    this.timeframe_forOrderList = null;
    this.SelectedCountryId = localStorage.getItem('selectedCountryId')
    this.SelectedCountryName = localStorage.getItem('selectedCountryName')
    this.selectedDateRange = {
      startDate: moment().startOf('year'),     // January 1st, current year
      endDate: moment().endOf('year')          // December 31st, current year
    };
    this.StartDate = this.selectedDateRange.startDate.format('YYYY-MM-DD');
    this.EndDate = this.selectedDateRange.endDate.format('YYYY-MM-DD');
    this.Role = localStorage.getItem('role');
    if (this.Role == "admin") {
      this.isAdmin = true;
    }
    else {
      this.isAdmin = false;
    }
    this.UserName = localStorage.getItem('UserName');
    this.UserID = localStorage.getItem('UserId');
    this.buildForm();
    this.getAllBucketListOrders(false);
    this.PrepDebounce();
    this.xspan = 3600;
    // this.stockDataFunc();
    this.buildForm();
    this.getorderscount();
    // this.getCommodityorderscount();
    // this.getFuturesorderscount();
  }

  PrepDebounce() {
    // Unsubscribe any previous search listener
    if (this.searchSubscription) {
      this.searchSubscription.unsubscribe();
    }

    // Set up one active subscription based on activeTab
    this.searchSubscription = this.searchSubject.pipe(
      debounceTime(400)
    ).subscribe((value: string) => {
      const trimmed = value.trim().toLowerCase();
      this.searchText = trimmed;
      if (this.activeTab === "Stocks") {
        this.getAllBucketListOrders(true);
        // if (this.activeMenu === 'Success') {
        //   this.getSuccessOrders(true);
        // } else if (this.activeMenu === 'Failed') {
        //   this.getFailedOrders(true);
        // } else if (this.activeMenu === 'Pending') {
        //   this.getPendingOrders(true);
        // } else if (this.activeMenu === 'Progress') {
        //   this.getProgressOrders(true);
        // }
      }

      else if (this.activeTab === "Commodity") {
        // if (this.activeMenuCommodity === 'Success') {
        //   this.getSuccessOrdersCommodity(true);
        // } else if (this.activeMenuCommodity === 'Failed') {
        //   this.getFailedOrdersCommodity(true);
        // } else if (this.activeMenuCommodity === 'Pending') {
        //   this.getPendingOrdersCommodity(true);
        // } else {
        //   this.getProgressOrdersCommodity(true);
        // }
      }

      else if (this.activeTab === "Future") {
        // if (this.activeMenuFuture === 'Success') {
        //   this.getSuccessOrdersFuture(true);
        // } else if (this.activeMenuFuture === 'Failed') {
        //   this.getFailedOrdersFuture(true);
        // } else if (this.activeMenuFuture === 'Pending') {
        //   this.getPendingOrdersFuture(true);
        // } else {
        //   this.getProgressOrdersFuture(true);
        // }
      }
    });
  }

  dashboard() {
    this.router.navigate(['dashboard']);
  }

  logout() {
    localStorage.clear();
    this.router.navigate(['landing']);
  }

  orderList() {
    this.router.navigate(['orderlist']);
  }

  alerts() {
    this.router.navigate(['alerts']);
  }

  autoorders() {
    this.router.navigate(['auto-order-list']);
  }

  stock_screener() {
    this.router.navigate(['home']);
  }

  sysmgmt() {
    this.router.navigate(['system-management']);
  }

  news() {
    this.router.navigate(['news']);
  }

  available_trades() {
    this.router.navigate(['trades']);
  }

  onSearchInput(value: string) {
    this.SearchDebounceFlag = true;
    this.searchSubject.next(value);
  }

  initializeCandles(): void {
    this.candles = Array.from({ length: 10 }, () => ({
      color: 'green',
      height: this.getRandomHeight(),
      wickHeight: this.getRandomWickHeight()
    }));
  }

  getRandomWickHeight(): number {
    return Math.floor(Math.random() * 30) + 10;
  }

  getRandomHeight(): number {
    return Math.floor(Math.random() * 50) + 20;
  }

  startRandomColorToggle(): void {
    this.colorInterval = setInterval(() => {
      this.candles = this.candles.map((candle) => ({
        color: Math.random() > 0.5 ? 'green' : 'red',
        height: this.getRandomHeight(),
        wickHeight: this.getRandomWickHeight()
      }));
    }, 500);
  }

    getorderscount() {
    const requestPayload = {
      country_id: Number(localStorage.getItem('selectedCountryId')),
      stock_tick: this.searchText,
      start_date: this.selectedDateRange.startDate.format('YYYY-MM-DD'),
      end_date: this.selectedDateRange.endDate.format('YYYY-MM-DD'),
      status: "all",
      time_frame: this.timeframe_forOrderList,
      order_type: this.selectTradeType,
      prediction_type: this.predictionFilter
    };
    this.apiService.getBucketOrdersCountService(requestPayload).subscribe(resp => {
      console.log("getbucketordercount",resp)
         this.TotalCount = resp.response[0].count;
          console.log("getbucketordercount",  this.TotalCount)
    })
       
  }


  resetFilter() {
    this.isChecked = false;
    this.selectTradeType = "all";
    this.predictionFilter = null
    this.timeframe_forOrderList = null
    this.selectedDateRange = {
      startDate: moment().startOf('year'),     // January 1st, current year
      endDate: moment().endOf('year')          // December 31st, current year
    };
    this.StartDate = this.selectedDateRange.startDate.format('YYYY-MM-DD');
    this.EndDate = this.selectedDateRange.endDate.format('YYYY-MM-DD');
    this.PrepDebounce();
    this.onPredictionFilterChange();
    this.getAllBucketListOrders(false);
    this.getorderscount();
  }

  togglePopsup() {
    this.isPopupOpen = !this.isPopupOpen;
  }

  openPopup() {
    this.isPopupOpen = true;
  }

  onCmpToggle(event: Event) {
    this.isChecked = (event.target as HTMLInputElement).checked;
    if (this.activeTab == 'Stocks') {
      this.getAllBucketListOrders(true);
      this.getorderscount();
    }
    else if (this.activeTab == 'Commodity') {
      return;
    }
    else {
      return;
    }
  }

  onTimeframeChangeForSuccess() {
    if (this.activeTab == 'Stocks') {
      this.getAllBucketListOrders(true);
      this.getorderscount();
    }
    else if (this.activeTab == 'Commodity') {
      return;
    }
    else {
      return;
    }
  }

  onOrderTypeChangeFilter() {
    if (this.activeTab == 'Stocks') {
      this.getAllBucketListOrders(true);
      this.getorderscount();
    }
    else if (this.activeTab == 'Commodity') {
      return;
    }
    else {
      return;
    }
  }

  onPredictionFilterChange() {
    //  if (this.activeTab == 'Stocks') {
    //     this.getSuccessOrders();
    //     this.getFailedOrders();
    //     this.getPendingOrders();
    //     this.getProgressOrders();
    //     this.getorderscount();
    //   }
    //   else if (this.activeTab == 'Commodity') {
    //     this.getSuccessOrdersCommodity();
    //     this.getFailedOrdersCommodity();
    //     this.getPendingOrdersCommodity();
    //     this.getProgressOrdersCommodity();
    //     this.getCommodityorderscount();
    //   }
    //   else {
    //     this.getSuccessOrdersFuture();
    //     this.getFailedOrdersFuture();
    //     this.getPendingOrdersFuture();
    //     this.getProgressOrdersFuture();
    //     this.getFuturesorderscount();
    //   }
    this.getorderscount();
    this.getAllBucketListOrders(true);
  }

  SwitchMasterMenu(menu: string) {
    this.activeTab = menu;
     this.activeMenu = "";
    this.activeMenuCommodity = "";
   this.activeMenuFuture = "";
    this.searchText = '';
   this.MatchedCount = 0;
    this.highlightedStockTick = '';
     this.PrepDebounce();
    this.timeframe_forOrderList = null;
    if (menu === 'Stocks') {
      // this.activeMenu = "Success"
      // this.successPage = 1;
      // this.getSuccessOrders()
    } else if (menu === 'Commodity') {
      // this.activeMenuCommodity = "Success";
      // this.successPagecommodity = 1;
      // this.getSuccessOrdersCommodity()
    } else if (menu === 'Future') {
      // this.activeMenuFuture = "Success";
      // this.successPageFuture = 1;
      // this.getSuccessOrdersFuture()

    }
  }

  getTimeFrameLabel(time_frame: number) {
    if (this.activeTab == "Stocks") {
      switch (time_frame) {
        case 1: return "Daily";
        case 2: return "60 Minute";
        case 3: return "15 Minute";
        case 25: return "75 Minute";
        case 5: return "125 Minute";
        case 6: return "25 Minute";
        default: return "Unknown";
      }
    }
    else if (this.activeTab == "Commodity") {
      switch (time_frame) {
        case 1: return "Daily";
        case 2: return "240 Minute";
        case 3: return "120 Minute";
        case 4: return "60 Minute";
        default: return "Unknown";
      }
    }
    else if (this.activeTab == "Future") {
      switch (time_frame) {
        case 1: return "Daily";
        case 2: return "60 Minute";
        case 3: return "15 Minute";
        case 25: return "75 Minute";
        default: return "Unknown";
      }
    }
    else {
      return null;
    }
  }

  calculateRR(entry_price: number, stoploss_price: number, target_price: number) {
    const risk = Math.abs(entry_price - stoploss_price);
    const reward = Math.abs(target_price - entry_price);

    if (risk === 0) {
      throw new Error("Stoploss cannot be equal to entry price, risk would be zero.");
    }

    return reward / risk;
  }

  ViewGraph(order_id: any, stock_name: any, entry_price: any, stoploss_price: any, target_price: any, purchased_date: any, completed_on: any, entry_timestamp: any, order_type: any, order_status: any, time_frame: any, expiry_date: any, stock_id: any) {
    this.disconnectWebSocket();
    this.UpdateCnadleStockId = stock_id;
    let container = document.getElementById('chart-container_new');
    if (container) {
      container.innerHTML = ''; // clears old chart
    }
    this.SelectedExpiry = expiry_date
    this.selectedOrderId = order_id;
    this.RRR = this.calculateRR(entry_price, stoploss_price, target_price)
    this.SpinnerCounter = 0;
    this.ViewGraphTimeFrame = time_frame;
    this.QualifiedZoneFlag = true;
    this.ChartRESPONSE = [];
    this.FullChartResponse = [];
    let exchange_type = "";
    this.SETUPREQ = true;
    this.SelectedStockName = stock_name;
    this.showmsg = "Analyzing Data and Generating Your Graph... Please Wait.";
    if (this.activeTab == "Stocks") {
      exchange_type = "cash";
    }
    else if (this.activeTab == "Future") {
      exchange_type = "futures";
    }
    else {
      exchange_type = this.activeTab
    }
    this.apiService.getGraphByOrderService(order_id, this.SelectedCountryName, exchange_type).subscribe(resp => {
      this.FullChartResponse = resp.response;
      if (this.activeTab == "Stocks") {
        // this.getReasonForStocks()
        this.FetchStockZones(stock_name, time_frame, purchased_date, this.FullChartResponse, entry_timestamp, completed_on, entry_price, stoploss_price, target_price, order_type)
      }
      if (this.activeTab == "Commodity") {
        // this.getReasonForCommodity("commodity")
        // this.fetchCommodityZones(stock_name, time_frame, purchased_date, this.FullChartResponse, entry_timestamp, completed_on, entry_price, stoploss_price, target_price, order_type, expiry_date)
      }
      if (this.activeTab == "Future") {
        // this.getReasonForCommodity("futures")
        // this.fetchFutureZones(stock_name, time_frame, purchased_date, this.FullChartResponse, entry_timestamp, completed_on, entry_price, stoploss_price, target_price, order_type, expiry_date)
      }
    })
  }

  FetchStockZones(stock_name: any, time_frame: any, purchased_date: any, resp: any, entry_timestamp: any, completed_on: any, entry_price: any, stoploss_price: any, target_price: any, order_type: any) {
    this.spinner.show();
    this.finData = {
      country: localStorage.getItem('selectedCountryName'),
      tick: stock_name,
      time_frame: time_frame,
      last_d_time: purchased_date
    }
    const originalDateString = this.finData.last_d_time;
    const originalDate = new Date(originalDateString);
    const year = originalDate.getFullYear();
    const month = ('0' + (originalDate.getMonth() + 1)).slice(-2);
    const day = ('0' + originalDate.getDate()).slice(-2);
    const hours = ('0' + originalDate.getHours()).slice(-2);
    const minutes = ('0' + originalDate.getMinutes()).slice(-2);
    const seconds = ('0' + originalDate.getSeconds()).slice(-2);
    const formattedDateString = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
    this.finData.last_d_time = formattedDateString;
    if (time_frame == 1) {
      this.FullScreenModeValue = "daily";
      this.ModalHeader = "daily";
    }
    if (time_frame == 2) {
      this.FullScreenModeValue = "sixty";
      this.ModalHeader = "60 minute";
    }
    if (time_frame == 3) {
      this.FullScreenModeValue = "fifteen";
      this.ModalHeader = "15 minute";
    }
    if (time_frame == 25) {
      this.FullScreenModeValue = "seventy_five";
      this.ModalHeader = "75 minute";
    }
    if (time_frame == 5) {
      this.FullScreenModeValue = "one_twenty_five";
      this.ModalHeader = "125 minute";
    }
    if (time_frame == 6) {
      this.FullScreenModeValue = "twenty_five";
      this.ModalHeader = "25 minute";
    }
    if (this.activeMenu == "Pending") {
      if (this.ViewGraphTimeFrame == 1) {
        this.ChartRESPONSE = [...resp.daily.PRE, ...resp.daily.POST];
      }
      if (this.ViewGraphTimeFrame == 2) {
        this.ChartRESPONSE = [...resp.sixty.PRE, ...resp.sixty.POST];
      }
      if (this.ViewGraphTimeFrame == 3) {
        this.ChartRESPONSE = [...resp.fifteen.PRE, ...resp.fifteen.POST];
      }
      if (this.ViewGraphTimeFrame == 25) {
        this.ChartRESPONSE = [...resp.seventy_five.PRE, ...resp.seventy_five.POST];
      }
      if (this.ViewGraphTimeFrame == 5) {
        this.ChartRESPONSE = [...resp.one_twenty_five.PRE, ...resp.one_twenty_five.POST];
      }
      if (this.ViewGraphTimeFrame == 6) {
        this.ChartRESPONSE = [...resp.twenty_five.PRE, ...resp.twenty_five.POST];
      }
    }
    else if (this.activeMenu == "Progress") {
      if (this.ViewGraphTimeFrame == 1) {
        this.ChartRESPONSE = [...resp.daily.PRE, ...resp.daily.POST];
      }
      if (this.ViewGraphTimeFrame == 2) {
        this.ChartRESPONSE = [...resp.sixty.PRE, ...resp.sixty.POST];
      }
      if (this.ViewGraphTimeFrame == 3) {
        this.ChartRESPONSE = [...resp.fifteen.PRE, ...resp.fifteen.POST];
      }
      if (this.ViewGraphTimeFrame == 25) {
        this.ChartRESPONSE = [...resp.seventy_five.PRE, ...resp.seventy_five.POST];
      }
      if (this.ViewGraphTimeFrame == 5) {
        this.ChartRESPONSE = [...resp.one_twenty_five.PRE, ...resp.one_twenty_five.POST];
      }
      if (this.ViewGraphTimeFrame == 6) {
        this.ChartRESPONSE = [...resp.twenty_five.PRE, ...resp.twenty_five.POST];
      }
    }
    else {
      if (this.ViewGraphTimeFrame == 1) {
        this.ChartRESPONSE = [...resp.daily.PRE, ...resp.daily.POST];
        this.preBars = resp.daily.PRE;
        this.postBars = resp.daily.POST;
      }
      if (this.ViewGraphTimeFrame == 2) {
        this.ChartRESPONSE = [...resp.sixty.PRE, ...resp.sixty.POST];
        this.preBars = resp.sixty.PRE;
        this.postBars = resp.sixty.POST;
      }
      if (this.ViewGraphTimeFrame == 3) {
        this.ChartRESPONSE = [...resp.fifteen.PRE, ...resp.fifteen.POST];
        this.preBars = resp.fifteen.PRE;
        this.postBars = resp.fifteen.POST;
      }
      if (this.ViewGraphTimeFrame == 25) {
        this.ChartRESPONSE = [...resp.seventy_five.PRE, ...resp.seventy_five.POST];
        this.preBars = resp.seventy_five.PRE;
        this.postBars = resp.seventy_five.POST;
      }
      if (this.ViewGraphTimeFrame == 5) {
        this.ChartRESPONSE = [...resp.one_twenty_five.PRE, ...resp.one_twenty_five.POST];
      }
      if (this.ViewGraphTimeFrame == 6) {
        this.ChartRESPONSE = [...resp.twenty_five.PRE, ...resp.twenty_five.POST];
      }
    }
    const promises = [
      // this.GetQualifiedZones(),
      // this.GetAllZones(),
      // this.GetBaseCandleData(),
      // this.GetBuyZoneData(),
      // this.GetSellZoneData(),
      // this.OverLayFetching(),
      // this.BadZones(),
      // this.OptimizedBuySellZoneFunc(),
      this.previousHighService()
    ];
    Promise.all(promises).then(() => {
      const lastRow = this.ChartRESPONSE[this.ChartRESPONSE.length - 1];
      this.lastTime = lastRow.time;
      this.LoadChart(this.ChartRESPONSE, "chart-container_new");
      this.purchased_date = purchased_date;
      this.entry_timestamp = entry_timestamp;
      this.completed_on = completed_on;
      this.entry_price = entry_price;
      this.stoploss_price = stoploss_price;
      this.target_price = target_price;
      this.order_type = order_type;
      this.addPreviousHighPriceLine(this.FullScreenModeValue)
      this.getsetup(this.purchased_date, this.entry_timestamp, this.completed_on, this.entry_price, this.stoploss_price, this.target_price, this.order_type)
      // if (this.activeMenu == "Success" || this.activeMenu == "Failed") {
      //   this.entryMark(
      //     this.barReplaytimestampInSeconds_entry,
      //     this.barReplaytimestampInSeconds_completed,
      //     this.barReplayorder_type
      //   );
      // }
      this.checkboxClicked('qualified_zones')
      this.connectWebSocket(this.FullScreenModeValue)
      this.spinner.hide();
    }).catch((error) => {
      console.error("Error occurred during API calls", error);
      this.spinner.hide();
    })
      ;
  }

  connectWebSocket(type: any): void {
    this.webSocketService.connect(this.finData.tick, this.finData.time_frame, this.UpdateCnadleStockId, type);
    this.webSocketService.getStockMessage().subscribe((data) => {
      this.realTimePrice = data;
      const parsedData = JSON.parse(data);
      if (this.finData.tick === parsedData.data.stock_tick) {
        this.updateChart(data);
      }
    });
  }

  updateChart(data: any): void {
    const parsedData = JSON.parse(data);

    // Convert all fields to numbers
    const updatedCandle = {
      open: Number(parsedData.data.open),
      high: Number(parsedData.data.high),
      low: Number(parsedData.data.low),
      close: Number(parsedData.data.close),
      time: Number(parsedData.data.time),
    };

    // Get existing chart data
    const existingData = this.candlestickSeries.data();
    if (!existingData || existingData.length === 0) {
      // First candle
      this.candlestickSeries.setData([updatedCandle]);
    } else {
      // Remove last candle and append updated one
      const dataWithoutLast = existingData.slice(0, -1);
      const newSeriesData = [...dataWithoutLast, updatedCandle];

      // ---- Add postbars after last real candle ----
      const lastCandle = newSeriesData[newSeriesData.length - 1];
      const postbars = [...new Array(100)].map((_, i) => ({
        time: lastCandle.time + (i + 1) * this.xspan,
      }));

      // Combine
      // const finalSeries = [...newSeriesData, ...postbars];

      // Set to chart
      this.candlestickSeries.setData([...newSeriesData, ...postbars]);
    }

    // Update lastBar reference
    this.lastBar = updatedCandle;

    // Optional: update closing line
    this.CreateClosingLine(updatedCandle.close);
  }

  previousHighService() {
    this.apiService.GetprevioushighDataService(this.finData).subscribe(resp => {
      this.PreviousHighData = resp.response;
      console.log(`RESPONSE 7 (PREVIOUS HIGH) :`, this.PreviousHighData);
    })
  }

  previousHighServiceForMcxNsefo(exchange:any) {
    console.log("PH",this.finData)
    this.apiService.GetprevioushighDataMcxNsefoService(this.finData,exchange).subscribe(resp => {
      this.PreviousHighData = resp.response;
      console.log(`RESPONSE 7 (PREVIOUS HIGH) :`, this.PreviousHighData);
    })
  }

  addPreviousHighPriceLine(key: any) {
    // Check if data exists for the given key
    if (!this.PreviousHighData || !this.PreviousHighData[key]) {
      return; // key not found, bypass silently
    }

    const previousHigh = this.PreviousHighData[key].previous_high;

    // Extra safeguard if previous_high is missing
    if (!previousHigh || previousHigh.price == null) {
      return;
    }

    const myPriceLine = {
      price: previousHigh.price,
      color: '#f5d131',
      lineWidth: 2,
      lineStyle: 2,
      axisLabelVisible: true,
      title: 'Previous High',
    };

    this.candlestickSeries.createPriceLine(myPriceLine);
  }

  CreateClosingLine(price: any) {
    if (this.lastCMPLine) {
      this.candlestickSeries.removePriceLine(this.lastCMPLine);
    }
    const ClosingPrice = price;
    const ClosingPriceLine = {
      price: ClosingPrice,
      color: 'green',
      lineWidth: 1,
      lineStyle: 1,
      axisLabelVisible: true,
      title: 'CMP',
    };
    this.lastCMPLine = this.candlestickSeries.createPriceLine(ClosingPriceLine);
  }

  calculateMovingAverageSeriesData(candleData: any, maLength: any) {
    const maData = [];
    for (let i = 0; i < candleData.length; i++) {
      if (i < maLength) {
        maData.push({ time: candleData[i].time });
      } else {
        let sum = 0;
        for (let j = 0; j < maLength; j++) {
          sum += candleData[i - j].close;
        }
        const maValue = sum / maLength;
        maData.push({ time: candleData[i].time, value: maValue });
      }
    }
    return maData;
  }

  LoadChart(data: any, chartId: any) {
    let chart = null;

    const chartProperties = {
      timeScale: {
        timeVisible: true,
        secondsVisible: false,
        rightOffset: 0,
      },
      crosshair: {
        mode: CrosshairMode.Normal
      },
      priceScale: {
        borderVisible: false,
        autoScale: true,
      }
    };

    const chartOptions = {
      layout: { textColor: 'black', background: { type: 'solid', color: 'white' } }
    };

    chart = createChart(document.getElementById(chartId)!, {
      ...chartProperties,
      layout: {
        background: {
          color: '#f0ffff',  // Background color
        },
      },
    });

    chart.applyOptions({
      watermark: {
        visible: true,
        fontSize: 35,
        horzAlign: 'right',
        vertAlign: 'bottom',
        color: 'rgb(128, 128, 128)',
        text: 'FIN PRODUCT BY ISPECK ',
      },
      grid: {
        vertLines: { visible: false }, // Disable vertical grid lines
        horzLines: { visible: false }, // Disable horizontal grid lines
      },
    });

    this.candlestickSeries = chart.addCandlestickSeries({
      upColor: '#1B880C',
      downColor: '#D90000',
      borderVisible: false,
      wickUpColor: '#26a69a',
      wickDownColor: '#ef5350',
    });

    const postbars = [...new Array(100)].map((_, i) => ({
      time: data[data.length - 1].time + (i + 1) * this.xspan,
    }));
    this.allData = data;
    this.candlestickSeries.setData([...data, ...postbars]);

    // Adjust the price scale to "squeeze" the chart vertically, increasing candle height
    chart.priceScale('right').applyOptions({
      scaleMargins: {
        top: 0.01, // Reduce the top margin for the price scale
        bottom: 0.01, // Reduce the bottom margin to squeeze candles vertically
      },
      autoScale: true, // Ensure auto-scaling continues to work
    });

    chart.timeScale().fitContent();

    // Tool for drawing rectangles
    this.rectangleTool = new RectangleDrawingTool(
      chart,
      this.candlestickSeries,
      document.querySelector<HTMLDivElement>('#toolbar')!,
      { showLabels: false }
    );

    // EMA
    const maData = this.calculateMovingAverageSeriesData(data, 20);
    const maSeries = chart.addLineSeries({ color: '#2962FF', lineWidth: 1, title: 'EMA 20' });
    maSeries.setData(maData);

    // TOOLTIP
    chart.subscribeCrosshairMove(param => {
      if (param.time) {
        const seriesPrices = param.seriesData.get(this.candlestickSeries);
        if (seriesPrices) {
          this.toolTipData = seriesPrices;
          this.Open = this.toolTipData.open.toFixed(2);
          this.Close = this.toolTipData.close.toFixed(2);
          this.High = this.toolTipData.high.toFixed(2);
          this.Low = this.toolTipData.low.toFixed(2);
          this.CandleColor = this.Close > this.Open ? "green" : "red";
        } else {
          this.Open = "";
          this.Close = "";
          this.High = "";
          this.Low = "";
        }
      }
    });

    this.chart = chart;
    // if (this.activeMenu == "Pending") {
    const lastRow = data.slice(-1)[0];
    this.CreateClosingLine(lastRow.close)
    // }
  }

  CloseFullModal() {
    this.allData = []
    this.preBars = []
    this.postBars = []
    this.reasons = [];

    this.ReplayFlag = false;
    this.ModelPrediction = "";
    this.cleanupChart();
    this.disconnectWebSocket()
    //  this.selectedOption = '';
    this.dropdownShow = false;
    this.selectedOptions = {
      base_candle: false,
      buy_sell_zone: false,
      bad_zone: false,
      setup: false,
    };
    const leftBar = document.getElementById('leftBar');
    if (leftBar!.classList.contains('open')) {
      leftBar!.classList.remove('open');
    }
  }

  cleanupChart() {
    if (this.chart) {
      this.chart.remove();
      this.chart = null;
    }
  }

  openBar(isOpen: boolean) {
    const leftPanel = document.getElementById('leftPanel');
    if (leftPanel) {
      leftPanel.classList.remove('open');
    }

    const leftBar = document.getElementById('leftBar');
    if (!leftBar) return;

    if (isOpen) {
      const windowHeight: number = window.innerHeight;
      const targetHeight: number = 80;
      leftBar.style.top = `${targetHeight}px`;
      leftBar.style.height = `${windowHeight - targetHeight}px`;
      leftBar.style.overflowY = 'auto';
      leftBar.classList.add('open');
    } else {
      leftBar.classList.remove('open');
    }
  }

  getsetup(purchased_date: any, entry_timestamp: any, completed_on: any, entry_price: any, stoploss_price: any, target_price: any, order_type: any) {
    const entryddateObject3 = new Date(purchased_date + 'Z');
    const istOffset3 = 5.5 * 60 * 60 * 1000;
    const istDateObject3 = new Date(entryddateObject3.getTime() + istOffset3);
    const year1 = istDateObject3.getUTCFullYear();
    const month1 = String(istDateObject3.getUTCMonth() + 1).padStart(2, '0');
    const day1 = String(istDateObject3.getUTCDate()).padStart(2, '0');
    const purchaseddateOnly1 = `${year1}-${month1}-${day1}`;
    const PurchaseddateObjectNumber = new Date(purchaseddateOnly1);
    const timestampInMilliseconds = PurchaseddateObjectNumber.getTime();
    const timestampInSeconds_purchased = Math.floor(timestampInMilliseconds / 1000);


    const entryddateObject = new Date(entry_timestamp + 'Z');
    const istOffset = 5.5 * 60 * 60 * 1000;
    const istDateObject = new Date(entryddateObject.getTime() + istOffset);
    const year3 = istDateObject.getUTCFullYear();
    const month3 = String(istDateObject.getUTCMonth() + 1).padStart(2, '0');
    const day3 = String(istDateObject.getUTCDate()).padStart(2, '0');
    const hours3 = String(istDateObject.getUTCHours()).padStart(2, '0');
    const minutes3 = String(istDateObject.getUTCMinutes()).padStart(2, '0');
    const seconds3 = String(istDateObject.getUTCSeconds()).padStart(2, '0');
    const entryddateOnly = `${year3}-${month3}-${day3} ${hours3}:${minutes3}:${seconds3}`;
    const entrydateObjectNumber = new Date(entryddateOnly);
    const timestampInMillisecondsss = entrydateObjectNumber.getTime();
    const timestampInSeconds_entry = Math.floor(timestampInMillisecondsss / 1000);

    // const CompleteddateObject = new Date(
    //   new Date(
    //     completed_on ? completed_on + 'Z' : new Date().toISOString().split('T')[0] + 'T00:00:00.000Z'
    //   ).getTime() + 10 * 24 * 60 * 60 * 1000
    // );

    const CompleteddateObject = new Date(
      completed_on ? completed_on + 'Z' : new Date().toISOString().split('T')[0] + 'T00:00:00.000Z'
    )

    // if(this.activeMenu=="Progress" || this.activeMenu=="Pending" || this.activeMenuCommodity=="Progress" ||
    //    this.activeMenuCommodity=="Pending" || this.activeMenuFuture=="Progress" || this.activeMenuFuture=="Pending")
    // {
    //   let adjustedTimestamp = timestampInSeconds_purchased;
    //   if (this.ViewGraphTimeFrame == 1) {
    //     // add 30 days
    //     adjustedTimestamp += 30 * 24 * 60 * 60;
    //   } else if (this.ViewGraphTimeFrame == 2) {
    //     // add 720 hours (30 days)
    //     adjustedTimestamp += 720 * 60 * 60;
    //   } else if (this.ViewGraphTimeFrame == 3) {
    //     // add 720 hours again (same as case 2)
    //     adjustedTimestamp += 720 * 60 * 60;
    //   }else if (this.ViewGraphTimeFrame == 25) {
    //     // add 720 hours again (same as case 2)
    //     adjustedTimestamp += 720 * 60 * 60;
    //   }else if (this.ViewGraphTimeFrame == 4) {
    //     // add 720 hours again (same as case 2)
    //     adjustedTimestamp += 720 * 60 * 60;
    //   }
    //   else if (this.ViewGraphTimeFrame == 5) {
    //     // add 720 hours again (same as case 2)
    //     adjustedTimestamp += 720 * 60 * 60;
    //   }else if (this.ViewGraphTimeFrame == 6) {
    //     // add 720 hours again (same as case 2)
    //     adjustedTimestamp += 720 * 60 * 60;
    //   }
    //   this.timestampInSeconds_completed = adjustedTimestamp;
    //   console.log("Final Adjusted Timestamp (in seconds):", this.timestampInSeconds_completed);
    // }
    //     else{
    //  // const CompleteddateObject = new Date(completed_on + 'Z');
    //     const istOffset2 = 5.5 * 60 * 60 * 1000;
    //     const istDateObject2 = new Date(CompleteddateObject.getTime() + istOffset2);
    //     const year2 = istDateObject2.getUTCFullYear();
    //     const month2 = String(istDateObject2.getUTCMonth() + 1).padStart(2, '0');
    //     const day2 = String(istDateObject2.getUTCDate()).padStart(2, '0');
    //     const hours2 = String(istDateObject2.getUTCHours()).padStart(2, '0');
    //     const minutes2 = String(istDateObject2.getUTCMinutes()).padStart(2, '0');
    //     const seconds2 = String(istDateObject2.getUTCSeconds()).padStart(2, '0');
    //     const entryddateOnly2 = `${year2}-${month2}-${day2} ${hours2}:${minutes2}:${seconds2}`;
    //     const completeddateObjectNumber = new Date(entryddateOnly2);
    //     const timestampInMillisecondss = completeddateObjectNumber.getTime();
    //     this.timestampInSeconds_completed = Math.floor(timestampInMillisecondss / 1000);
    //     }




    // this.addEntryPriceLine(entry_price, timestampInSeconds_purchased, this.timestampInSeconds_completed)
    // this.addStoplossPriceLine(stoploss_price, timestampInSeconds_purchased, this.timestampInSeconds_completed)
    // this.addTargetPriceLine(target_price, timestampInSeconds_purchased, this.timestampInSeconds_completed)


    // if (this.activeMenu == "Success" || this.activeMenuCommodity == "Success" || this.activeMenuFuture == "Success") {
    //   this.barReplaytimestampInSeconds_completed = this.timestampInSeconds_completed;
    //   this.barReplaytimestampInSeconds_entry = timestampInSeconds_entry;
    //   this.barReplayorder_type = order_type;
    //   // this.entryMark(timestampInSeconds_entry, this.timestampInSeconds_completed, order_type);
    // }
    // if (this.activeMenu == "Failed" || this.activeMenuCommodity == "Failed" || this.activeMenuFuture == "Failed") {
    //   this.barReplaytimestampInSeconds_completed = this.timestampInSeconds_completed;
    //   this.barReplaytimestampInSeconds_entry = timestampInSeconds_entry;
    //   this.barReplayorder_type = order_type;
    //   // this.stoplossMark(timestampInSeconds_entry, this.timestampInSeconds_completed, order_type)
    // }

    // if (this.activeMenu == "Pending") {
    //   this.barReplaytimestampInSeconds_completed = this.timestampInSeconds_completed;
    //   this.barReplaytimestampInSeconds_entry = timestampInSeconds_entry;
    //   this.barReplayorder_type = order_type;
    //   this.addEntryPriceLine(entry_price, timestampInSeconds_purchased, this.lastTime)
    //   this.addStoplossPriceLine(stoploss_price, timestampInSeconds_purchased, this.lastTime)
    //   this.addTargetPriceLine(target_price, timestampInSeconds_purchased, this.lastTime)
    //   // this.entryMark(timestampInSeconds_entry, this.lastTime, order_type);
    // }
    // this.candlestickSeries.setMarkers([]);

    if (this.SETUPREQ) {
      // if(this.activeTab== "Stocks"){
      //      if(this.activeMenu == "Failed" || this.activeMenu == "Success"){
      //    this.entryMark(
      //     this.barReplaytimestampInSeconds_entry,
      //     this.barReplaytimestampInSeconds_completed,
      //     this.barReplayorder_type
      //   );
      // }
      // if(this.activeMenu == "Progress"){
      //    this.entryMark(
      //     this.barReplaytimestampInSeconds_entry,
      //     this.barReplaytimestampInSeconds_completed,
      //     this.barReplayorder_type
      //   );
      // }
      // }

      // if(this.activeTab== "Commodity"){
      //      if(this.activeMenuCommodity == "Failed" || this.activeMenuCommodity == "Success"){
      //    this.entryMark(
      //     this.barReplaytimestampInSeconds_entry,
      //     this.barReplaytimestampInSeconds_completed,
      //     this.barReplayorder_type
      //   );
      // }
      // if(this.activeMenuCommodity == "Progress"){
      //    this.entryMark(
      //     this.barReplaytimestampInSeconds_entry,
      //     this.barReplaytimestampInSeconds_completed,
      //     this.barReplayorder_type
      //   );
      // }
      // }

      // if(this.activeTab== "Future"){
      //      if(this.activeMenuFuture == "Failed" || this.activeMenuFuture == "Success"){
      //    this.entryMark(
      //     this.barReplaytimestampInSeconds_entry,
      //     this.barReplaytimestampInSeconds_completed,
      //     this.barReplayorder_type
      //   );
      // }
      // if(this.activeMenuFuture == "Progress"){
      //    this.entryMark(
      //     this.barReplaytimestampInSeconds_entry,
      //     this.barReplaytimestampInSeconds_completed,
      //     this.barReplayorder_type
      //   );
      // }
      // }

      // if (this.activeMenu == "Failed" || this.activeMenuCommodity == "Failed" || this.activeMenuFuture == "Failed") {
      //   this.entryMark(
      //     this.barReplaytimestampInSeconds_entry,
      //     this.barReplaytimestampInSeconds_completed,
      //     this.barReplayorder_type
      //   );
      // }
      // if (this.activeMenu == "Success" || this.activeMenuCommodity == "Success" || this.activeMenuFuture == "Success") {
      //   this.entryMark(
      //     this.barReplaytimestampInSeconds_entry,
      //     this.barReplaytimestampInSeconds_completed,
      //     this.barReplayorder_type
      //   );
      // }
    }
  }

  checkboxClicked(option: string) {
    this.candlestickSeries.setMarkers([]);
    this.selectedOptions[option] = !this.selectedOptions[option];
    let result = this.checkOptions();
    if (result == false) {
      this.rectangleTool.removeAllRectangles()

      if (this.selectedOptions['qualified_zones']) {
        this.showmsg = "Analyzing Qualified Zones !";
        this.ModelPrediction = "";
        const buy_array = this.QualifiedData["Buy"];
        const fillColorBuy = 'rgba(0,255,0,0.2)';
        for (let item of Object.values(buy_array)) {
          this.rectangleTool.addRectanglesFromData(item, fillColorBuy);
        }
        const fillColorSell = 'rgba(255,51,51,0.2)';
        var sell_array = this.QualifiedData["Sell"];
        for (let item of Object.values(sell_array)) {
          this.rectangleTool.addRectanglesFromData(item, fillColorSell);
        }
        // this.getsetup(this.purchased_date, this.entry_timestamp, this.completed_on, this.entry_price, this.stoploss_price, this.target_price, this.order_type)
      }
      if (this.selectedOptions['all_zones']) {
        this.showmsg = "Analyzing All Zones !";
        this.ModelPrediction = "";
        const array = this.AllZonesData[this.FullScreenModeValue];
        const fillColorBuy = 'rgba(50,50,50,0.5)';
        var buy_array = array['Buy'];
        for (let item of Object.values(buy_array)) {
          this.rectangleTool.addRectanglesFromData(item, fillColorBuy);
        }
        const fillColorSell = 'rgba(50,50,50,0.5)';
        var sell_array = array['Sell'];
        for (let item of Object.values(sell_array)) {
          this.rectangleTool.addRectanglesFromData(item, fillColorSell);
        }
        // this.getsetup(this.purchased_date, this.entry_timestamp, this.completed_on, this.entry_price, this.stoploss_price, this.target_price, this.order_type)
      }
      if (this.selectedOptions['base_candle']) {
        this.showmsg = "Analyzing Base Candles !";
        const BaseMarkers = [];
        this.ModelPrediction = "";
        const fillColor = 'rgba(51,153,255,0.3)';
        const array = this.BaseCandleData[this.FullScreenModeValue];
        for (let item of array) {
          BaseMarkers.push({
            time: item,
            position: 'aboveBar',
            color: 'blue',
            shape: 'arrowDown',
            text: "B",
          });
        }
        this.candlestickSeries.setMarkers(BaseMarkers);
        // this.getsetup(this.purchased_date, this.entry_timestamp, this.completed_on, this.entry_price, this.stoploss_price, this.target_price, this.order_type)
      }
      if (this.selectedOptions['buy_sell_zone']) {
        this.showmsg = "Analyzing Buy/Sell Zones !";
        this.ModelPrediction = "";
        const fillColorBuy = 'rgba(0,255,0,0.2)';
        var buy_array = this.BuyZoneData[this.FullScreenModeValue];
        for (let item of Object.values(buy_array)) {
          this.rectangleTool.addRectanglesFromData(item, fillColorBuy);
        }
        const fillColorSell = 'rgba(255,51,51,0.2)';
        var sell_array = this.SellZoneData[this.FullScreenModeValue];
        for (let item of Object.values(sell_array)) {
          this.rectangleTool.addRectanglesFromData(item, fillColorSell);
        }
        // this.getsetup(this.purchased_date, this.entry_timestamp, this.completed_on, this.entry_price, this.stoploss_price, this.target_price, this.order_type)
      }
      if (this.selectedOptions['bad_zone']) {
        this.ModelPrediction = "";
        let array = this.BadZoneData[this.FullScreenModeValue]
        const fillColor = "rgba(41, 3, 3, 0.21)"
        for (let item of Object.values(array)) {
          this.rectangleTool.addRectanglesFromData(item, fillColor);
        }
        // this.getsetup(this.purchased_date, this.entry_timestamp, this.completed_on, this.entry_price, this.stoploss_price, this.target_price, this.order_type)
      }
      if (this.selectedOptions['optimized_buy_sell_zone']) {
        const fillColorBuy = 'rgba(0,255,0,0.2)';
        var buy_array = this.OptimizedBuySellZoneData[this.FullScreenModeValue];
        for (let item of Object.values(buy_array.BUY)) {
          this.rectangleTool.addRectanglesFromData(item, fillColorBuy);
        }
        const fillColorSell = 'rgba(255,51,51,0.2)';
        var sell_array = this.OptimizedBuySellZoneData[this.FullScreenModeValue];
        for (let item of Object.values(sell_array.SELL)) {
          this.rectangleTool.addRectanglesFromData(item, fillColorSell);
        }
      }
      if (this.selectedOptions['overlap_evaluate']) {

        if (this.activeTab == "Stocks") {

          if (this.finData.time_frame == 1) {
            const fillColorBuy = 'rgba(0,59,0,0.2)';
            var buy_array = this.BuyOverlayData['monthly'];
            for (let item of Object.values(buy_array)) {
              this.rectangleTool.addRectanglesFromData(item, fillColorBuy);
            }
            const fillColorSell = 'rgba(255,51,51,0.2)';
            var sell_array = this.SellOverlayData['monthly'];
            for (let item of Object.values(sell_array)) {
              this.rectangleTool.addRectanglesFromData(item, fillColorSell);
            }
            // this.getsetup(this.purchased_date, this.entry_timestamp, this.completed_on, this.entry_price, this.stoploss_price, this.target_price, this.order_type)
          }

          if (this.finData.time_frame == 2) {
            const fillColorBuy = 'rgba(0,59,0,0.2)';
            var buy_array = this.BuyOverlayData['weekly'];
            for (let item of Object.values(buy_array)) {
              this.rectangleTool.addRectanglesFromData(item, fillColorBuy);
            }
            const fillColorSell = 'rgba(255,51,51,0.2)';
            var sell_array = this.SellOverlayData['weekly'];
            for (let item of Object.values(sell_array)) {
              this.rectangleTool.addRectanglesFromData(item, fillColorSell);
            }
            // this.getsetup(this.purchased_date, this.entry_timestamp, this.completed_on, this.entry_price, this.stoploss_price, this.target_price, this.order_type)
          }

          if (this.finData.time_frame == 3) {
            const fillColorBuy = 'rgba(0,59,0,0.2)';
            var buy_array = this.BuyOverlayData['daily'];
            for (let item of Object.values(buy_array)) {
              this.rectangleTool.addRectanglesFromData(item, fillColorBuy);
            }
            const fillColorSell = 'rgba(255,51,51,0.2)';
            var sell_array = this.SellOverlayData['daily'];
            for (let item of Object.values(sell_array)) {
              this.rectangleTool.addRectanglesFromData(item, fillColorSell);
            }
            // this.getsetup(this.purchased_date, this.entry_timestamp, this.completed_on, this.entry_price, this.stoploss_price, this.target_price, this.order_type)
          }

          if (this.finData.time_frame == 25) {
            const fillColorBuy = 'rgba(0,59,0,0.2)';
            var buy_array = this.BuyOverlayData['weekly'];
            for (let item of Object.values(buy_array)) {
              this.rectangleTool.addRectanglesFromData(item, fillColorBuy);
            }
            const fillColorSell = 'rgba(255,51,51,0.2)';
            var sell_array = this.SellOverlayData['weekly'];
            for (let item of Object.values(sell_array)) {
              this.rectangleTool.addRectanglesFromData(item, fillColorSell);
            }
            // this.getsetup(this.purchased_date, this.entry_timestamp, this.completed_on, this.entry_price, this.stoploss_price, this.target_price, this.order_type)
          }

          if (this.finData.time_frame == 5) {
            const fillColorBuy = 'rgba(0,59,0,0.2)';
            var buy_array = this.BuyOverlayData['weekly'];
            for (let item of Object.values(buy_array)) {
              this.rectangleTool.addRectanglesFromData(item, fillColorBuy);
            }
            const fillColorSell = 'rgba(255,51,51,0.2)';
            var sell_array = this.SellOverlayData['weekly'];
            for (let item of Object.values(sell_array)) {
              this.rectangleTool.addRectanglesFromData(item, fillColorSell);
            }
            // this.getsetup(this.purchased_date, this.entry_timestamp, this.completed_on, this.entry_price, this.stoploss_price, this.target_price, this.order_type)
          }

          if (this.finData.time_frame == 6) {
            const fillColorBuy = 'rgba(0,59,0,0.2)';
            var buy_array = this.BuyOverlayData['daily'];
            for (let item of Object.values(buy_array)) {
              this.rectangleTool.addRectanglesFromData(item, fillColorBuy);
            }
            const fillColorSell = 'rgba(255,51,51,0.2)';
            var sell_array = this.SellOverlayData['daily'];
            for (let item of Object.values(sell_array)) {
              this.rectangleTool.addRectanglesFromData(item, fillColorSell);
            }
            // this.getsetup(this.purchased_date, this.entry_timestamp, this.completed_on, this.entry_price, this.stoploss_price, this.target_price, this.order_type)
          }
        }

        if (this.activeTab == "Commodity") {

          if (this.finData.time_frame == 1) {
            const fillColorBuy = 'rgba(0,59,0,0.2)';
            var buy_array = this.BuyOverlayData['monthly'];
            for (let item of Object.values(buy_array)) {
              this.rectangleTool.addRectanglesFromData(item, fillColorBuy);
            }
            const fillColorSell = 'rgba(255,51,51,0.2)';
            var sell_array = this.SellOverlayData['monthly'];
            for (let item of Object.values(sell_array)) {
              this.rectangleTool.addRectanglesFromData(item, fillColorSell);
            }
            // this.getsetup(this.purchased_date, this.entry_timestamp, this.completed_on, this.entry_price, this.stoploss_price, this.target_price, this.order_type)
          }

          if (this.finData.time_frame == 2) {
            const fillColorBuy = 'rgba(0,59,0,0.2)';
            var buy_array = this.BuyOverlayData['weekly'];
            for (let item of Object.values(buy_array)) {
              this.rectangleTool.addRectanglesFromData(item, fillColorBuy);
            }
            const fillColorSell = 'rgba(255,51,51,0.2)';
            var sell_array = this.SellOverlayData['weekly'];
            for (let item of Object.values(sell_array)) {
              this.rectangleTool.addRectanglesFromData(item, fillColorSell);
            }
            // this.getsetup(this.purchased_date, this.entry_timestamp, this.completed_on, this.entry_price, this.stoploss_price, this.target_price, this.order_type)
          }

          if (this.finData.time_frame == 3) {
            const fillColorBuy = 'rgba(0,59,0,0.2)';
            var buy_array = this.BuyOverlayData['daily'];
            for (let item of Object.values(buy_array)) {
              this.rectangleTool.addRectanglesFromData(item, fillColorBuy);
            }
            const fillColorSell = 'rgba(255,51,51,0.2)';
            var sell_array = this.SellOverlayData['daily'];
            for (let item of Object.values(sell_array)) {
              this.rectangleTool.addRectanglesFromData(item, fillColorSell);
            }
            // this.getsetup(this.purchased_date, this.entry_timestamp, this.completed_on, this.entry_price, this.stoploss_price, this.target_price, this.order_type)
          }

          if (this.finData.time_frame == 4) {
            const fillColorBuy = 'rgba(0,59,0,0.2)';
            var buy_array = this.BuyOverlayData['daily'];
            for (let item of Object.values(buy_array)) {
              this.rectangleTool.addRectanglesFromData(item, fillColorBuy);
            }
            const fillColorSell = 'rgba(255,51,51,0.2)';
            var sell_array = this.SellOverlayData['daily'];
            for (let item of Object.values(sell_array)) {
              this.rectangleTool.addRectanglesFromData(item, fillColorSell);
            }
            // this.getsetup(this.purchased_date, this.entry_timestamp, this.completed_on, this.entry_price, this.stoploss_price, this.target_price, this.order_type)
          }

        }

        if (this.activeTab == "Future") {

          if (this.finData.time_frame == 1) {
            const fillColorBuy = 'rgba(0,59,0,0.2)';
            var buy_array = this.BuyOverlayData['monthly'];
            for (let item of Object.values(buy_array)) {
              this.rectangleTool.addRectanglesFromData(item, fillColorBuy);
            }
            const fillColorSell = 'rgba(255,51,51,0.2)';
            var sell_array = this.SellOverlayData['monthly'];
            for (let item of Object.values(sell_array)) {
              this.rectangleTool.addRectanglesFromData(item, fillColorSell);
            }
            // this.getsetup(this.purchased_date, this.entry_timestamp, this.completed_on, this.entry_price, this.stoploss_price, this.target_price, this.order_type)
          }

          if (this.finData.time_frame == 2) {
            const fillColorBuy = 'rgba(0,59,0,0.2)';
            var buy_array = this.BuyOverlayData['weekly'];
            for (let item of Object.values(buy_array)) {
              this.rectangleTool.addRectanglesFromData(item, fillColorBuy);
            }
            const fillColorSell = 'rgba(255,51,51,0.2)';
            var sell_array = this.SellOverlayData['weekly'];
            for (let item of Object.values(sell_array)) {
              this.rectangleTool.addRectanglesFromData(item, fillColorSell);
            }
            // this.getsetup(this.purchased_date, this.entry_timestamp, this.completed_on, this.entry_price, this.stoploss_price, this.target_price, this.order_type)
          }

          if (this.finData.time_frame == 3) {
            const fillColorBuy = 'rgba(0,59,0,0.2)';
            var buy_array = this.BuyOverlayData['daily'];
            for (let item of Object.values(buy_array)) {
              this.rectangleTool.addRectanglesFromData(item, fillColorBuy);
            }
            const fillColorSell = 'rgba(255,51,51,0.2)';
            var sell_array = this.SellOverlayData['daily'];
            for (let item of Object.values(sell_array)) {
              this.rectangleTool.addRectanglesFromData(item, fillColorSell);
            }
            // this.getsetup(this.purchased_date, this.entry_timestamp, this.completed_on, this.entry_price, this.stoploss_price, this.target_price, this.order_type)
          }

          if (this.finData.time_frame == 25) {
            const fillColorBuy = 'rgba(0,59,0,0.2)';
            var buy_array = this.BuyOverlayData['weekly'];
            for (let item of Object.values(buy_array)) {
              this.rectangleTool.addRectanglesFromData(item, fillColorBuy);
            }
            const fillColorSell = 'rgba(255,51,51,0.2)';
            var sell_array = this.SellOverlayData['weekly'];
            for (let item of Object.values(sell_array)) {
              this.rectangleTool.addRectanglesFromData(item, fillColorSell);
            }
            // this.getsetup(this.purchased_date, this.entry_timestamp, this.completed_on, this.entry_price, this.stoploss_price, this.target_price, this.order_type)
          }
        }

      }
      if (this.selectedOptions['overlap_analyze']) {

        if (this.activeTab == "Stocks") {

          if (this.finData.time_frame == 1) {
            const fillColorBuy = 'rgba(0,255,0,0.2)';
            var buy_array = this.BuyOverlayData['weekly'];
            for (let item of Object.values(buy_array)) {
              this.rectangleTool.addRectanglesFromData(item, fillColorBuy);
            }
            const fillColorSell = 'rgba(255,51,51,0.2)';
            var sell_array = this.SellOverlayData['weekly'];
            for (let item of Object.values(sell_array)) {
              this.rectangleTool.addRectanglesFromData(item, fillColorSell);
            }
            // this.getsetup(this.purchased_date, this.entry_timestamp, this.completed_on, this.entry_price, this.stoploss_price, this.target_price, this.order_type)
          }

          if (this.finData.time_frame == 2) {
            const fillColorBuy = 'rgba(0,255,0,0.2)';
            var buy_array = this.BuyOverlayData['daily'];
            for (let item of Object.values(buy_array)) {
              this.rectangleTool.addRectanglesFromData(item, fillColorBuy);
            }
            const fillColorSell = 'rgba(255,51,51,0.2)';
            var sell_array = this.SellOverlayData['daily'];
            for (let item of Object.values(sell_array)) {
              this.rectangleTool.addRectanglesFromData(item, fillColorSell);
            }
            // this.getsetup(this.purchased_date, this.entry_timestamp, this.completed_on, this.entry_price, this.stoploss_price, this.target_price, this.order_type)
          }

          if (this.finData.time_frame == 3) {
            const fillColorBuy = 'rgba(0,255,0,0.2)';
            var buy_array = this.BuyOverlayData['sixty'];
            for (let item of Object.values(buy_array)) {
              this.rectangleTool.addRectanglesFromData(item, fillColorBuy);
            }
            const fillColorSell = 'rgba(255,51,51,0.2)';
            var sell_array = this.SellOverlayData['sixty'];
            for (let item of Object.values(sell_array)) {
              this.rectangleTool.addRectanglesFromData(item, fillColorSell);
            }
            // this.getsetup(this.purchased_date, this.entry_timestamp, this.completed_on, this.entry_price, this.stoploss_price, this.target_price, this.order_type)
          }

           if (this.finData.time_frame == 25) {
            const fillColorBuy = 'rgba(0,255,0,0.2)';
            var buy_array = this.BuyOverlayData['daily'];
            for (let item of Object.values(buy_array)) {
              this.rectangleTool.addRectanglesFromData(item, fillColorBuy);
            }
            const fillColorSell = 'rgba(255,51,51,0.2)';
            var sell_array = this.SellOverlayData['daily'];
            for (let item of Object.values(sell_array)) {
              this.rectangleTool.addRectanglesFromData(item, fillColorSell);
            }
            // this.getsetup(this.purchased_date, this.entry_timestamp, this.completed_on, this.entry_price, this.stoploss_price, this.target_price, this.order_type)
          }
          if (this.finData.time_frame == 5) {
            const fillColorBuy = 'rgba(0,255,0,0.2)';
            var buy_array = this.BuyOverlayData['daily'];
            for (let item of Object.values(buy_array)) {
              this.rectangleTool.addRectanglesFromData(item, fillColorBuy);
            }
            const fillColorSell = 'rgba(255,51,51,0.2)';
            var sell_array = this.SellOverlayData['daily'];
            for (let item of Object.values(sell_array)) {
              this.rectangleTool.addRectanglesFromData(item, fillColorSell);
            }
            // this.getsetup(this.purchased_date, this.entry_timestamp, this.completed_on, this.entry_price, this.stoploss_price, this.target_price, this.order_type)
          }

          if (this.finData.time_frame == 6) {
            const fillColorBuy = 'rgba(0,255,0,0.2)';
            var buy_array = this.BuyOverlayData['one_twenty_five'];
            for (let item of Object.values(buy_array)) {
              this.rectangleTool.addRectanglesFromData(item, fillColorBuy);
            }
            const fillColorSell = 'rgba(255,51,51,0.2)';
            var sell_array = this.SellOverlayData['one_twenty_five'];
            for (let item of Object.values(sell_array)) {
              this.rectangleTool.addRectanglesFromData(item, fillColorSell);
            }
            // this.getsetup(this.purchased_date, this.entry_timestamp, this.completed_on, this.entry_price, this.stoploss_price, this.target_price, this.order_type)
          }
        }

        if (this.activeTab == "Commodity") {

          if (this.finData.time_frame == 1) {
            const fillColorBuy = 'rgba(0,59,0,0.2)';
            var buy_array = this.BuyOverlayData['weekly'];
            for (let item of Object.values(buy_array)) {
              this.rectangleTool.addRectanglesFromData(item, fillColorBuy);
            }
            const fillColorSell = 'rgba(255,51,51,0.2)';
            var sell_array = this.SellOverlayData['weekly'];
            for (let item of Object.values(sell_array)) {
              this.rectangleTool.addRectanglesFromData(item, fillColorSell);
            }
            // this.getsetup(this.purchased_date, this.entry_timestamp, this.completed_on, this.entry_price, this.stoploss_price, this.target_price, this.order_type)
          }

          if (this.finData.time_frame == 2) {
            const fillColorBuy = 'rgba(0,59,0,0.2)';
            var buy_array = this.BuyOverlayData['daily'];
            for (let item of Object.values(buy_array)) {
              this.rectangleTool.addRectanglesFromData(item, fillColorBuy);
            }
            const fillColorSell = 'rgba(255,51,51,0.2)';
            var sell_array = this.SellOverlayData['daily'];
            for (let item of Object.values(sell_array)) {
              this.rectangleTool.addRectanglesFromData(item, fillColorSell);
            }
            // this.getsetup(this.purchased_date, this.entry_timestamp, this.completed_on, this.entry_price, this.stoploss_price, this.target_price, this.order_type)
          }

          if (this.finData.time_frame == 3) {
            const fillColorBuy = 'rgba(0,59,0,0.2)';
            var buy_array = this.BuyOverlayData['two_forty'];
            for (let item of Object.values(buy_array)) {
              this.rectangleTool.addRectanglesFromData(item, fillColorBuy);
            }
            const fillColorSell = 'rgba(255,51,51,0.2)';
            var sell_array = this.SellOverlayData['two_forty'];
            for (let item of Object.values(sell_array)) {
              this.rectangleTool.addRectanglesFromData(item, fillColorSell);
            }
            // this.getsetup(this.purchased_date, this.entry_timestamp, this.completed_on, this.entry_price, this.stoploss_price, this.target_price, this.order_type)
          }

          if (this.finData.time_frame == 4) {
            const fillColorBuy = 'rgba(0,59,0,0.2)';
            var buy_array = this.BuyOverlayData['two_forty'];
            for (let item of Object.values(buy_array)) {
              this.rectangleTool.addRectanglesFromData(item, fillColorBuy);
            }
            const fillColorSell = 'rgba(255,51,51,0.2)';
            var sell_array = this.SellOverlayData['two_forty'];
            for (let item of Object.values(sell_array)) {
              this.rectangleTool.addRectanglesFromData(item, fillColorSell);
            }
            // this.getsetup(this.purchased_date, this.entry_timestamp, this.completed_on, this.entry_price, this.stoploss_price, this.target_price, this.order_type)
          }

        }

        if (this.activeTab == "Future") {

          if (this.finData.time_frame == 1) {
            const fillColorBuy = 'rgba(0,59,0,0.2)';
            var buy_array = this.BuyOverlayData['weekly'];
            for (let item of Object.values(buy_array)) {
              this.rectangleTool.addRectanglesFromData(item, fillColorBuy);
            }
            const fillColorSell = 'rgba(255,51,51,0.2)';
            var sell_array = this.SellOverlayData['weekly'];
            for (let item of Object.values(sell_array)) {
              this.rectangleTool.addRectanglesFromData(item, fillColorSell);
            }
            // this.getsetup(this.purchased_date, this.entry_timestamp, this.completed_on, this.entry_price, this.stoploss_price, this.target_price, this.order_type)
          }

          if (this.finData.time_frame == 2) {
            const fillColorBuy = 'rgba(0,59,0,0.2)';
            var buy_array = this.BuyOverlayData['daily'];
            for (let item of Object.values(buy_array)) {
              this.rectangleTool.addRectanglesFromData(item, fillColorBuy);
            }
            const fillColorSell = 'rgba(255,51,51,0.2)';
            var sell_array = this.SellOverlayData['daily'];
            for (let item of Object.values(sell_array)) {
              this.rectangleTool.addRectanglesFromData(item, fillColorSell);
            }
            // this.getsetup(this.purchased_date, this.entry_timestamp, this.completed_on, this.entry_price, this.stoploss_price, this.target_price, this.order_type)
          }

          if (this.finData.time_frame == 3) {
            const fillColorBuy = 'rgba(0,59,0,0.2)';
            var buy_array = this.BuyOverlayData['sixty'];
            for (let item of Object.values(buy_array)) {
              this.rectangleTool.addRectanglesFromData(item, fillColorBuy);
            }
            const fillColorSell = 'rgba(255,51,51,0.2)';
            var sell_array = this.SellOverlayData['sixty'];
            for (let item of Object.values(sell_array)) {
              this.rectangleTool.addRectanglesFromData(item, fillColorSell);
            }
            // this.getsetup(this.purchased_date, this.entry_timestamp, this.completed_on, this.entry_price, this.stoploss_price, this.target_price, this.order_type)
          }

           if (this.finData.time_frame == 25) {
            const fillColorBuy = 'rgba(0,59,0,0.2)';
            var buy_array = this.BuyOverlayData['daily'];
            for (let item of Object.values(buy_array)) {
              this.rectangleTool.addRectanglesFromData(item, fillColorBuy);
            }
            const fillColorSell = 'rgba(255,51,51,0.2)';
            var sell_array = this.SellOverlayData['daily'];
            for (let item of Object.values(sell_array)) {
              this.rectangleTool.addRectanglesFromData(item, fillColorSell);
            }
            // this.getsetup(this.purchased_date, this.entry_timestamp, this.completed_on, this.entry_price, this.stoploss_price, this.target_price, this.order_type)
          }

        }

      }
      // if (this.selectedOptions['setup']) {
      //   this.dropdownShow = true;
      // } else {
      //   this.dropdownShow = false;
      //   if (this.buylineSeries) {
      //     this.buylineSeries.setMarkers([]);
      //     this.buylineSeries.setData([]);
      //   }
      //   if (this.targetlineSeries) {
      //     this.targetlineSeries.setMarkers([]);
      //     this.targetlineSeries.setData([]);
      //   }
      //   if (this.stoplosslineSeries) {
      //     this.stoplosslineSeries.setMarkers([]);
      //     this.stoplosslineSeries.setData([]);
      //   }
      // }
      if (this.SETUPREQ) {
      //     if(this.activeTab== "Stocks"){
      //      if(this.activeMenu == "Failed" || this.activeMenu == "Success"){
      //    this.entryMark(
      //     this.barReplaytimestampInSeconds_entry,
      //     this.barReplaytimestampInSeconds_completed,
      //     this.barReplayorder_type
      //   );
      // }
      // if(this.activeMenu == "Progress"){
      //    this.entryMark(
      //     this.barReplaytimestampInSeconds_entry,
      //     this.barReplaytimestampInSeconds_completed,
      //     this.barReplayorder_type
      //   );
      // }
      // }

      // if(this.activeTab== "Commodity"){
      //      if(this.activeMenuCommodity == "Failed" || this.activeMenuCommodity == "Success"){
      //    this.entryMark(
      //     this.barReplaytimestampInSeconds_entry,
      //     this.barReplaytimestampInSeconds_completed,
      //     this.barReplayorder_type
      //   );
      // }
      // if(this.activeMenuCommodity == "Progress"){
      //    this.entryMark(
      //     this.barReplaytimestampInSeconds_entry,
      //     this.barReplaytimestampInSeconds_completed,
      //     this.barReplayorder_type
      //   );
      // }
      // }

      // if(this.activeTab== "Future"){
      //      if(this.activeMenuFuture == "Failed" || this.activeMenuFuture == "Success"){
      //    this.entryMark(
      //     this.barReplaytimestampInSeconds_entry,
      //     this.barReplaytimestampInSeconds_completed,
      //     this.barReplayorder_type
      //   );
      // }
      // if(this.activeMenuFuture == "Progress"){
      //    this.entryMark(
      //     this.barReplaytimestampInSeconds_entry,
      //     this.barReplaytimestampInSeconds_completed,
      //     this.barReplayorder_type
      //   );
      // }
      // }
   
        // if (this.activeMenu == "Failed" || this.activeMenuCommodity == "Failed" || this.activeMenuFuture == "Failed") {
        //   this.entryMark(
        //     this.barReplaytimestampInSeconds_entry,
        //     this.barReplaytimestampInSeconds_completed,
        //     this.barReplayorder_type
        //   );
        // }
        // if (this.activeMenu == "Success" || this.activeMenuCommodity == "Success" || this.activeMenuFuture == "Success") {
        //   this.entryMark(
        //     this.barReplaytimestampInSeconds_entry,
        //     this.barReplaytimestampInSeconds_completed,
        //     this.barReplayorder_type
        //   );
        // }
      }
    }
    else {
      // this.dropdownShow = false;
      // this.candlestickSeries.setMarkers([]);
      // this.rectangleTool.removeAllRectangles()
      // if (this.buylineSeries) {
      //   this.buylineSeries.setMarkers([]);
      //   this.buylineSeries.setData([]);
      // }
      // if (this.targetlineSeries) {
      //   this.targetlineSeries.setMarkers([]);
      //   this.targetlineSeries.setData([]);
      // }
      // if (this.stoplosslineSeries) {
      //   this.stoplosslineSeries.setMarkers([]);
      //   this.stoplosslineSeries.setData([]);
      // }
      this.dropdownShow = false;
      this.candlestickSeries.setMarkers([]);
      this.rectangleTool.removeAllRectangles()
      if (this.SETUPREQ) {
        // if (this.activeMenu == "Failed" || this.activeMenuCommodity == "Failed" || this.activeMenuFuture == "Failed") {
        //   this.entryMark(
        //     this.barReplaytimestampInSeconds_entry,
        //     this.barReplaytimestampInSeconds_completed,
        //     this.barReplayorder_type
        //   );
        // }
        // if (this.activeMenu == "Success" || this.activeMenuCommodity == "Success" || this.activeMenuFuture == "Success") {
        //   this.entryMark(
        //     this.barReplaytimestampInSeconds_entry,
        //     this.barReplaytimestampInSeconds_completed,
        //     this.barReplayorder_type
        //   );
        // }
      }
       //this.getsetup(this.purchased_date, this.entry_timestamp, this.completed_on, this.entry_price, this.stoploss_price, this.target_price, this.order_type)
    }
  }

  checkOptions(): boolean {
    for (let key in this.selectedOptions) {
      if (this.selectedOptions[key]) {
        return false;
      }
    }
    return true;
  }

  isTradeSignalHighlighted(item: any): boolean {
    return item.TRADE_SIGNAL_ID != null; // highlight only if not null
  }

 isHighlighted(stockTick: string): boolean {
  return this.highlightedStockNames
    .some(x => (x || '').toLowerCase() === (stockTick || '').toLowerCase());
}


  getAllBucketListOrders(highlight: boolean = false) {
    this.showmsg = "Fetching Data!";
    this.spinner.show();
    this.initializeCandles();
    this.startRandomColorToggle();
    let obj = {
      country_id: Number(localStorage.getItem('selectedCountryId')),
      stock_tick: this.searchText,
      start_date: this.selectedDateRange.startDate.format('YYYY-MM-DD'),
      end_date: this.selectedDateRange.endDate.format('YYYY-MM-DD'),
      status: "all",
      time_frame: this.timeframe_forOrderList,
      page_no: this.SearchDebounceFlag ? null : String(this.successPage),
      limit: this.pageSize,
      order_by_purchased_cmp_date: this.isChecked,
      order_type: this.selectTradeType,
      trade_id: null,
      prediction_type: this.predictionFilter
    }
    console.log("Bucket Object", obj);
    this.apiService.getAllBucketListOrderService(obj).subscribe(resp => {
      this.SearchDebounceFlag = false;
      this.AllbucketListOrders=[];
      this.AllbucketListOrders = resp.response.orders;
      console.log("bucketlist resp", this.AllbucketListOrders);
      this.spinner.hide();
      
     if (highlight && this.searchText) {
  const lowerSearch = this.searchText.trim().toLowerCase();

  const matches = this.AllbucketListOrders.filter((item: any) =>
    (item.stock_tick || '').toLowerCase().includes(lowerSearch)
    || (item.stock_symbol || '').toLowerCase().includes(lowerSearch) // optional
  );

  this.MatchedCount = matches.length;

  // ✅ store the SAME key that HTML uses in data-stock
  this.highlightedStockNames = matches.map((x: any) => x.stock_tick);

  if (matches.length > 0) {
    const firstTick = matches[0].stock_tick;

    setTimeout(() => {
      const target = this.stockCells.find(cell =>
        (cell.nativeElement.getAttribute('data-stock') || '').toLowerCase() === firstTick.toLowerCase()
      );
      console.log("TARGET",target)
      if (target) {
        target.nativeElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
        this.successPage=resp.response.page_no;
      }
    });
  }
} else {
  this.highlightedStockNames = [];
  this.MatchedCount = 0;
}

    })
  }

  approveBucketOrder(bucket_id: any, status: any) {
    this.showmsg = "Please Wait..!";
    this.spinner.show();
    let obj = {
      bucket_id: bucket_id,
      approved_by: this.UserID,
      status: status
    }
    this.apiService.approveBucketOrderService(obj).subscribe(resp => {
      console.log("approveBucketOrder resp", resp)
      if (resp.msg == "success") {
        this.spinner.hide();
        this.getAllBucketListOrders(false);
        this.toastr.success(resp.response);
      }
      else {
        this.spinner.hide();
        this.toastr.error(resp.response);
      }

    });
  }

  goToNextPage() {
    const totalPages = this.getTotalPages();
    if (this.successPage < totalPages) {
      this.successPage++;
      this.getAllBucketListOrders(true);
    }
    // if (this.activeMenu === 'Success' && this.successPage < totalPages) {
    //   this.successPage++;
    //   this.getSuccessOrders(true);
    // } else if (this.activeMenu === 'Failed' && this.failedPage < totalPages) {
    //   this.failedPage++;
    //   this.getFailedOrders(true);
    // } else if (this.activeMenu === 'Pending' && this.pendingPage < totalPages) {
    //   this.pendingPage++;
    //   this.getPendingOrders(true);
    // } else if (this.activeMenu === 'Progress' && this.progressPage < totalPages) {
    //   this.progressPage++;
    //   this.getProgressOrders(true);
    // }
  }

  goToPreviousPage() {
      this.successPage--;
      this.getAllBucketListOrders(true);
    
    // if (this.activeMenu === 'Success' && this.successPage > 1) {
    //   this.successPage--;
    //   this.getSuccessOrders(true);
    // } else if (this.activeMenu === 'Failed' && this.failedPage > 1) {
    //   this.failedPage--;
    //   this.getFailedOrders(true);
    // } else if (this.activeMenu === 'Pending' && this.pendingPage > 1) {
    //   this.pendingPage--;
    //   this.getPendingOrders(true);
    // }
    // else if (this.activeMenu === 'Progress' && this.progressPage > 1) {
    //   this.progressPage--;
    //   this.getProgressOrders(true);
    // }
  }

  getTotalPages(): number {
    return Math.ceil(this.TotalCount / this.pageSize);

    // const total = this.activeMenu === 'Success' ? this.SuccessCount
    //   : this.activeMenu === 'Failed' ? this.FailedCount
    //     : this.activeMenu === 'Progress' ? this.ProgressCount
    //       : this.PendingCount;

    //return Math.ceil(total / this.pageSize);
  }

  getPageNumbers(): number[] {
    const totalPages = this.getTotalPages();
    const currentPage = this.getCurrentPage();

    const maxVisible = 5;
    let startPage = Math.max(currentPage - Math.floor(maxVisible / 2), 1);
    let endPage = Math.min(startPage + maxVisible - 1, totalPages);

    if (endPage - startPage < maxVisible - 1) {
      startPage = Math.max(endPage - maxVisible + 1, 1);
    }

    const pageNumbers: number[] = [];
    for (let i = startPage; i <= endPage; i++) {
      pageNumbers.push(i);
    }

    return pageNumbers;
  }

  getCurrentPage(): number {
    return this.successPage;
    // return this.activeMenu === 'Success' ? this.successPage
    //   : this.activeMenu === 'Failed' ? this.failedPage
    //     : this.activeMenu === 'Progress' ? this.progressPage
    //       : this.pendingPage;
  }

  goToPage(page: number) {
      this.successPage = page;
      this.getAllBucketListOrders(true);
    // if (this.activeMenu === 'Success') {
    //   this.successPage = page;
    //   this.getSuccessOrders(true);
    // } else if (this.activeMenu === 'Failed') {
    //   this.failedPage = page;
    //   this.getFailedOrders(true);
    // } else if (this.activeMenu == "Pending") {
    //   this.pendingPage = page;
    //   this.getPendingOrders(true);
    // } else {
    //   this.progressPage = page;
    //   this.getProgressOrders(true)
    // }
  }

  onPageSizeChange() {
      this.successPage = 1
      this.getAllBucketListOrders(true);
    
    // if (this.activeMenu === 'Success') {
    //   this.successPage = 1
    //   this.getSuccessOrders();
    // } else if (this.activeMenu === 'Failed') {
    //   this.failedPage = 1;
    //   this.getFailedOrders();
    // } else if (this.activeMenu === 'Pending') {
    //   this.pendingPage = 1;
    //   this.getPendingOrders();
    // } else {
    //   this.progressPage = 1;
    //   this.getProgressOrders();
    // }
  }

  onSearchButtonClick() {
     this.successPage = 1;
    // this.progressPage = 1;
    // this.pendingPage = 1;
    // this.failedPage = 1;
    this.getAllBucketListOrders(true);
    this.getorderscount();
    this.highlightedIndex = -1
  }





  
}

