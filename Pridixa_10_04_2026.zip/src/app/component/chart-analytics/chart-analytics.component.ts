import {
  ChangeDetectorRef,
  Component,
  ElementRef,
  HostListener,
  OnInit,
  QueryList,
  Renderer2,
  TemplateRef,
  ViewChild,
  ViewChildren,
} from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NgxSpinnerService } from 'ngx-spinner';
import { ApiService } from 'src/app/services/api.service';
import {
  ISeriesApi,
  createChart,
  LineStyle,
  CrosshairMode,
  BarData,
  PriceLineOptions,
  IPriceLine,
} from 'lightweight-charts';
import { ActivatedRoute, Router, TitleStrategy } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { debounceTime, distinctUntilChanged, Subject, switchMap } from 'rxjs';
import { WebSocketService } from 'src/app/services/web-socket.service';
import * as moment from 'moment';
import { RectangleDrawingTool } from './rectangle-drawing-tool';
import { FloatingModalComponent } from '../floating-modal/floating-modal.component';

  type Patch = Partial<{
    optimized_buy_sell_zone: boolean;
    qualified_zones: boolean;
  }>;

  const MENU_RULES: Record<string, {
    base: string; // where overlap checkboxes are valid (same as activeMenu)
    overlap_evaluate?: Record<string, Patch>;
    overlap_analyze?: Record<string, Patch>;
  }> = {
    daily: {
      base: "daily",
      overlap_evaluate: {
        monthly: { qualified_zones: false, optimized_buy_sell_zone: true },
      },
      overlap_analyze: {
        weekly: { qualified_zones: false, optimized_buy_sell_zone: true },
      }
    },

    sixty: {
      base: "sixty",
      overlap_evaluate: {
        weekly: { optimized_buy_sell_zone: true },
        seventy_five: { optimized_buy_sell_zone: true },
      },
      overlap_analyze: {
        daily: { optimized_buy_sell_zone: true },
        seventy_five: { optimized_buy_sell_zone: true },
      }
    },

    fifteen: {
      base: "fifteen",
      overlap_evaluate: {
        daily: { optimized_buy_sell_zone: true },
      },
      overlap_analyze: {
        sixty: { optimized_buy_sell_zone: true },
      }
    },

    one_twenty_five: {
      base: "one_twenty_five",
      overlap_evaluate: {
        weekly: { optimized_buy_sell_zone: true },
      },
      overlap_analyze: {
        daily: { optimized_buy_sell_zone: true },
      }
    },

    seventy_five: {
      base: "seventy_five",
      overlap_evaluate: {
        weekly: { optimized_buy_sell_zone: true },
      },
      overlap_analyze: {
        daily: { optimized_buy_sell_zone: true },
      }
    },

    twenty_five: {
      base: "twenty_five",
      overlap_evaluate: {
        daily: { optimized_buy_sell_zone: true },
      },
      overlap_analyze: {
        one_twenty_five: { optimized_buy_sell_zone: true },
      }
    },
  };
  interface CandleData {
    time: number;
    open: number;
    high: number;
    low: number;
    close: number;
  }

  interface ChartPoint {
    time: number;
    price: number;
  }

  interface ChartPath {
    points: ChartPoint[];
  }

  interface ChartText {
    time: number;
    price: number;
    text: string;
  }

  interface ZoneItem {
    time: number; // or 'string' if you're using businessDay
    price: number;
    // ... any other properties your rectangles use
  }

@Component({
  selector: 'app-chart-analytics',
  templateUrl: './chart-analytics.component.html',
  styleUrls: ['./chart-analytics.component.css'],
})
export class ChartAnalyticsComponent implements OnInit {
   private viewGraphOverlapMemory: Record<number, { evaluate: boolean; analyze: boolean ;qualified:boolean }> = {};
  placementMode: 'none' | 'entry' | 'target' | 'stoploss' = 'none';
  previewLine: any = null;
  horizontalLines: any[] = [];
  boundShowPreviewLine: ((param: any) => void) | null = null;
  boundFixLineAtPrice: ((param: any) => void) | null = null;
  selectedLine: any = null;
  RiskToReward: any;
  fincreateformForMannualSetup: FormGroup;
  submittedForMannual: boolean = false;
  showCreateOrderModalForMAnnual = false;
  createBtnFlgForMannualSetup: boolean = false;
  @ViewChild('modalA') modalA!: FloatingModalComponent;
  // keep one-time listener flag
  lastBar: any;
  private _dragListenersAttached = false;

  // your desired default margins – set this to whatever you configure at chart init
  private readonly DEFAULT_SCALE_MARGINS = { top: 0.0, bottom: 0.0 };

  // “infinite” right extension (~100 years)
  private readonly FUTURE_SECONDS = 60 * 60 * 24 * 365 * 1;

  // clamp to avoid negative prices while placing/dragging
  private readonly MIN_PRICE = 0; // adjust if your instrument can go below 0
  private _previewInvalid = false;
  private _previewMsg = '';

  trackByTick = (_: number, item: any) => item?.stock_tick;
  @ViewChild('closeButton') closeButton: ElementRef;
  @ViewChild('closeButtonHide') closeButtonHide: ElementRef;
  @ViewChild('closemodal') closemodal!: ElementRef;
  @ViewChild('AddStockcloseButton') AddStockcloseButton!: ElementRef;
  @ViewChild('drawingCanvas') drawingCanvas!: ElementRef<HTMLCanvasElement>;
  @ViewChild('modalalert') modalalert!: FloatingModalComponent;
  @ViewChildren('stockCell') stockCells!: QueryList<ElementRef>;
  BuyZoneDataItem: any;
  finform: FormGroup;
  AddStockForm: FormGroup;
  selectedStockId: any;
  submitted: boolean = false;
  submittedforAddStock: boolean = false;
  stockData: any[] = [];
  filter: any;
  selectedDate: any;
  showmsg: any;
  ChartRESPONSE: any;
  BitmapPositionLength: any;
  Daily: any;
  Weekly: any;
  Monthly: any;
  layoutFlagfirst: boolean;
  OptimizedBuySellZoneData75: any;
  layoutFlagsecond: boolean;
  layoutFlagthird: boolean;
  finData: any;
  ModalHeader: any;
  MonthlyLabel: any;
  WeeklyLabel: any;
  DailyLabel: any;
  Seventy_FiveLabel: any;
  SixtyLabel: any;
  Fifteen_MinuteLabel: any;
  checkbox1: boolean = false;
  checkbox2: boolean = false;
  checkbox3: boolean = false;
  BaseCandleData: any;
  AllZonesData: any;
  FullScreenModeValue: any;
  selectedOption: any;
  BuyZoneData: any;
  SellZoneData: any;
  toolTipData: any;
  Open: any;
  High: any;
  Low: any;
  Close: any;
  CandleColor: any;
  suggestion: any;
  setupData: any;
  key: any;
  BuySetupData: any;
  SellSetupData: any;
  BuyTimestampData: any;
  SellTimestampData: any;
  GapData: any;
  BadZoneData: any;
  dropdownShow: any;
  SelectedStockName: any;
  token: any;
  state: any;
  fincreateform: FormGroup;
  SellMessage: any;
  BuyMessage: any;
  createorderResp: any;
  timer: any;
  TimeFrame: any;
  setupdataStatus: any;
  ModelPrediction: any;
  OverLayCandleData: any;
  BuyOverlayData: any;
  SellOverlayData: any;
  QualifiedData: any;
  selectedOptions: any = {
    base_candle: false,
    buy_sell_zone: false,
    bad_zone: false,
    setup: false,
    overlap_evaluate: false,
    overlap_analyze: false,
  };
  isPanelOpen = false;
  draggedStock: any;
  Isdragged = false;
  isNotificationVisible = false;
  PreviousHighData: any;
  filteredCompanies: any = [];
  highlightedIndex: number = -1;
  setupDataonseventyfive: any;
  QualifiedDataonSeventyfive: any;
  OverLayCandleDataonSevetyFive: any;
  BuyOverlayDataonSeventyFive: any;
  SellOverlayDataonSeventyFive: any;
  lastTouchEnd = 0;
  candles: { color: string; height: number; wickHeight: number }[] = [];
  colorInterval: any;
  realTimePrice: any;
  cmpLine: any;
  lastCMPLine: any = null;
  selectedType: any;
  FULLSCREENCHARTDATA: any;
  LINEDATA: any;
  EntryPrice: any;
  TargetPrice: any;
  StoplossPrice: any;
  EntryTime: any;
  SETUPTYPE: any;
  searchSubject: Subject<string> = new Subject<string>();
  @ViewChild('chart_container_new') chartContainer!: ElementRef;
  isDragging = false;
  TrackFullScreenMode: boolean = false;
  updateModelPredictionFlag = false;
  Counter: any = 0;
  MasterTimeFrameToHideSpinner: any = 0;
  OptimizedBuySellZoneData: any;
  TrendAnalyzer: any;
  GapUpDownData: any;
  Role: any;
  UserName: any;
  isAdmin: boolean = false;
  OriginalFinData: any;
  lastReplayTime: any;
  showOrderPanel = false;
  SelectedPrediction: any;
  SelectedProbability: any;
  currentCandle: any = null;
  layoutFlagfourth: boolean;
  layoutFlagfifth: boolean;
  layoutFlagsixth: boolean;
  One_Twenty_FiveLabel: any;
  Twenty_FiveLabel: any;
  // CHART ELEMENT
  private chart: any;
  private areaSeries: any;
  private candlestickSeries: any;
  private buylineSeries: any;
  private targetlineSeries: any;
  private stoplosslineSeries: any;
  candleData: any;
  p1: any;
  p2: any;
  x1: any;
  x2: any;
  rectangleTool: any;
  dataPoints: any;
  xspan: any;
  lineSeries: any;
  buyZoneMarkers: any;
  UpdateCnadleStockId: any;
  countries: any;
  selectedCountry: any;
  replayVisibleData: any[] = [];
  replayFutureData: any[] = [];
  replayInterval: any;
  allData: any[] = [];
  currentPostIndex = 0;
  isReplayMode: boolean = false;
  recalculateTimeFormat: any;
  isReplayPlaying: boolean = false;
  allSetAlerts: any = [];
  showCreateOrderModal = false;
  ViewSetUpAnywayFlag: boolean = false;
  PricePercentageData: any;
  PP_Analyze: any;
  PP_Evaluate: any;
  PP_Execute: any;
  PP_Reason: any;
  PP_FinalDecision: any;
  showPopup = false;

  //#endregion VARIABLES

  private startPoint: { x: number; y: number } | null = null;
  @ViewChild('textLayer') textLayer!: ElementRef<HTMLDivElement>;
  private ctx!: CanvasRenderingContext2D;
  private isDrawing = false;
  selectedPathIndex: number = -1;
  activeTool: 'none' | 'pencil' | 'line' | 'text' = 'none';
  textBoxes: ChartText[] = [];
  paths: ChartPath[] = [];
  currentPath: ChartPath | null = null;
  selectedTextBoxIndex: number = -1;
  isChartInverted: boolean = false;
  replayMode = false;
  CancelReplayClicked: boolean = false;
  selectedstockintID: any;
  TradeSetupReason: any;
  alertForm: FormGroup;
  submitStock = false;
  countryId: any;
  userId: any;
  CreateButtonFlag = false;
  selectedTab: 'add' | 'list' = 'add'; // Default tab
  currentPage: any = 1;
  itemsPerPage: number = 10; // default
  totalCount: any;
  searchText: string = '';
  highlightedStockName: string = '';
  pageSize = 10;
  pageSizeOptions = [2, 10, 25, 50, 100];
  highlightedStockNames: string[] = [];
  TotalCount: any = 0;
  selectedDateRange: any;
  highlightedStockTick: string = '';
  MatchedCount: number = 0;
  StartDate: any;
  EndDate: any;
  ranges: any = {
    All: [moment('2019-01-01'), moment()],
    Today: [moment(), moment()],
    'Last 7 Days': [moment().subtract(6, 'days'), moment()],
    'Last 15 Days': [moment().subtract(14, 'days'), moment()],
    'This Month': [moment().startOf('month'), moment().endOf('month')],
    'Last 3 Months': [
      moment().subtract(3, 'months').startOf('month'),
      moment().subtract(1, 'month').endOf('month'),
    ], // Last 3 months excluding current month
    'Last 6 Months': [
      moment().subtract(6, 'months').startOf('month'),
      moment().subtract(1, 'month').endOf('month'),
    ],
  };
  private ws!: WebSocket;
  invalidDates: moment.Moment[] = [
    moment().add(2, 'days'),
    moment().add(3, 'days'),
    moment().add(5, 'days'),
  ];
  isInvalidDate = (m: moment.Moment) => {
    return this.invalidDates.some((d) => d.isSame(m, 'day'));
  };

  SearchDebounceFlag: boolean = false;
  currentGroupId: any;
  entryEnabled = true;
  targetEnabled = true;
  stoplossEnabled = true;
  isDisabled = false;
  StockTickByParam: any;
  stock_id: any;
  isLeftBarOpen = false;
  showMobileTradeMenu = false;

  constructor(
    private webSocketService: WebSocketService,
    private route: ActivatedRoute,
    private cdRef: ChangeDetectorRef,
    private renderer: Renderer2,
    private router: Router,
    private toastr: ToastrService,
    private formBuilder: FormBuilder,
    private apiService: ApiService,
    private spinner: NgxSpinnerService,
    private elementRef: ElementRef
  ) {
    this.searchSubject
      .pipe(debounceTime(300), distinctUntilChanged())
      .subscribe((searchTerm) => {
        this.search(searchTerm);
      });
    this.xspan = 3600;
    this.selectedOption = '';
  }

   @HostListener('document:click', ['$event'])
  onOutsideClick(event: MouseEvent) {
    if (!this.isLeftBarOpen) return;

    const leftBar = document.getElementById('leftBar');
    const target = event.target as HTMLElement;

    if (leftBar && leftBar.contains(target)) return;

    const settingsBtn = target.closest('.trade-header__settings');
    if (settingsBtn) return;

    this.openBar(false);
  }

  toggleMobileTradeMenu(): void {
    this.showMobileTradeMenu = !this.showMobileTradeMenu;
  }

  closeMobileTradeMenu(): void {
    this.showMobileTradeMenu = false;
  }

   openBar(isOpen: boolean): void {
    this.isLeftBarOpen = isOpen;
  }

    toggleLeftBar(): void {
    if (window.innerWidth <= 767.98) {
      this.isLeftBarOpen = !this.isLeftBarOpen;
    } else {
      this.isLeftBarOpen = true;
    }
  }

  handleSettingsEnter(): void {
    if (window.innerWidth > 767.98) {
      this.openBar(true);
    }
  }

  handleSettingsLeave(): void {
    // keep empty or remove this if not needed
  }

  handleLeftBarEnter(): void {
    if (window.innerWidth > 767.98) {
      this.openBar(true);
    }
  }

  handleLeftBarLeave(): void {
    if (window.innerWidth > 767.98) {
      this.openBar(false);
    }
  }


  @HostListener('window:keydown', ['$event'])
  handleKeyDown(event: KeyboardEvent): void {
    const target2 = event.target as HTMLElement;
    // ✅ Early return if user is typing in an input, textarea, or contentEditable element
    if (
      target2.tagName === 'INPUT' ||
      target2.tagName === 'TEXTAREA' ||
      target2.getAttribute('contenteditable') === 'true' ||
      (target2 as HTMLInputElement).isContentEditable
    ) {
      return; // Don't handle global keys when
    }

    if (event.key === 'Delete' && this.selectedLine) {
      if (this.selectedLine.type === 'entry') {
        for (let line of this.horizontalLines) {
          try {
            this.chart.removeSeries(line.series);
            if (line.type === 'entry') this.entryEnabled = true;
            if (line.type === 'target') this.targetEnabled = true;
            if (line.type === 'stoploss') this.stoplossEnabled = true;
          } catch { }
        }

        this.fincreateformForMannualSetup.patchValue({ entry: null });
        this.fincreateformForMannualSetup.patchValue({ stoploss: null });
        this.fincreateformForMannualSetup.patchValue({ target: null });
        this.horizontalLines = [];
        this.EntryPrice = null;
        this.TargetPrice = null;
        this.StoplossPrice = null;
      } else {
        // remove only the selected line
        try {
          this.chart.removeSeries(this.selectedLine.series);
        } catch { }
        this.horizontalLines = this.horizontalLines.filter(
          (l) => l !== this.selectedLine
        );

        // clear form value for this line
        if (this.selectedLine.type === 'stoploss') {
          this.StoplossPrice = null;
          this.fincreateformForMannualSetup.patchValue({ stoploss: null });
        }
        if (this.selectedLine.type === 'target') {
          this.TargetPrice = null;
          this.fincreateformForMannualSetup.patchValue({ target1: null });
        }
        if (this.selectedLine.type === 'entry') this.entryEnabled = true;
        if (this.selectedLine.type === 'target') this.targetEnabled = true;
        if (this.selectedLine.type === 'stoploss') this.stoplossEnabled = true;
      }

      this.selectedLine = null;
    }

    // Check if the target element is an input, textarea, or content-editable element
    const target = event.target as HTMLElement;
    const isInputField =
      target.tagName === 'INPUT' ||
      target.tagName === 'TEXTAREA' ||
      target.isContentEditable;

    if (isInputField) {
      // Allow default behavior for input fields
      return;
    }

    // if (event.ctrlKey && event.key === 'o') {
    //   if (this.TrackFullScreenMode) {
    //     event.preventDefault();
    //     this.togglePanel();
    //   }
    // }
    let dataPresent = false;
    switch (event.key) {
      case 'm':
      case 'M':
        dataPresent = !!this.ChartRESPONSE['monthly'];
        if (dataPresent) {
          // this.selectedOptions = [];
          this.dropdownShow = false;
          this.ChangeScreenMode('monthly', 'chart-container_new');
        } else {
          this.toastr.error(`No Data Found on Monthly !`);
        }
        break;
      case 'w':
      case 'W':
        dataPresent = !!this.ChartRESPONSE['weekly'];
        if (dataPresent) {
          // this.selectedOptions = [];
          this.dropdownShow = false;
          this.ChangeScreenMode('weekly', 'chart-container_new');
        } else {
          this.toastr.error(`No Data Found on Weekly !`);
        }
        break;
      case 'd':
      case 'D':
        dataPresent = !!this.ChartRESPONSE['daily'];
        if (dataPresent) {
          // this.selectedOptions = [];
          this.dropdownShow = false;
          this.ChangeScreenMode('daily', 'chart-container_new');
        } else {
          this.toastr.error(`No Data Found on Daily !`);
        }
        break;
      case '7':
        dataPresent = !!this.ChartRESPONSE['seventy_five'];
        if (dataPresent) {
          // this.selectedOptions = [];
          this.dropdownShow = false;
          this.ChangeScreenMode('seventy_five', 'chart-container_new');
        } else {
          this.toastr.error(`No Data Found on 75 Minutes !`);
        }
        break;
      case '6':
        dataPresent = !!this.ChartRESPONSE['sixty'];
        if (dataPresent) {
          // this.selectedOptions = [];
          this.dropdownShow = false;
          this.ChangeScreenMode('sixty', 'chart-container_new');
        } else {
          this.toastr.error(`No Data Found on 60 Minutes !`);
        }
        break;
      case '5':
        dataPresent = !!this.ChartRESPONSE['fifteen'];
        if (dataPresent) {
          // this.selectedOptions = [];
          this.dropdownShow = false;
          this.ChangeScreenMode('fifteen', 'chart-container_new');
        } else {
          this.toastr.error(`No Data Found on 15 Minutes !`);
        }
        break;
      case '2':
        dataPresent = !!this.ChartRESPONSE['twenty_five'];
        if (dataPresent) {
          // this.selectedOptions = [];
          this.dropdownShow = false;
          this.ChangeScreenMode('twenty_five', 'chart-container_new');
        } else {
          this.toastr.error(`No Data Found on 25 Minutes !`);
        }
        break;
      case '1':
        dataPresent = !!this.ChartRESPONSE['one_twenty_five'];
        if (dataPresent) {
          // this.selectedOptions = [];
          this.dropdownShow = false;
          this.ChangeScreenMode('one_twenty_five', 'chart-container_new');
        } else {
          this.toastr.error(`No Data Found on 125 Minutes !`);
        }
        break;
      case 'ArrowLeft':
        this.shiftChart(-10);
        break;
      case 'ArrowRight':
        this.shiftChart(10);
        break;
      case '+':
      case '=':
        this.scaleChart(1 / 8, true);
        break;
      case '-':
        this.scaleChart(1 / 8, false);
        break;
      case 'Escape':
        this.renderer.selectRootElement(this.closeButton.nativeElement).click();
        this.cleanupChart();
        this.selectedOption = '';
        this.dropdownShow = false;
        break;
      // case 'l':
      // case 'L':
      //   if (this.TrackFullScreenMode) {
      //     this.drawLineSeries();
      //   }
      //   break;
      // case 'C':
      // case 'c':
      //   if (this.TrackFullScreenMode) {
      //     this.drawCandleSeries();
      //   }
      //   break;
    }
  }

  getLineColor(type: string) {
    if (type === 'entry') return 'blue';
    if (type === 'target') return 'green';
    if (type === 'stoploss') return 'red';
    return 'gray';
  }

  shiftChart(diff: any) {
    const currentPos = this.chart.timeScale().scrollPosition();
    this.chart.timeScale().scrollToPosition(currentPos + diff, false);
  }

  scaleChart(pct: number, zoomIn: boolean): void {
    const timeScale = this.chart.timeScale();
    const priceScale = this.chart.priceScale('right'); // Use the default 'right' price scale
    const direction = zoomIn ? -1 : 1;

    // Handle horizontal scaling (time scale)
    const currentTimeRange = timeScale.getVisibleLogicalRange();
    if (currentTimeRange) {
      const bars = currentTimeRange.to - currentTimeRange.from;
      const newRangeBars = bars * pct * direction + bars;
      timeScale.setVisibleLogicalRange({
        to: currentTimeRange.to,
        from: currentTimeRange.to - newRangeBars,
      });
    }

    this.candlestickSeries.applyOptions({
      priceScale: {
        scaleMargins: {
          top: Math.max(0.1, 0.2 + (zoomIn ? -0.05 : 0.05)),
          bottom: Math.max(0.1, 0.2 + (zoomIn ? -0.05 : 0.05)),
        },
      },
    });
  }

  dashboard() {
    this.router.navigate(['dashboard']);
  }

  alerts() {
    this.router.navigate(['alerts']);
  }

  logout() {
    this.router.navigate(['landing']);
  }

  orders() {
    this.router.navigate(['orderlist']);
  }

  sysmgmt() {
    this.router.navigate(['system-management']);
  }

  autoorders() {
    this.router.navigate(['auto-order-list']);
  }

  available_trades() {
    this.router.navigate(['trades']);
  }

  news() {
    this.router.navigate(['news']);
  }

  private buildForm() {
    const countryId = localStorage.getItem('selectedCountryId');
    this.finform = this.formBuilder.group({
      country: [localStorage.getItem('selectedCountryName')],
      tick: ['', [Validators.required]],
      time_frame: ['', [Validators.required]],
      last_d_time: [''],
    });

    this.alertForm = this.formBuilder.group({
      user_id: [Number(this.userId)],
      country_id: [Number(this.countryId)],
      stock_symbol: ['', Validators.required],
      exchange: ['NSE'],
      alert_type: ['', Validators.required],
      trigger_price: ['', Validators.required],
      price_range_min: ['', Validators.required],
      price_range_max: ['', Validators.required],
      threshold: ['', Validators.required],
      timeframe: [''],
      note: [''],
      target_percentage: [],
      cooldown_minutes: [Number],
      is_active: [true],
      email_notification: [false],
    });

    this.fincreateformForMannualSetup = this.formBuilder.group({
      stock_tick: [''],
      stock_id: [''],
      prediction: [''],
      probability: [''],

      country_id: [countryId ? Number(countryId) : null],
      order_type: ['', [Validators.required]],
      entry_price: ['', [Validators.required]],
      stoploss_price: ['', [Validators.required]],
      target_price: ['', [Validators.required]],
      stock_quantity: ['', [Validators.required]],
      purchased_cmp_date: [''],
      time_frame: [''],
    });
  }

  private CreateForm() {
    this.fincreateform = this.formBuilder.group({
      stock_tick: [''],
      stock_id: [''],
      prediction: [''],
      probability: [''],
      country_id: this.countryId,
      order_type: ['', [Validators.required]],
      entry_price: ['', [Validators.required]],
      stoploss_price: ['', [Validators.required]],
      target_price: ['', [Validators.required]],
      stock_quantity: ['', [Validators.required]],
      purchased_cmp_date: [''],
      time_frame: [''],
    });
  }

  private buildAddStockForm() {
    this.AddStockForm = this.formBuilder.group({
      stock_name: ['', [Validators.required]],
      y_stock_name: ['', [Validators.required]],
    });
  }

  ngOnInit(): void {
    this.initializeCandles();
    this.startRandomColorToggle();
    this.filter = [
      { id: '1', name: 'Monthly - Weekly - Daily' },
      { id: '2', name: 'Weekly - Daily - 75-60' },
      { id: '3', name: 'Daily - 60-75 - 15' },
      { id: '4', name: 'Monthly - Weekly - 125' },
      { id: '5', name: 'Weekly - Daily - 125' },
      { id: '6', name: 'Daily - 125 - 25' },
    ];
    this.onCountryChange(localStorage.getItem('selectedCountryName'));
    const id = this.route.snapshot.paramMap.get('stock_tick');
    this.StockTickByParam = id;
    this.Role = localStorage.getItem('role');
    if (this.Role == 'admin') {
      this.isAdmin = true;
    } else {
      this.isAdmin = false;
    }
    this.UserName = localStorage.getItem('UserName');
    this.userId = localStorage.getItem('UserId');
    this.selectedDateRange = {
      startDate: moment().startOf('year'), // January 1st, current year
      endDate: moment().endOf('year'), // December 31st, current year
    };
    this.countryId = localStorage.getItem('selectedCountryId');
    this.webSocketService.disconnectStock();
    this.buildForm();
    this.CreateForm();
    this.buildAddStockForm();

    this.getAllSetAlerts(true);
    this.PrepDebounce();
    this.apiService.getStockdataBYTick(
        this.StockTickByParam,
        localStorage.getItem('selectedCountryName')
      )
      .subscribe((resp) => {
        const data = resp.response;
        this.stock_id = resp.response.id;
        // Wait until stockData is loaded
        const interval = setInterval(() => {
          const matchingStock = this.stockData.find(
            (stock) => stock.stock_tick === data.stock_tick
          );
          if (matchingStock) {
            clearInterval(interval);
            this.finform.patchValue({
              tick: matchingStock,
              time_frame: '1',
              last_d_time: moment().format('YYYY-MM-DD HH:mm:ss'),
            });
            this.submit();
          }
        }, 100);
      });

    // Assuming your form is called `form`
    this.alertForm.get('trigger_price')?.valueChanges.subscribe(() => {
      this.calculateMinMax();
    });

    this.alertForm.get('threshold')?.valueChanges.subscribe(() => {
      this.calculateMinMax();
    });
  }

    getRegimeClass(regime: string | null | undefined): string {
    const r = (regime || '').toUpperCase();

    if (r === 'UP') return 'regime-up';
    if (r === 'SW') return 'regime-sw';
    if (r === 'DOWN') return 'regime-down';
    return 'regime-neutral';
  }

  formatPct(value: number | null | undefined): string {
    if (value === null || value === undefined) return '%';
    return `${value.toFixed(1)}%`;
  }

  getZoneLine(zone: any): string {
    if (!zone) return '-';
    return `Prox ${zone.proximal ?? '-'} / Dist ${zone.distal ?? '-'} | ${zone.state ?? '-'}`;
  }

  getZoneMetaLine(zone: any): string {
    if (!zone) return '';
    return `Retests: ${zone.retest_count ?? 0} | Bars Since: ${zone.age_bars ?? 0} | Violation: ${zone.violation ?? 'NONE'}`;
  }

  calculateMinMax() {
    const trigger = this.alertForm.get('trigger_price')?.value;
    const threshold = this.alertForm.get('threshold')?.value;

    if (trigger && threshold) {
      const diff = (trigger * threshold) / 100;
      this.alertForm
        .get('price_range_min')
        ?.setValue(trigger - diff, { emitEvent: false });
      this.alertForm
        .get('price_range_max')
        ?.setValue(trigger + diff, { emitEvent: false });
    }
  }

  get g() {
    return this.fincreateform.controls;
  }
  get f() {
    return this.finform.controls;
  }
  get h() {
    return this.AddStockForm.controls;
  }
  get j() {
    return this.alertForm.controls;
  }
  get k() {
    return this.fincreateformForMannualSetup.controls;
  }

  connectWebSocket(type: any): void {
    this.webSocketService.connect(
      this.finData.tick,
      this.finData.time_frame,
      this.UpdateCnadleStockId,
      type
    );
    this.webSocketService.getStockMessage().subscribe((data) => {
      this.realTimePrice = data;
      console.log('UPDATED DATA', data);
      const parsedData = JSON.parse(data);
      if (this.finData.tick === parsedData.data.stock_tick) {
        this.updateChart(data);
      }
    });
  }


  updateChart(data: any): void {
    const parsedData = JSON.parse(data);

    // Convert all fields to numbers
    const updatedCandle = {
      open: Number(parsedData.data.open),
      high: Number(parsedData.data.high),
      low: Number(parsedData.data.low),
      close: Number(parsedData.data.close),
      time: Number(parsedData.data.time),
    };

    // Get existing chart data
    const existingData = this.candlestickSeries.data();
    if (!existingData || existingData.length === 0) {
      // First candle
      this.candlestickSeries.setData([updatedCandle]);
    } else {
      // Remove last candle and append updated one
      const dataWithoutLast = existingData.slice(0, -1);
      const newSeriesData = [...dataWithoutLast, updatedCandle];

      // ---- Add postbars after last real candle ----
      const lastCandle = newSeriesData[newSeriesData.length - 1];
      const postbars = [...new Array(100)].map((_, i) => ({
        time: lastCandle.time + (i + 1) * this.xspan,
      }));

      // Combine
      // const finalSeries = [...newSeriesData, ...postbars];

      // Set to chart
      this.candlestickSeries.setData([...newSeriesData, ...postbars]);
    }

    // Update lastBar reference
    this.lastBar = updatedCandle;

    // Optional: update closing line
    this.CreateClosingLine(updatedCandle.close);
  }

  CreateClosingLine(price: any) {
    if (this.lastCMPLine) {
      this.candlestickSeries.removePriceLine(this.lastCMPLine);
    }
    const ClosingPrice = price;
    const ClosingPriceLine = {
      price: ClosingPrice,
      color: 'green',
      lineWidth: 1,
      lineStyle: 1,
      axisLabelVisible: true,
      title: 'CMP',
    };
    this.lastCMPLine = this.candlestickSeries.createPriceLine(ClosingPriceLine);
  }

  ngOnDestroy(): void {
    this.disconnectWebSocket();
  }

  disconnectWebSocket(): void {
    this.webSocketService.disconnectStock();
  }

  ngAfterViewInit() {
    // this.chartContainer.nativeElement.addEventListener(
    //   'contextmenu',
    //   (event: MouseEvent) => {
    //     event.preventDefault();
    //     this.showContextMenu(event.clientX, event.clientY);
    //   }
    // );

    for (var key in this.ChartRESPONSE) {
      if (this.ChartRESPONSE.hasOwnProperty(key)) {
        var array = this.ChartRESPONSE[key];
        switch (key) {
          case 'monthly':
            this.MonthlyLabel = key;
            break;
          case 'weekly':
            this.WeeklyLabel = key;
            break;
          case 'daily':
            this.DailyLabel = key;
            break;
          case 'seventy_five':
            this.Seventy_FiveLabel = '75 Minute';
            break;
          case 'sixty':
            this.SixtyLabel = '60 Minute';
            break;
          case 'fifteen':
            this.Fifteen_MinuteLabel = '15 Minute';
            break;
        }
        this.LoadChart(array, key);
        this.spinner.hide()
        this.addPreviousHighPriceLine(key);
        
      }
    }
  }

  openCreateOrderPanel() {
    this.showCreateOrderModal = true;
    this.onOrderTypeChange();
    if (this.SelectedStockName) {
      this.fincreateform.patchValue({
        stock_tick: this.SelectedStockName,
        stock_id: this.stock_id.toString(),
      });
    } else {
      console.warn('SelectedStockName is undefined');
    }
  }

  closeCreateOrderPanel() {
    this.showCreateOrderModal = false;
    this.fincreateform.reset();
    this.submitted = false;
  }

  AddStock() {
    this.submittedforAddStock = true;
    this.AddStockForm.markAllAsTouched();
    if (this.AddStockForm.invalid) {
      return;
    }
    if (this.AddStockForm.valid) {
      this.spinner.show();
      this.showmsg = 'Adding Stock. PLease Wait !!';
      const trimmedValues = {
        stock_name: this.AddStockForm.value.stock_name.trim(),
        y_stock_name: this.AddStockForm.value.y_stock_name.trim(),
      };
      this.apiService.addstockservice(trimmedValues).subscribe((resp) => {
        if (resp.msg == 'success') {
          this.spinner.hide();
          this.toastr.success('New Stock Added Successfully !');
          this.NewStockPrecessing(resp.response.stock_id);
        } else {
          this.spinner.hide();
          this.toastr.error('Stock Is Already Exists !');
        }
      });
    }
  }

  NewStockPrecessing(stock_id: any) {
    this.spinner.show();
    this.showmsg = 'Data Processing Started . Please Wait !!';
    this.apiService.addstockProcessingservice(stock_id).subscribe((resp) => {
      if (resp.msg == 'success') {
        this.spinner.hide();
        this.toastr.success('New Stock Processed Successfully !');
        this.AddStockcloseButton.nativeElement.click();
      } else {
        this.spinner.hide();
        this.toastr.error('Failed to Process Stock !');
      }
    });
  }

  resetOrderForm() {
    this.fincreateform.reset();
  }

  onOrderTypeChange() {
    let type = '';
    if (this.SETUPTYPE === 'BUY') {
      type = 'Buy';
    } else {
      type = 'Sell';
    }
    const order_type = type;
    this.fincreateform.patchValue({
      entry_price: '',
      stoploss_price: '',
      target_price: '',
    });
    if (this.FullScreenModeValue == 'seventy_five') {
      if (this.updateModelPredictionFlag) {
        this.fincreateform.patchValue({
          order_type: type,
          entry_price: this.EntryPrice.toFixed(2),
          stoploss_price: this.StoplossPrice.toFixed(2),
          target_price: this.TargetPrice.toFixed(2),
        });
      } else {
        const setup = this.setupDataonseventyfive[order_type.toUpperCase()];
        this.EntryPrice = setup.entry_price;
        this.StoplossPrice = setup.stop_loss;
        this.TargetPrice = setup.target_price;
        this.fincreateform.patchValue({
          order_type: type,
          entry_price: this.EntryPrice.toFixed(2),
          stoploss_price: this.StoplossPrice.toFixed(2),
          target_price: this.TargetPrice.toFixed(2),
        });
      }
    } else {
      if (this.updateModelPredictionFlag) {
        this.fincreateform.patchValue({
          order_type: type,
          entry_price: this.EntryPrice.toFixed(2),
          stoploss_price: this.StoplossPrice.toFixed(2),
          target_price: this.TargetPrice.toFixed(2),
        });
      } else {
        const setup = this.setupData[order_type.toUpperCase()];
        this.EntryPrice = setup.entry_price;
        this.StoplossPrice = setup.stop_loss;
        this.TargetPrice = setup.target_price;
        this.fincreateform.patchValue({
          order_type: type,
          entry_price: this.EntryPrice.toFixed(2),
          stoploss_price: this.StoplossPrice.toFixed(2),
          target_price: this.TargetPrice.toFixed(2),
        });
      }
    }
  }

  createOrder() {
    this.selectedDate = this.getCurrentDateTime();
    const leftBar = document.getElementById('leftBar');
    if (leftBar!.classList.contains('open')) {
      leftBar!.classList.remove('open');
    }
    const leftPanel = document.getElementById('leftPanel');
    if (leftPanel) {
      leftPanel.classList.remove('open');
    }
    this.isNotificationVisible = false;
    this.updateModelPredictionFlag = false;
    this.TrackFullScreenMode = false;
    this.ModelPrediction = '';
    this.submitted = false;
    this.cleanupChart();
    this.selectedOption = '';
    this.dropdownShow = false;
    this.selectedOptions = {
      base_candle: false,
      buy_sell_zone: false,
      bad_zone: false,
      setup: false,
    };
  }

  getCurrentDateTime(): string {
    const finDataStock = this.finform.value;
    const selectedDatetimeStr = finDataStock.last_d_time;

    // Convert the string to a Date object
    const selectedDatetime = new Date(selectedDatetimeStr.replace(' ', 'T'));

    const year = selectedDatetime.getFullYear();
    const month = String(selectedDatetime.getMonth() + 1).padStart(2, '0');
    const day = String(selectedDatetime.getDate()).padStart(2, '0');
    const hours = String(selectedDatetime.getHours()).padStart(2, '0');
    const minutes = String(selectedDatetime.getMinutes()).padStart(2, '0');

    return `${year}-${month}-${day}T${hours}:${minutes}`;
  }

  create() {
    this.showmsg = 'Please Wait !!';
    this.submitted = true;
    this.fincreateform.markAllAsTouched();
    if (this.fincreateform.invalid) {
      return;
    }
    if (this.fincreateform.valid) {
      this.spinner.show();
      const finDataStock = this.finform.value;
      this.fincreateform.patchValue({
        prediction: this.SelectedPrediction,
        probability: this.SelectedProbability / 100,
        country_id: this.countryId,
        stock_tick: this.selectedStockId,
        purchased_cmp_date: this.getCurrentDateTime(),
        time_frame: finDataStock.time_frame,
      });
      const fincreateorderData = this.fincreateform.value;
      this.apiService.createorder(fincreateorderData).subscribe((resp) => {
        this.createorderResp = resp;
        if (resp.msg == 'success') {
          // this.closemodal.nativeElement.click();
          this.spinner.hide();
          this.toastr.success('Order Create Success ', 'ALERT !');
          this.closeCreateOrderPanel();
          this.stopTimer();
          // this.router.navigate(['orderlist']);
        } else {
          this.spinner.hide();
          this.toastr.error(resp.response, 'ALERT !');
        }
      });
    }
  }

  stopTimer() {
    clearInterval(this.timer);
  }

  onStockChange(event: any) {
    const selectedValue = (event.target as HTMLSelectElement).value;
    this.selectedStockId = selectedValue;
  }

  updateSelectedDate(event: any) {
    const selectedValue = (event.target as HTMLSelectElement).value;
    this.selectedDate = selectedValue;
  }

  onCountryChange(countryName: any) {
    this.apiService.getStockDataByCountry(countryName).subscribe((resp) => {
      this.stockData = resp.response;
    });
  }

  download() {
    this.showmsg = 'Please Wait !!';
    this.spinner.show();
    this.apiService.accessTokenValidationService().subscribe((resp) => {
      if (resp.msg == 'success') {
        this.callDownloadDataService();
      } else {
        alert(
          'Failed to validate access token. Please select a valid request token!'
        );
        this.spinner.hide();
      }
    });
  }

  callDownloadDataService() {
    let retryCount = 0;
    const downloadData = () => {
      this.apiService.downloadLatestDataService().subscribe((downloadResp) => {
        if (downloadResp.msg == 'success') {
          this.apiService.parseLatestDataCsvService().subscribe((resp) => {
            if (resp.msg == 'success') {
              this.apiService.processStockItemsService().subscribe((resp) => {
                this.spinner.hide();
              });
            }
          });
        } else {
          retryCount++;
          if (retryCount < 10) {
            downloadData();
          } else {
            alert('Unable to process. Please retry later.');
          }
        }
      });
    };

    downloadData();
  }

  ViewOrderList() {
    this.router.navigate(['orderlist']);
  }

  autoorderlist() {
    this.router.navigate(['auto-order-list']);
  }

  validateToken() {
    if (this.token == undefined || this.token == '') {
      alert('Empty Token !');
    } else {
      this.state = '1006';
      const token = encodeURIComponent(this.token);
      this.apiService.tokenService(token, this.state).subscribe((resp) => {
        if (resp.response.status == 200) {
          this.toastr.success('Token Validation Successfull !');
        } else {
          alert(
            'Failed to generate access token. Please select a valid request token!'
          );
        }
      });
    }
  }

  initializeCandles(): void {
    this.candles = Array.from({ length: 10 }, () => ({
      color: 'green',
      height: this.getRandomHeight(),
      wickHeight: this.getRandomWickHeight(),
    }));
  }

  getRandomWickHeight(): number {
    return Math.floor(Math.random() * 30) + 10;
  }

  getRandomHeight(): number {
    return Math.floor(Math.random() * 50) + 20;
  }

  startRandomColorToggle(): void {
    this.colorInterval = setInterval(() => {
      this.candles = this.candles.map((candle) => ({
        color: Math.random() > 0.5 ? 'green' : 'red',
        height: this.getRandomHeight(),
        wickHeight: this.getRandomWickHeight(),
      }));
    }, 500);
  }

  // openBar() {
  //   const leftPanel = document.getElementById('leftPanel');
  //   if (leftPanel) {
  //     leftPanel.classList.remove('open');
  //   }
  //   const leftBar = document.getElementById('leftBar');
  //   if (leftBar) {
  //     const windowHeight: number = window.innerHeight;
  //     const targetHeight: number = 80;
  //     leftBar.style.top = `${targetHeight}px`;
  //     leftBar.style.height = `${windowHeight - targetHeight}px`;
  //     leftBar.style.overflowY = 'auto';
  //     if (leftBar.classList.contains('open')) {
  //       leftBar.classList.remove('open');
  //     } else {
  //       leftBar.classList.add('open');
  //     }
  //   }
  // }

//   openBar(isOpen: boolean) {
//   const leftPanel = document.getElementById('leftPanel');
//   if (leftPanel) {
//     leftPanel.classList.remove('open');
//   }

//   const leftBar = document.getElementById('leftBar');
//   if (!leftBar) return;

//   if (isOpen) {
//     const windowHeight: number = window.innerHeight;
//     const targetHeight: number = 80;
//     leftBar.style.top = `${targetHeight}px`;
//     leftBar.style.height = `${windowHeight - targetHeight}px`;
//     leftBar.style.overflowY = 'auto';
//     leftBar.classList.add('open');
//   } else {
//     leftBar.classList.remove('open');
//   }
// }


  togglePanel() {
    const leftBar = document.getElementById('leftBar');
    if (leftBar!.classList.contains('open')) {
      leftBar!.classList.remove('open');
    }
    const leftPanel = document.getElementById('leftPanel');
    if (leftPanel) {
      const windowHeight: number = window.innerHeight;
      const targetHeight: number = 150;
      leftPanel.style.top = `${targetHeight}px`;
      leftPanel.style.height = `${windowHeight - targetHeight}px`;
      if (leftPanel.classList.contains('open')) {
        leftPanel.classList.remove('open');
      } else {
        leftPanel.classList.add('open');
      }
    }
  }

  submit() {
    this.GapUpDownData = [];
    this.QualifiedData = null;
    this.PreviousHighData = null;
    this.BuySetupData = null;
    this.SellSetupData = null;
    this.BuyZoneData = null;
    this.OptimizedBuySellZoneData = null;
    this.SellZoneData = null;
    this.BaseCandleData = null;
    this.QualifiedDataonSeventyfive = null;
    this.BadZoneData = null;
    this.GapData = null;
    this.OverLayCandleData = null;
    this.BuyOverlayDataonSeventyFive = null;
    this.AllZonesData = null;
    this.setupData = null;
    this.TrendAnalyzer = '';
    this.Counter = 0;

    this.finform.markAllAsTouched();
    if (this.finform.invalid) {
      return;
    }
    if (this.finform.valid) {

      this.showmsg = 'Analyzing Data and Generating Your Graph... Please Wait.';
      this.clearChartDiv();
      this.spinner.show();
      this.OriginalFinData = JSON.parse(JSON.stringify(this.finform.value)); // 🔥 deep copy
      this.finData = { ...this.OriginalFinData }; // Shallow copy of top-level properties
      if (!this.finData.last_d_time) {
        const currentDateTime = moment();
        this.finData.last_d_time = currentDateTime.format(
          'YYYY-MM-DD HH:mm:ss'
        );
        // this.finData.last_d_time = currentDateTime.format("DD-MM-YYYY HH:mm:ss");
      } else {
        this.TimeFrame = this.finData.time_frame;
        const originalDateString = this.finData.last_d_time;
        const originalDate = new Date(originalDateString);
        const year = originalDate.getFullYear();
        const month = ('0' + (originalDate.getMonth() + 1)).slice(-2);
        const day = ('0' + originalDate.getDate()).slice(-2);
        const hours = ('0' + originalDate.getHours()).slice(-2);
        const minutes = ('0' + originalDate.getMinutes()).slice(-2);
        const seconds = ('0' + originalDate.getSeconds()).slice(-2);
        const formattedDateString = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
        this.finData.last_d_time = formattedDateString;
      }
      this.finData.tick = this.OriginalFinData.tick.stock_tick;
      this.selectedStockId = this.OriginalFinData.tick.stock_tick;
      this.UpdateCnadleStockId = this.OriginalFinData.tick.id;
      this.TimeFrame = this.finData.time_frame;
      this.previousHighService();
      // Prepare promises for initial API calls
      const promises = [
        this.getGapupDownData(),
        this.GetBaseCandleData(),
        this.GetBuyZoneData(),
        this.GetSellZoneData(),
        this.OverLayFetching(),
        this.GetAllZones(),
        this.GetQualifiedZones(),
        this.GetSetUpData(),
        this.OptimizedBuySellZoneFunc(),
        this.trendAnalyzerFunction(),
        this.PricePercentage()
      ];

      // Add additional API calls based on time_frame
      this.MasterTimeFrameToHideSpinner = this.finData.time_frame;
      this.MasterTimeFrameToHideSpinner = this.finData.time_frame;
      if (this.finData.time_frame === '1') {
        this.layoutFlagfirst = true;
        this.layoutFlagsecond = false;
        this.layoutFlagthird = false;
        this.layoutFlagfourth = false;
        this.layoutFlagfifth = false;
        this.layoutFlagsixth = false;
      } else if (this.finData.time_frame === '2') {
        promises.push(
          this.OptimizedBUySellFor75(),
          this.GetSetUpDataonSeventy_five(),
          this.GetQualifiedZonesonSeventy_five(),
          this.OverLayFetchingonSeventyFive()
        );
        this.layoutFlagfirst = false;
        this.layoutFlagsecond = true;
        this.layoutFlagthird = false;
        this.layoutFlagfourth = false;
        this.layoutFlagfifth = false;
        this.layoutFlagsixth = false;
      } else if (this.finData.time_frame === '3') {
        promises.push(
          this.GetSetUpDataonSeventy_five(),
          this.GetQualifiedZonesonSeventy_five(),
          this.OverLayFetchingonSeventyFive()
        );
        this.layoutFlagfirst = false;
        this.layoutFlagsecond = false;
        this.layoutFlagthird = true;
        this.layoutFlagfourth = false;
        this.layoutFlagfifth = false;
        this.layoutFlagsixth = false;
      } else if (this.finData.time_frame === '4') {
        this.layoutFlagfirst = false;
        this.layoutFlagsecond = false;
        this.layoutFlagthird = false;
        this.layoutFlagfourth = true;
        this.layoutFlagfifth = false;
        this.layoutFlagsixth = false;
      } else if (this.finData.time_frame === '5') {
        this.layoutFlagfirst = false;
        this.layoutFlagsecond = false;
        this.layoutFlagthird = false;
        this.layoutFlagfourth = false;
        this.layoutFlagfifth = true;
        this.layoutFlagsixth = false;
      } else if (this.finData.time_frame === '6') {
        this.layoutFlagfirst = false;
        this.layoutFlagsecond = false;
        this.layoutFlagthird = false;
        this.layoutFlagfourth = false;
        this.layoutFlagfifth = false;
        this.layoutFlagsixth = true;
      }

      // Execute all promises and fetch candle data after they are complete
      Promise.all(promises)
        .then(() => {
          return this.apiService.fetchCandleData(this.finData).toPromise();
        })
        .then((resp) => {
          this.ChartRESPONSE = resp.response;
          this.SelectedStockName = this.finData.tick;
          this.cdRef.detectChanges();
          this.ngAfterViewInit();
        })
        .catch((error) => {
          console.error('Error occurred during API calls', error);
          this.spinner.hide()
        })
        .finally(() => {
          // this.spinner.hide()
        });
    }
  }

  OptimizedBuySellZoneFunc(): Promise<void> {
    return new Promise((resolve, reject) => {
      this.apiService.GetOptimizedBuySellZoneService(this.finData).subscribe({
        next: (resp) => {
          this.OptimizedBuySellZoneData = resp.response;
          resolve();
        },
        error: (err) => {
          console.error('Error in OptimizedBuySellZoneFunc', err);
          reject(err);
        }
      });
    });
  }

  ViewSetupAnyway() {
    this.isDisabled = true; // disable the button
    if (this.SETUPTYPE == "BUY") {
      this.addEntryPriceLine(this.BuySetupData.entry_price, this.BuyTimestampData.entry_price_timestamp, this.BuyTimestampData.extend_timestamp)
      this.addTargetPriceLine(this.BuySetupData.target_price, this.BuyTimestampData.target_price_timestamp, this.BuyTimestampData.extend_timestamp)
      this.addStoplossPriceLine(this.BuySetupData.stop_loss, this.BuyTimestampData.entry_price_timestamp, this.BuyTimestampData.extend_timestamp)
    }
    else {
      this.addEntryPriceLine(this.SellSetupData.entry_price, this.SellTimestampData.entry_price_timestamp, this.SellTimestampData.extend_timestamp)
      this.addTargetPriceLine(this.SellSetupData.target_price, this.SellTimestampData.target_price_timestamp, this.SellTimestampData.extend_timestamp)
      this.addStoplossPriceLine(this.SellSetupData.stop_loss, this.SellTimestampData.entry_price_timestamp, this.SellTimestampData.extend_timestamp)
    }

  }

  GetQualifiedZones(): Promise<void> {
    return new Promise((resolve, reject) => {
      this.apiService.GetQualifiedZoneService(this.finData).subscribe({
        next: (resp) => {
          this.QualifiedData = resp.response;

          if (this.CancelReplayClicked) {
            this.FullScreenMode(this.FullScreenModeValue, 'chart-container_new');
          }

          resolve();
        },
        error: (err) => {
          console.error('Error in GetQualifiedZones', err);
          reject(err);
        }
      });
    });
  }

  GetQualifiedZonesonSeventy_five(): Promise<void> {
    return new Promise((resolve, reject) => {
      const obj = {
        country: localStorage.getItem('selectedCountryName'),
        tick: this.finData.tick,
        time_frame: 25,
        last_d_time: this.finData.last_d_time,
      };

      this.apiService.GetQualifiedZoneService(obj).subscribe({
        next: (resp) => {
          this.QualifiedDataonSeventyfive = resp.response;

          if (this.CancelReplayClicked) {
            this.FullScreenMode(this.FullScreenModeValue, 'chart-container_new');
          }

          resolve();
        },
        error: (err) => {
          console.error('Error in GetQualifiedZonesonSeventy_five', err);
          reject(err);
        }
      });
    });
  }

  OptimizedBUySellFor75(): Promise<void> {
    return new Promise((resolve, reject) => {
      const obj = {
        country: this.finData.country,
        last_d_time: this.finData.last_d_time,
        stock_id: '',
        tick: this.finData.tick,
        time_frame: '25',
      };

      this.apiService.GetOptimizedBuySellZoneService(obj).subscribe({
        next: (resp) => {
          this.OptimizedBuySellZoneData75 = resp.response;
          resolve();
        },
        error: (err) => {
          console.error('Error in OptimizedBUySellFor75', err);
          reject(err);
        }
      });
    });
  }

  OverLayFetching(): Promise<void> {
    return new Promise((resolve, reject) => {
      this.apiService.fetchingOverlayService(this.finData).subscribe({
        next: (resp: any) => {
          this.OverLayCandleData = resp.response;
          this.BuyOverlayData = this.OverLayCandleData.Buy;
          this.SellOverlayData = this.OverLayCandleData.Sell;

          if (this.CancelReplayClicked) {
            this.FullScreenMode(this.FullScreenModeValue, 'chart-container_new');
          }

          resolve();
        },
        error: (err) => {
          console.error('Error in OverLayFetching', err);
          reject(err);
        }
      });
    });
  }

  OverLayFetchingonSeventyFive(): Promise<void> {
    return new Promise((resolve, reject) => {
      const obj = {
        country: localStorage.getItem('selectedCountryName'),
        tick: this.finData.tick,
        time_frame: 25,
        last_d_time: this.finData.last_d_time,
      };

      this.apiService.fetchingOverlayService(obj).subscribe({
        next: (resp: any) => {
          this.OverLayCandleDataonSevetyFive = resp.response;
          this.BuyOverlayDataonSeventyFive = this.OverLayCandleDataonSevetyFive.Buy;
          this.SellOverlayDataonSeventyFive = this.OverLayCandleDataonSevetyFive.Sell;

          if (this.CancelReplayClicked) {
            this.FullScreenMode(this.FullScreenModeValue, 'chart-container_new');
          }
          resolve();
        },
        error: (err) => {
          console.error('Error in OverLayFetchingonSeventyFive', err);
          reject(err);
        }
      });
    });
  }

  GetSetUpData(): Promise<void> {
    return new Promise((resolve, reject) => {
      this.setupData = [];

      this.apiService.GetSetupDataService(this.finData).subscribe({
        next: (resp) => {
          if (resp.msg === 'failed') {
            this.setupdataStatus = resp.msg;
          } else {
            this.setupdataStatus = resp.status;
            this.setupData = resp.response;
            this.TradeSetupReason = resp.response.reason;

            if (this.CancelReplayClicked) {
              this.FullScreenMode(this.FullScreenModeValue, 'chart-container_new');
            }
          }
          resolve();
        },
        error: (err) => {
          console.error('Error in GetSetUpData', err);
          reject(err);
        }
      });
    });
  }

  GetSetUpDataonSeventy_five(): Promise<void> {
    return new Promise((resolve, reject) => {
      const sedndOBj = {
        country: localStorage.getItem('selectedCountryName'),
        tick: this.finData.tick,
        time_frame: 25,
        last_d_time: this.finData.last_d_time,
      };

      this.apiService.GetSetupDataService(sedndOBj).subscribe({
        next: (resp) => {
          if (resp.msg === 'failed') {
            this.setupdataStatus = resp.msg;
          } else {
            this.setupdataStatus = resp.status;
            this.setupDataonseventyfive = resp.response;

            if (this.CancelReplayClicked) {
              this.FullScreenMode(this.FullScreenModeValue, 'chart-container_new');
            }
          }
          resolve();
        },
        error: (err) => {
          console.error('Error in GetSetUpDataonSeventy_five', err);
          reject(err);
        }
      });
    });
  }

  trendAnalyzerFunction() {
    this.apiService.TrendAnalyzerService(this.finData).subscribe((resp) => {
      this.TrendAnalyzer = resp.response;
    });
  }

  GetgapZone() {
    // this.setupData = []
    this.showmsg = 'Fetching Data !';
    this.apiService.GetGapDataService(this.finData).subscribe((resp) => {
      this.GapData = resp.response;
    });
  }

  GetBuyZoneData(): Promise<void> {
    return new Promise((resolve, reject) => {
      this.apiService.GetBuyZoneDataService(this.finData).subscribe({
        next: (resp) => {
          this.BuyZoneData = resp.response;
          if (this.CancelReplayClicked) {
            this.FullScreenMode(this.FullScreenModeValue, 'chart-container_new');
          }
          // console.log(`RESPONSE 2 (BUY ZONE) :`, this.BuyZoneData);
          resolve();
        },
        error: (err) => {
          console.error('Error in GetBuyZoneData', err);
          reject(err);
        }
      });
    });
  }

  GetSellZoneData(): Promise<void> {
    return new Promise((resolve, reject) => {
      this.apiService.GetSellZoneDataService(this.finData).subscribe({
        next: (resp) => {
          this.SellZoneData = resp.response;

          if (this.CancelReplayClicked) {
            this.FullScreenMode(this.FullScreenModeValue, 'chart-container_new');
          }

          resolve();
        },
        error: (err) => {
          console.error('Error in GetSellZoneData', err);
          reject(err);
        }
      });
    });
  }

  GetBaseCandleData(): Promise<void> {
    return new Promise((resolve, reject) => {
      this.apiService.GetBaseCandleData(this.finData).subscribe({
        next: (resp) => {
          this.BaseCandleData = resp.response;
          if (this.CancelReplayClicked) {
            this.FullScreenMode(this.FullScreenModeValue, 'chart-container_new');
          }
          resolve();
        },
        error: (err) => {
          console.error('Error in GetBaseCandleData', err);
          reject(err);
        }
      });
    });
  }

  GetAllZones(): Promise<void> {
    return new Promise((resolve, reject) => {
      this.apiService.GetAllZonesData(this.finData).subscribe({
        next: (resp) => {
          this.AllZonesData = resp.response;

          if (this.CancelReplayClicked) {
            this.FullScreenMode(this.FullScreenModeValue, 'chart-container_new');
          }

          // console.log(`RESPONSE 5 (ALL ZONE) :`, this.AllZonesData);
          resolve();
        },
        error: (err) => {
          console.error('Error in GetAllZones', err);
          reject(err);
        }
      });
    });
  }

  clearChartDiv() {
    const monthlyDiv = this.elementRef.nativeElement.querySelector('#monthly');
    const weeklyDiv = this.elementRef.nativeElement.querySelector('#weekly');
    const dailyDiv = this.elementRef.nativeElement.querySelector('#daily');
    const seventy_five_minute_Div =
      this.elementRef.nativeElement.querySelector('#seventy_five');
    const sixty_minute_Div =
      this.elementRef.nativeElement.querySelector('#sixty');
    const fifteen_minute_Div =
      this.elementRef.nativeElement.querySelector('#fifteen');

    if (monthlyDiv) {
      monthlyDiv.innerHTML = '';
    }
    if (weeklyDiv) {
      weeklyDiv.innerHTML = '';
    }
    if (dailyDiv) {
      dailyDiv.innerHTML = '';
    }
    if (seventy_five_minute_Div) {
      seventy_five_minute_Div.innerHTML = '';
    }
    if (sixty_minute_Div) {
      sixty_minute_Div.innerHTML = '';
    }
    if (fifteen_minute_Div) {
      fifteen_minute_Div.innerHTML = '';
    }
  }

  getGapupDownData(): Promise<void> {
    return new Promise((resolve, reject) => {
      this.apiService.GetGapUpDownDataService(this.finData).subscribe({
        next: (resp) => {
          this.GapUpDownData = resp.response;
          resolve();
        },
        error: (err) => {
          console.error('Error in getGapupDownData', err);
          reject(err);
        }
      });
    });
  }

  LoadChart(data: any, chartId: any) {
    const extraRight = 80;    // how much empty space you want
    const lookback = 140;     // how many real candles to show

    // data = data.slice(0, -1);
    this.FULLSCREENCHARTDATA = data;
    this.lastBar = data ? data.at(-1) : null;
    let chart = null;
    const chartProperties = {
      grid: {
        vertLines: { visible: false },
        horzLines: { visible: false },
      },
      timeScale: {
        timeVisible: true,
        secondsVisible: false,
        rightOffset: 0,
      },
      crosshair: {
        mode: CrosshairMode.Normal,
      },
    };

    chart = createChart(document.getElementById(chartId)!, {
      ...chartProperties,
      layout: {
        background: {
          color: '#f0ffff',
        },
      },
    });

   if (this.TrackFullScreenMode==true) {
      chart.applyOptions({
        watermark: {
          visible: true,
          fontSize: 20,
          horzAlign: 'left',
          vertAlign: 'top',
          color: 'rgb(128, 128, 128)',
          text: this.SelectedStockName.toUpperCase() + " | " + this.ModalHeader.toUpperCase(),
        },
        grid: {
          vertLines: { visible: false },
          horzLines: { visible: false },
        },
      });
    }

    this.areaSeries = chart.addAreaSeries({
      lineColor: '#2962FF',
      topColor: '#2962FF',
      bottomColor: 'rgba(41, 98, 255, 0.28)',
    });

    // NUMBER 1
    this.candlestickSeries = chart.addCandlestickSeries({
      upColor: '#006401',
      downColor: '#8b0101',
      borderVisible: false,
      wickUpColor: '#26a69a',
      wickDownColor: '#ef5350',
      lastValueVisible: false,
      priceLineVisible: false,
    });
   
    const paddingBars = 200;
    // Whitespace before first candle
    const prebars = Array.from({ length: paddingBars }, (_, i) => ({
      time: data[0].time - (paddingBars - i) * this.xspan, // older times
    }));

    // this.connectCMPWebsocket(data)

    const postbars = [...new Array(500)].map((_, i) => ({
      time: data[data.length - 1].time + (i + 1) * this.xspan,
    }));

    this.candlestickSeries.setData([...data, ...postbars]);

    chart.timeScale().fitContent();

    // this.candlestickSeries.setData([...data, ...postbars]);

    // chart.timeScale().setVisibleLogicalRange({
    //   from: Math.max(0, data.length - lookback),
    //   to: data.length + extraRight,
    // });

    chart.priceScale('right').applyOptions({
      scaleMargins: {
        top: 0.0,
        bottom: 0.0,
      },
    });

    this.rectangleTool = new RectangleDrawingTool(
      chart,
      this.candlestickSeries,
      document.querySelector<HTMLDivElement>('#toolbar')!,
      {
        showLabels: false,
      }
    );
    const maData = this.calculateMovingAverageSeriesData(data, 20);

    const maSeries = chart.addLineSeries({
      color: '#2962FF',
      lineWidth: 1,
      title: 'EMA',
    });
    maSeries.setData(maData);

    if (this.isReplayMode) {
      this.candlestickSeries.setData([...data, ...postbars]);
    } else {
      const candlestickSeries = chart.addCandlestickSeries({
        upColor: '#006401',
        downColor: '#8b0101',
        borderVisible: false,
        wickUpColor: '#26a69a',
        wickDownColor: '#ef5350',
        lastValueVisible: false,
        priceLineVisible: false,
      });
      this.candlestickSeries.setData([...data, ...postbars]);
    }

    chart.subscribeCrosshairMove((param) => {
      if (param.time) {
        const seriesPrices = param.seriesData.get(this.candlestickSeries);
        if (seriesPrices) {
          this.toolTipData = seriesPrices;
          this.Open = this.toolTipData.open.toFixed(2);
          this.Close = this.toolTipData.close.toFixed(2);
          this.High = this.toolTipData.high.toFixed(2);
          this.Low = this.toolTipData.low.toFixed(2);
          if (this.Close > this.Open) {
            this.CandleColor = 'green';
          } else {
            this.CandleColor = 'red';
          }
        } else {
          this.Open = '';
          this.Close = '';
          this.High = '';
          this.Low = '';
        }
      }
    });
    this.chart = chart;
    this.chart.subscribeClick(this.onChartClick.bind(this));
  }

  connectCMPWebsocket(CandleData: any) {
    this.webSocketService.connect(
      this.finData.tick,
      this.finData.time_frame,
      this.UpdateCnadleStockId,
      this.FullScreenModeValue
    );
    this.webSocketService.getStockMessage().subscribe((data) => {
      this.realTimePrice = data;
      const parsedData = JSON.parse(data);
      const updatedCandle = {
        open: Number(parsedData.data.open),
        high: Number(parsedData.data.high),
        low: Number(parsedData.data.low),
        close: Number(parsedData.data.close),
        time: Number(parsedData.data.time),
      };

      const newSeriesData = [...CandleData, updatedCandle];

      const postbars = [...new Array(100)].map((_, i) => ({
        time:
          newSeriesData[newSeriesData.length - 1].time + (i + 1) * this.xspan,
      }));

      this.candlestickSeries.setData([...newSeriesData, ...postbars]);

      this.candlestickSeries.setData([...data]);
      if (this.finData.tick === parsedData.data.stock_tick) {
        // this.updateChart(data);
      }
    });
  }

  drawLineSeries() {
    this.candlestickSeries.applyOptions({ visible: false });
    this.lineSeries.setData(this.LINEDATA);
    this.lineSeries.applyOptions({ visible: true });
  }

  drawCandleSeries() {
    this.lineSeries.applyOptions({ visible: false });
    this.candlestickSeries.applyOptions({ visible: true });
  }

  calculateMovingAverageSeriesData(candleData: any, maLength: any) {
    const maData = [];
    for (let i = 0; i < candleData.length; i++) {
      if (i < maLength) {
        maData.push({ time: candleData[i].time });
      } else {
        let sum = 0;
        for (let j = 0; j < maLength; j++) {
          sum += candleData[i - j].close;
        }
        const maValue = sum / maLength;
        maData.push({ time: candleData[i].time, value: maValue });
      }
    }
    return maData;
  }

  FullScreenMode(type: any, chartId: any) {
    this.disconnectWebSocket();
    const chart_container_new = this.elementRef.nativeElement.querySelector(
      '#chart-container_new'
    );
    if (chart_container_new) {
      chart_container_new.innerHTML = '';
    }
    this.TrackFullScreenMode = true;
    this.dropdownShow = false;
    switch (type) {
      case 'monthly':
        this.FullScreenModeValue = type;
        this.ModalHeader = type;
        this.suggestion = false;
        break;
      case 'weekly':
        this.FullScreenModeValue = type;
        this.ModalHeader = type;
        this.suggestion = false;
        break;
      case 'daily':
        this.FullScreenModeValue = type;
        this.ModalHeader = type;
        if (this.TimeFrame == 1) {
          this.suggestion = true;
        } else {
          this.suggestion = false;
        }
        break;
      case 'seventy_five':
        this.FullScreenModeValue = type;
        this.ModalHeader = '75 Minute';
        this.suggestion = true;
        break;
      case 'sixty':
        this.FullScreenModeValue = type;
        this.ModalHeader = '60 Minute';
        if (this.TimeFrame == 2) {
          this.suggestion = true;
        } else {
          this.suggestion = false;
        }
        break;
      case 'fifteen':
        this.FullScreenModeValue = type;
        this.ModalHeader = '15 Minute';
        if (this.TimeFrame == 3) {
          this.suggestion = true;
        } else {
          this.suggestion = false;
        }
        break;
      case 'one_twenty_five':
        this.FullScreenModeValue = type;
        this.ModalHeader = '125 Minute';
        if (this.TimeFrame == 4 || this.TimeFrame == 5) {
          this.suggestion = true;
        }
        break;
      case 'twenty_five':
        this.FullScreenModeValue = type;
        this.ModalHeader = '25 Minute';
        if (this.TimeFrame == 6) {
          this.suggestion = true;
        } else {
          this.suggestion = false;
        }
        break;
    }
    const data = this.ChartRESPONSE[type];
    const toolbarDiv = this.elementRef.nativeElement.querySelector('#toolbar');
    if (toolbarDiv) {
      toolbarDiv.innerHTML = '';
    }
    // const newDataArray = data.slice(0, -1)
    this.LoadChart(data, chartId);
    this.addPreviousHighPriceLine(type);
    const now = new Date();
    const dayOfWeek = now.getDay();
    const hours = now.getHours();
    const minutes = now.getMinutes();
    const lastRow = data.slice(-1)[0];
    this.CreateClosingLine(lastRow.close);
    this.connectWebSocket(type);

    // if (dayOfWeek >= 1 && dayOfWeek <= 5 && (hours > 9 || (hours === 9 && minutes >= 15)) && (hours < 15 || (hours === 15 && minutes <= 30))) {
    //   this.connectWebSocket();
    // } else {
    // }
  }

  previousHighService(): Promise<void> {
    return new Promise((resolve, reject) => {
      this.apiService.GetprevioushighDataService(this.finData).subscribe({
        next: (resp) => {
          this.PreviousHighData = resp.response;

          if (this.CancelReplayClicked) {
            this.FullScreenMode(this.FullScreenModeValue, 'chart-container_new');
          }
          resolve();
        },
        error: (err) => {
          console.error('Error in previousHighService', err);
          reject(err);
        }
      });
    });
  }

  clearDrawing() {
    const toolbarDiv = this.elementRef.nativeElement.querySelector('#toolbar');
    if (toolbarDiv) {
      toolbarDiv.innerHTML = '';
    }
  }

  ChangeScreenMode(type: any, chartId: any) {
    const prevFullScreen = this.FullScreenModeValue;
    this.disconnectWebSocket();
    this.updateModelPredictionFlag = false;
    if (this.horizontalLines && this.horizontalLines.length > 0) {
      this.horizontalLines.forEach((line) => {
        this.chart.removeSeries(line.series);
      });
      this.horizontalLines = [];
    }
    this.entryEnabled = true;
    this.targetEnabled = true;
    this.stoplossEnabled = true;
    this.EntryPrice = null;
    this.TargetPrice = null;
    this.StoplossPrice = null;
    this.isNotificationVisible = false;
    const dataPresent: boolean = !!this.ChartRESPONSE[type];
    if (dataPresent) {
      this.suggestion = false;
      switch (type) {
        case 'monthly':
          this.ModalHeader = type;
          this.FullScreenModeValue = type;
          this.selectedOption = '';
          break;
        case 'weekly':
          this.ModalHeader = type;
          this.FullScreenModeValue = type;
          this.selectedOption = '';
          break;
        case 'daily':
          this.ModalHeader = type;
          this.FullScreenModeValue = type;
          this.selectedOption = '';
          if (this.TimeFrame == 1) {
            this.suggestion = true;
          } else {
            this.suggestion = false;
          }
          break;
        case 'seventy_five':
          this.ModalHeader = '75 Minute';
          this.FullScreenModeValue = type;
          this.selectedOption = '';
          this.suggestion = true;
          break;
        case 'sixty':
          this.ModalHeader = '60 Minute';
          this.FullScreenModeValue = type;
          this.selectedOption = '';
          if (this.TimeFrame == 2) {
            this.suggestion = true;
          } else {
            this.suggestion = false;
          }
          break;
        case 'fifteen':
          this.ModalHeader = '15 Minute';
          this.FullScreenModeValue = type;
          this.selectedOption = '';
          if (this.TimeFrame == 3) {
            this.suggestion = true;
          } else {
            this.suggestion = false;
          }
          break;
        case 'one_twenty_five':
          this.ModalHeader = '125 Minute';
          this.FullScreenModeValue = type;
          this.selectedOption = '';
          if (this.TimeFrame == 4 || this.TimeFrame == 5) {
            this.suggestion = true;
          } else {
            this.suggestion = false;
          }
          break;
        case 'twenty_five':
          this.ModalHeader = '25 Minute';
          this.FullScreenModeValue = type;
          this.selectedOption = '';
          if (this.TimeFrame == 6) {
            this.suggestion = true;
          } else {
            this.suggestion = false;
          }
          break;
      }
      const data = this.ChartRESPONSE[type];
      this.cleanup();
      this.LoadChart(data, chartId);
      this.addPreviousHighPriceLine(type);
      const now = new Date();
      const dayOfWeek = now.getDay(); // getDay() returns a value between 0 (Sunday) and 6 (Saturday)
      const hours = now.getHours();
      const minutes = now.getMinutes();
      const lastRow = data.slice(-1)[0];
      this.CreateClosingLine(lastRow.close);
      this.connectWebSocket(type);
      this.applyViewGraphOverlapLogic(prevFullScreen); // ✅ NEW

      this.checkboxClicked(this.selectedOptions)    //Selected Zone Enabled
      // if (dayOfWeek >= 1 && dayOfWeek <= 5 && (hours > 9 || (hours === 9 && minutes >= 15)) && (hours < 15 || (hours === 15 && minutes <= 30))) {
      //   this.connectWebSocket(type);
      // } else {
      //   console.log("WebSocket connection can only be made between Monday to Friday, 9:15 AM to 3:30 PM.");
      // }
    } else {
      this.toastr.error(`No Data found !`);
      return;
    }
  }


   private applyViewGraphOverlapLogic(prevFullScreen: string) {
    const tf = Number(this.finData.time_frame);
    const baseMap: Record<number, string> = {
      1: "daily",     
      2: "sixty",
      3: "fifteen",
      5: "one_twenty_five",
      4: "one_twenty_five",
      6: "twenty_five",
    };

    const base = baseMap[tf];
    if (!base) return;

    // init memory
    if (!this.viewGraphOverlapMemory[tf]) {
      this.viewGraphOverlapMemory[tf] = { evaluate: false, analyze: false ,qualified: false};
    }

    // 1) If leaving base -> remember BOTH selections
    if (prevFullScreen === base) {
      this.viewGraphOverlapMemory[tf] = {
        evaluate: !!this.selectedOptions["overlap_evaluate"],
        analyze: !!this.selectedOptions["overlap_analyze"],
        qualified: !!this.selectedOptions["qualified_zones"],
      };
    }

    const mem = this.viewGraphOverlapMemory[tf];

    // 2) If returned to base -> restore BOTH, else clear UI flags (memory stays)
    if (this.FullScreenModeValue === base) {
      this.selectedOptions["overlap_evaluate"] = mem.evaluate;
      this.selectedOptions["overlap_analyze"]  = mem.analyze;
      this.selectedOptions["qualified_zones"]  = mem.qualified;
    } else {
      this.selectedOptions["overlap_evaluate"] = false;
      this.selectedOptions["overlap_analyze"]  = false;
      this.selectedOptions["qualified_zones"]  = false;
    }

    // 3) Calculate optimized dynamically (OR logic, both can trigger)
    this.selectedOptions.optimized_buy_sell_zone = false;

    // ---- ViewGraphTimeFrame == 2 ----

    if (tf === 1) {
      if (mem.evaluate && this.FullScreenModeValue === "monthly") this.selectedOptions.optimized_buy_sell_zone = true;
      if (mem.analyze && this.FullScreenModeValue === "weekly")  this.selectedOptions.optimized_buy_sell_zone = true;
    }

    if (tf === 2) {
      if (mem.evaluate && this.FullScreenModeValue === "weekly") this.selectedOptions.optimized_buy_sell_zone = true;
      if (mem.analyze && this.FullScreenModeValue === "daily")  this.selectedOptions.optimized_buy_sell_zone = true;
    }

    // ---- ViewGraphTimeFrame == 3 ----
    if (tf === 3) {
      if (mem.evaluate && this.FullScreenModeValue === "daily") this.selectedOptions.optimized_buy_sell_zone = true;
      if (mem.analyze && this.FullScreenModeValue === "sixty") this.selectedOptions.optimized_buy_sell_zone = true;
    }

    // ---- ViewGraphTimeFrame == 4 ----
    if (tf==4) {
      if (mem.evaluate && this.FullScreenModeValue === "monthly") this.selectedOptions.optimized_buy_sell_zone = true;
      if (mem.analyze && this.FullScreenModeValue === "weekly")   this.selectedOptions.optimized_buy_sell_zone = true;
    }

    if (tf==5) {
      if (mem.evaluate && this.FullScreenModeValue === "weekly") this.selectedOptions.optimized_buy_sell_zone = true;
      if (mem.analyze && this.FullScreenModeValue === "daily")   this.selectedOptions.optimized_buy_sell_zone = true;
    }

    // ---- ViewGraphTimeFrame == 6 ----
    if (tf === 6) {
      if (mem.evaluate && this.FullScreenModeValue === "daily")          this.selectedOptions.optimized_buy_sell_zone = true;
      if (mem.analyze && this.FullScreenModeValue === "one_twenty_five") this.selectedOptions.optimized_buy_sell_zone = true;
    }
  }

  toggleChartInversion() {
    this.isChartInverted = !this.isChartInverted;

    if (this.chart) {
      this.chart.priceScale('right').applyOptions({
        invertScale: this.isChartInverted,
      });
    }
  }

  CloseFullModal() {
    this.EntryPrice = null;
    this.TargetPrice = null;
    this.StoplossPrice = null;
    this.fincreateformForMannualSetup.reset();
    this.submittedForMannual = false;
    // ✅ Remove all placed horizontal lines from the chart
    if (this.horizontalLines && this.horizontalLines.length > 0) {
      this.horizontalLines.forEach((line) => {
        this.chart.removeSeries(line.series);
      });
      this.horizontalLines = [];
    }

    this.entryEnabled = true;
    this.targetEnabled = true;
    this.stoplossEnabled = true;

    // ✅ Remove preview line if any
    if (this.previewLine) {
      this.chart.removeSeries(this.previewLine);
      this.previewLine = null;
    }

    // ✅ Unsubscribe event listeners if still active
    if (this.boundShowPreviewLine) {
      this.chart.unsubscribeCrosshairMove(this.boundShowPreviewLine);
      this.boundShowPreviewLine = null;
    }
    if (this.boundFixLineAtPrice) {
      this.chart.unsubscribeClick(this.boundFixLineAtPrice);
      this.boundFixLineAtPrice = null;
    }

    // ✅ Reset placement mode
    this.placementMode = 'none';

    // ✅ Clear selected line (if any was selected for delete or drag)
    this.selectedLine = null;

    // ✅ Enable chart interactions again (if disabled during drag)
    this.chart.applyOptions({ handleScroll: true, handleScale: true });
    if (this.isReplayPlaying) {
      alert('Please Close Bar Replay !');
      return;
    }
    // this.paths = [];
    // this.currentPath = null;
    // const canvas = this.drawingCanvas.nativeElement;
    // const ctx = canvas.getContext('2d');
    // this.redrawCanvas();
    // ctx?.clearRect(0, 0, canvas.width, canvas.height);
    this.disconnectWebSocket();
    this.isNotificationVisible = false;
    this.updateModelPredictionFlag = false;
    this.TrackFullScreenMode = false;
    this.ModelPrediction = '';
    this.CreateButtonFlag = false;
    this.cleanupChart();
    this.selectedOption = '';
    this.dropdownShow = false;
    this.selectedOptions = {
      base_candle: false,
      buy_sell_zone: false,
      bad_zone: false,
      setup: false,
    };
    const leftBar = document.getElementById('leftBar');
    if (leftBar!.classList.contains('open')) {
      leftBar!.classList.remove('open');
    }
    const leftPanel = document.getElementById('leftPanel');
    if (leftPanel) {
      leftPanel.classList.remove('open');
    }
    this.isReplayMode = false;
    this.CancelReplayClicked = true;
    this.replayMode = false;
    this.replayVisibleData = [];
    this.replayFutureData = [];
    this.closeButtonHide.nativeElement.click();
    this.modalalert.hide();
    this.submitStock = false;
  }

  cleanupChart() {
    window.removeEventListener('keydown', this.handleKeyDown);
    if (this.chart) {
      this.chart.remove();
      this.chart = null;
    }
  }

  cleanup(): void {
    if (this.chart) {
      this.chart.remove();
    }
  }

  // checkboxClicked(option: string) {
  //   this.buyZoneMarkers = [];
  //   this.candlestickSeries.setMarkers([]);
  //   this.selectedOptions[option] = !this.selectedOptions[option];
  //   let result = this.checkOptions();
  //   if (result == false) {
  //     if (this.rectangleTool) {
  //       this.rectangleTool.removeAllRectangles()
  //     }

  //     if (this.selectedOptions['qualified_zones']) {
  //       let buy_array = null;
  //       let sell_array = null;
  //       if (this.FullScreenModeValue == "seventy_five") {
  //         buy_array = this.QualifiedDataonSeventyfive["Buy"]
  //       }
  //       else {
  //         buy_array = this.QualifiedData["Buy"];
  //       }
  //       const fillColorBuy = 'rgba(0,255,0,0.2)';
  //       if (buy_array.length > 0) {
  //         for (let item of Object.values(buy_array)) {
  //           this.rectangleTool.addRectanglesFromData(item, fillColorBuy);
  //         }
  //       }
  //       const fillColorSell = 'rgba(255,51,51,0.2)';
  //       if (this.FullScreenModeValue == "seventy_five") {
  //         sell_array = this.QualifiedDataonSeventyfive["Sell"]
  //       }
  //       else {
  //         sell_array = this.QualifiedData["Sell"];
  //       }
  //       if (sell_array.length > 0) {
  //         for (let item of Object.values(sell_array)) {
  //           this.rectangleTool.addRectanglesFromData(item, fillColorSell);
  //         }
  //       }
  //     }
  //     if (this.selectedOptions['all_zones']) {
  //       const array = this.AllZonesData[this.FullScreenModeValue];
  //       const fillColorBuy = 'rgba(50,50,50,0.5)';
  //       var buy_array = array['Buy'];
  //       for (let item of Object.values(buy_array)) {
  //         this.rectangleTool.addRectanglesFromData(item, fillColorBuy);
  //       }
  //       const fillColorSell = 'rgba(50,50,50,0.5)';
  //       var sell_array = array['Sell'];
  //       for (let item of Object.values(sell_array)) {
  //         this.rectangleTool.addRectanglesFromData(item, fillColorSell);
  //       }
  //     }
  //     if (this.selectedOptions['base_candle']) {
  //       this.showmsg = "Fetching Base Candle Data !";
  //       // const buyZoneMarkers = [];
  //       this.buyZoneMarkers = [];
  //       const fillColor = 'rgba(51,153,255,0.3)';
  //       const array = this.BaseCandleData[this.FullScreenModeValue];
  //       for (let item of array) {
  //         this.buyZoneMarkers.push({
  //           time: item,
  //           position: 'aboveBar',
  //           color: 'blue',
  //           shape: 'arrowDown',
  //           text: "B",
  //         });
  //       }
  //       this.candlestickSeries.setMarkers(this.buyZoneMarkers);
  //     }
  //     if (this.selectedOptions['buy_sell_zone']) {
  //       const fillColorBuy = 'rgba(0,255,0,0.2)';
  //       var buy_array = this.BuyZoneData[this.FullScreenModeValue];
  //       for (let item of Object.values(buy_array)) {
  //         this.rectangleTool.addRectanglesFromData(item, fillColorBuy);
  //       }
  //       const fillColorSell = 'rgba(255,51,51,0.2)';
  //       var sell_array = this.SellZoneData[this.FullScreenModeValue];;
  //       for (let item of Object.values(sell_array)) {
  //         this.rectangleTool.addRectanglesFromData(item, fillColorSell);
  //       }
  //     }
  //     if (this.selectedOptions['bad_zone']) {
  //       this.BadZoneData = []
  //       this.apiService.GetBadZoneDataService(this.finData).subscribe(resp => {
  //         this.BadZoneData = resp.response;
  //         let array = this.BadZoneData[this.FullScreenModeValue]
  //         const fillColor = "rgba(41, 3, 3, 0.21)"
  //         for (let item of Object.values(array)) {
  //           this.rectangleTool.addRectanglesFromData(item, fillColor);
  //         }
  //       });
  //     }
  //     if (this.selectedOptions['overlap_evaluate']) {
  //       if (this.finData.time_frame == 1) {
  //         const fillColorBuy = 'rgba(0,59,0,0.2)';
  //         var buy_array = this.BuyOverlayData['monthly'];
  //         for (let item of Object.values(buy_array)) {
  //           this.rectangleTool.addRectanglesFromData(item, fillColorBuy);
  //         }
  //         const fillColorSell = 'rgba(255,51,51,0.2)';
  //         var sell_array = this.SellOverlayData['monthly'];
  //         for (let item of Object.values(sell_array)) {
  //           this.rectangleTool.addRectanglesFromData(item, fillColorSell);
  //         }
  //       }

  //       if (this.finData.time_frame == 2) {
  //         const fillColorBuy = 'rgba(0,59,0,0.2)';
  //         let buy_array = null;
  //         let sell_array = null;
  //         if (this.FullScreenModeValue == "seventy_five") {
  //           buy_array = this.BuyOverlayDataonSeventyFive['weekly']
  //           sell_array = this.SellOverlayDataonSeventyFive['weekly']
  //         }
  //         else {
  //           buy_array = this.BuyOverlayData['weekly'];
  //           sell_array = this.SellOverlayData['weekly']
  //         }
  //         for (let item of Object.values(buy_array)) {
  //           this.rectangleTool.addRectanglesFromData(item, fillColorBuy);
  //         }
  //         const fillColorSell = 'rgba(255,51,51,0.2)';
  //         for (let item of Object.values(sell_array)) {
  //           this.rectangleTool.addRectanglesFromData(item, fillColorSell);
  //         }
  //       }

  //       if (this.finData.time_frame == 3) {
  //         const fillColorBuy = 'rgba(0,59,0,0.2)';
  //         var buy_array = this.BuyOverlayData['daily'];
  //         for (let item of Object.values(buy_array)) {
  //           this.rectangleTool.addRectanglesFromData(item, fillColorBuy);
  //         }
  //         const fillColorSell = 'rgba(255,51,51,0.2)';
  //         var sell_array = this.SellOverlayData['daily'];
  //         for (let item of Object.values(sell_array)) {
  //           this.rectangleTool.addRectanglesFromData(item, fillColorSell);
  //         }
  //       }

  //     }
  //     if (this.selectedOptions['overlap_analyze']) {
  //       if (this.finData.time_frame == 1) {
  //         const fillColorBuy = 'rgba(0,255,0,0.2)';
  //         var buy_array = this.BuyOverlayData['weekly'];
  //         for (let item of Object.values(buy_array)) {
  //           this.rectangleTool.addRectanglesFromData(item, fillColorBuy);
  //         }
  //         const fillColorSell = 'rgba(255,51,51,0.2)';
  //         var sell_array = this.SellOverlayData['weekly'];
  //         for (let item of Object.values(sell_array)) {
  //           this.rectangleTool.addRectanglesFromData(item, fillColorSell);
  //         }
  //       }

  //       if (this.finData.time_frame == 2) {
  //         const fillColorBuy = 'rgba(0,255,0,0.2)';
  //         var buy_array = this.BuyOverlayData['daily'];
  //         for (let item of Object.values(buy_array)) {
  //           this.rectangleTool.addRectanglesFromData(item, fillColorBuy);
  //         }
  //         const fillColorSell = 'rgba(255,51,51,0.2)';
  //         var sell_array = this.SellOverlayData['daily'];
  //         for (let item of Object.values(sell_array)) {
  //           this.rectangleTool.addRectanglesFromData(item, fillColorSell);
  //         }
  //       }

  //       if (this.finData.time_frame == 3) {
  //         const fillColorBuy = 'rgba(0,255,0,0.2)';
  //         var buy_array = this.BuyOverlayData['seventy_five'];
  //         for (let item of Object.values(buy_array)) {
  //           this.rectangleTool.addRectanglesFromData(item, fillColorBuy);
  //         }
  //         const fillColorSell = 'rgba(255,51,51,0.2)';
  //         var sell_array = this.SellOverlayData['seventy_five'];
  //         for (let item of Object.values(sell_array)) {
  //           this.rectangleTool.addRectanglesFromData(item, fillColorSell);
  //         }
  //       }
  //     }
  //     if (this.selectedOptions['optimized_buy_sell_zone']) {
  //       const fillColorBuy = 'rgba(0,255,0,0.2)';
  //       var buy_array = this.OptimizedBuySellZoneData[this.FullScreenModeValue];
  //       for (let item of Object.values(buy_array.BUY)) {
  //         this.rectangleTool.addRectanglesFromData(item, fillColorBuy);
  //       }
  //       const fillColorSell = 'rgba(255,51,51,0.2)';
  //       var sell_array = this.OptimizedBuySellZoneData[this.FullScreenModeValue];
  //       for (let item of Object.values(sell_array.SELL)) {
  //         this.rectangleTool.addRectanglesFromData(item, fillColorSell);
  //       }
  //     }
  //     if (this.selectedOptions['gap_up_down']) {
  //       const fillColor = 'rgba(183,199,21, 1)'; // Green for Gap Up
  //       const fillColor2 = 'rgba(189, 70, 25, 1)'; // Red for Gap Down

  //       const gapData = this.GapUpDownData[this.FullScreenModeValue];

  //       // Initialize marker arrays if needed
  //       const gapMarkers: any[] = [];

  //       // Gap Up
  //       for (let item of Object.values(gapData.gap_ups)) {
  //         const rect = item as { time: number; price: number }[];
  //         this.rectangleTool.addRectanglesFromData(item, fillColor);

  //         // Add Up Arrow Marker
  //         gapMarkers.push({
  //           time: rect[0].time,          // assuming 'time' exists in item
  //           position: 'belowBar',
  //           color: 'green',
  //           shape: 'arrowUp',
  //           text: 'Gap Up',
  //         });
  //       }

  //       // Gap Down
  //       for (let item of Object.values(gapData.gap_downs)) {
  //         const rect = item as { time: number; price: number }[];
  //         this.rectangleTool.addRectanglesFromData(item, fillColor2);

  //         // Add Down Arrow Marker
  //         gapMarkers.push({
  //           time: rect[0].time,
  //           position: 'aboveBar',
  //           color: 'red',
  //           shape: 'arrowDown',
  //           text: 'Gap Down',
  //         });
  //       }
  //       gapMarkers.sort((a, b) => a.time - b.time);
  //       // Finally, set the markers on your series
  //       const allMarkers = [...gapMarkers, ...this.buyZoneMarkers];
  //       allMarkers.sort((a, b) => a.time - b.time);
  //       this.candlestickSeries.setMarkers(allMarkers);
  //     }

  //     if (this.selectedOptions['setup']) {
  //       this.dropdownShow = true;
  //     } else {
  //       this.dropdownShow = false;
  //       if (this.buylineSeries) {
  //         this.buylineSeries.setMarkers([]);
  //         this.buylineSeries.setData([]);
  //       }
  //       if (this.targetlineSeries) {
  //         this.targetlineSeries.setMarkers([]);
  //         this.targetlineSeries.setData([]);
  //       }
  //       if (this.stoplosslineSeries) {
  //         this.stoplosslineSeries.setMarkers([]);
  //         this.stoplosslineSeries.setData([]);
  //       }
  //     }
  //   }
  //   else {
  //     this.dropdownShow = false;
  //     this.candlestickSeries.setMarkers([]);
  //     this.rectangleTool.removeAllRectangles()
  //     if (this.buylineSeries) {
  //       this.buylineSeries.setMarkers([]);
  //       this.buylineSeries.setData([]);
  //     }
  //     if (this.targetlineSeries) {
  //       this.targetlineSeries.setMarkers([]);
  //       this.targetlineSeries.setData([]);
  //     }
  //     if (this.stoplosslineSeries) {
  //       this.stoplosslineSeries.setMarkers([]);
  //       this.stoplosslineSeries.setData([]);
  //     }
  //   }

  // }

  checkboxClicked(option: string) {
    const buyfillColor = 'rgba(16, 185, 129, 0.10)';
    const buyoutlineColor = '#059669';
    const buytextColor = '#065f46';
    const sellfillColor = 'rgba(225, 29, 72, 0.10)';
    const selloutlineColor = '#be123c';
    const selltextColor = '#881337';
    this.buyZoneMarkers = [];
    this.candlestickSeries.setMarkers([]);
    this.selectedOptions[option] = !this.selectedOptions[option];
    let result = this.checkOptions();
    if (result == false) {
      if (this.rectangleTool) {
        this.rectangleTool.removeAllRectangles();
      }
      if (this.selectedOptions['qualified_zones']) {
        let buy_array = null;
        let sell_array = null;
        if (this.FullScreenModeValue == 'seventy_five') {
          buy_array = this.QualifiedDataonSeventyfive['Buy'];
        } else {
          buy_array = this.QualifiedData['Buy'];
        }
         const buyfillColor = 'rgba(0,255,0,0.2)';
        if (buy_array.length > 0) {
          for (let item of Object.values(buy_array)) {
            this.rectangleTool.addRectanglesFromData(item, { fillColor: buyfillColor});
          }
        }
        const sellfillColor = 'rgba(255,51,51,0.2)';
        if (this.FullScreenModeValue == 'seventy_five') {
          sell_array = this.QualifiedDataonSeventyfive['Sell'];
        } else {
          sell_array = this.QualifiedData['Sell'];
        }
        if (sell_array.length > 0) {
          for (let item of Object.values(sell_array)) {
            this.rectangleTool.addRectanglesFromData(item, { fillColor: sellfillColor});
          }
        }
      }
      if (this.selectedOptions['all_zones']) {
        const array = this.AllZonesData[this.FullScreenModeValue];

        const fillColorBuy = 'rgba(50,50,50,0.5)';
        const fillColorSell = 'rgba(50,50,50,0.5)';

        const buy_array = array['Buy'];
        const sell_array = array['Sell'];

        const zoneMarkers: any[] = [];

        for (let item of Object.values(buy_array)) {
          const rect = item as { time: number; price: number }[];
          this.rectangleTool.addRectanglesFromData(rect, { fillColor: fillColorBuy });

          const midTime = Math.floor(
            (rect[0].time + rect[rect.length - 1].time) / 2
          );

          zoneMarkers.push({
            time: midTime,
            position: 'belowBar',
            color: 'green',
            shape: 'arrowUp',
            text: 'Buy',
          });
        }

        for (let item of Object.values(sell_array)) {
          const rect = item as { time: number; price: number }[];
          this.rectangleTool.addRectanglesFromData(rect, { fillColor: fillColorSell });

          const midTime = Math.floor(
            (rect[0].time + rect[rect.length - 1].time) / 2
          );

          zoneMarkers.push({
            time: midTime,
            position: 'aboveBar',
            color: 'red',
            shape: 'arrowDown',
            text: 'Sell',
          });
        }

        zoneMarkers.sort((a, b) => a.time - b.time);
        this.candlestickSeries.setMarkers(zoneMarkers);
      }
      if (this.selectedOptions['base_candle']) {
        this.showmsg = 'Fetching Base Candle Data !';
        // const buyZoneMarkers = [];
        this.buyZoneMarkers = [];
        const fillColor = 'rgba(51,153,255,0.3)';
        const array = this.BaseCandleData[this.FullScreenModeValue];
        for (let item of array) {
          this.buyZoneMarkers.push({
            time: item,
            position: 'aboveBar',
            color: 'blue',
            shape: 'arrowDown',
            text: 'B',
          });
        }
        this.candlestickSeries.setMarkers(this.buyZoneMarkers);
      }
      if (this.selectedOptions['buy_sell_zone']) {
        const fillColorBuy = 'rgba(0,255,0,0.2)';
        var buy_array = this.BuyZoneData[this.FullScreenModeValue];
        console.log(buy_array);
        for (let item of Object.values(buy_array)) {
          this.rectangleTool.addRectanglesFromData(item,{ fillColor: fillColorBuy });
        }
        const fillColorSell = 'rgba(255,51,51,0.2)';
        var sell_array = this.SellZoneData[this.FullScreenModeValue];
        console.log(sell_array);
        for (let item of Object.values(sell_array)) {
          this.rectangleTool.addRectanglesFromData(item, { fillColor: fillColorSell });
        }
      }
      if (this.selectedOptions['bad_zone']) {
        this.BadZoneData = [];
        this.apiService
          .GetBadZoneDataService(this.finData)
          .subscribe((resp) => {
            this.BadZoneData = resp.response;
            let array = this.BadZoneData[this.FullScreenModeValue];
            const fillColor = 'rgba(41, 3, 3, 0.21)';
            for (let item of Object.values(array)) {
              this.rectangleTool.addRectanglesFromData(item,{ fillColor: fillColor });
            }
          });
      }
      if (this.selectedOptions['overlap_evaluate']) {
        if (this.finData.time_frame == 1) {
          var buy_array = this.BuyOverlayData['monthly'];
          for (let item of Object.values(buy_array)) {
           this.rectangleTool.addRectanglesFromData(item, { fillColor: buyfillColor, outlineColor: buyoutlineColor, outlineWidth: 0.5, text: "Monthly", textColor: buytextColor});
          }
          var sell_array = this.SellOverlayData['monthly'];
          for (let item of Object.values(sell_array)) {
           this.rectangleTool.addRectanglesFromData(item, { fillColor: sellfillColor, outlineColor: selloutlineColor, outlineWidth: 0.5, text: "Monthly", textColor: selltextColor });
          }
        }

        if (this.finData.time_frame == 2) {
          let buy_array = null;
          let sell_array = null;
          if (this.FullScreenModeValue == 'seventy_five') {
            console.log(
              '75 OVERLAY DATA BUY',
              this.BuyOverlayDataonSeventyFive
            );
            console.log(
              '75 OVERLAY DATA SELL',
              this.SellOverlayDataonSeventyFive
            );
            buy_array = this.BuyOverlayDataonSeventyFive['weekly'];
            sell_array = this.SellOverlayDataonSeventyFive['weekly'];
          } else {
            buy_array = this.BuyOverlayData['weekly'];
            sell_array = this.SellOverlayData['weekly'];
          }
          for (let item of Object.values(buy_array)) {
            this.rectangleTool.addRectanglesFromData(item, { fillColor: buyfillColor, outlineColor: buyoutlineColor, outlineWidth: 0.5, text: "Weekly", textColor: buytextColor});
          }
          for (let item of Object.values(sell_array)) {
            this.rectangleTool.addRectanglesFromData(item, { fillColor: sellfillColor, outlineColor: selloutlineColor, outlineWidth: 0.5, text: "Weekly", textColor: selltextColor });
          }
        }

        if (this.finData.time_frame == 3) {
           const buyfillColor = 'rgba(0,59,0,0.2)';
          var buy_array = this.BuyOverlayData['daily'];
          for (let item of Object.values(buy_array)) {
            this.rectangleTool.addRectanglesFromData(item, { fillColor: buyfillColor, outlineColor: buyoutlineColor, outlineWidth: 0.5, text: "Daily", textColor: buytextColor });
          }
          const sellfillColor = 'rgba(255,51,51,0.2)';
          var sell_array = this.SellOverlayData['daily'];
          for (let item of Object.values(sell_array)) {
            this.rectangleTool.addRectanglesFromData(item, { fillColor: sellfillColor, outlineColor: selloutlineColor, outlineWidth: 0.5, text: "Daily", textColor: selltextColor });
          }
        }

        if (this.finData.time_frame == 4) {
          var buy_array = this.BuyOverlayData['monthly'];
          for (let item of Object.values(buy_array)) {
            this.rectangleTool.addRectanglesFromData(item, { fillColor: buyfillColor, outlineColor: buyoutlineColor, outlineWidth: 0.5, text: "Monthly", textColor: buytextColor });
          }
          var sell_array = this.SellOverlayData['monthly'];
          for (let item of Object.values(sell_array)) {
            this.rectangleTool.addRectanglesFromData(item, { fillColor: sellfillColor, outlineColor: selloutlineColor, outlineWidth: 0.5, text: "Monthly", textColor: selltextColor });
          }
        }

        if (this.finData.time_frame == 5) {
          var buy_array = this.BuyOverlayData['weekly'];
          for (let item of Object.values(buy_array)) {
            this.rectangleTool.addRectanglesFromData(item, { fillColor: buyfillColor, outlineColor: buyoutlineColor, outlineWidth: 0.5, text: "Weekly", textColor: buytextColor });
          }
          var sell_array = this.SellOverlayData['weekly'];
          for (let item of Object.values(sell_array)) {
            this.rectangleTool.addRectanglesFromData(item, { fillColor: sellfillColor, outlineColor: selloutlineColor, outlineWidth: 0.5, text: "Weekly", textColor: selltextColor });
          }
        }

        if (this.finData.time_frame == 6) {
          var buy_array = this.BuyOverlayData['daily'];
          for (let item of Object.values(buy_array)) {
            this.rectangleTool.addRectanglesFromData(item, { fillColor: buyfillColor, outlineColor: buyoutlineColor, outlineWidth: 0.5, text: "Daily", textColor: buytextColor });
          }
          var sell_array = this.SellOverlayData['daily'];
          for (let item of Object.values(sell_array)) {
            this.rectangleTool.addRectanglesFromData(item, { fillColor: sellfillColor, outlineColor: selloutlineColor, outlineWidth: 0.5, text: "Daily", textColor: selltextColor });
          }
        }
      }
      if (this.selectedOptions['overlap_analyze']) {

        if (this.finData.time_frame == 1) {
          var buy_array = this.BuyOverlayData['weekly'];
          for (let item of Object.values(buy_array)) {
            this.rectangleTool.addRectanglesFromData(item, { fillColor: buyfillColor, outlineColor: buyoutlineColor, outlineWidth: 0.5, text: "Weekly", textColor: buytextColor });
          }
          var sell_array = this.SellOverlayData['weekly'];
          for (let item of Object.values(sell_array)) {
            this.rectangleTool.addRectanglesFromData(item, { fillColor: sellfillColor, outlineColor: selloutlineColor, outlineWidth: 0.5, text: "Weekly", textColor: selltextColor });
          }
        }

        if (this.finData.time_frame == 2) {
          let buy_array = null;
          let sell_array = null;
          if (this.FullScreenModeValue == 'seventy_five') {
            console.log(
              '75 OVERLAY DATA BUY',
              this.BuyOverlayDataonSeventyFive
            );
            console.log(
              '75 OVERLAY DATA SELL',
              this.SellOverlayDataonSeventyFive
            );
            buy_array = this.BuyOverlayDataonSeventyFive['daily'];
            sell_array = this.SellOverlayDataonSeventyFive['daily'];
          } else {
            buy_array = this.BuyOverlayData['daily'];
            sell_array = this.SellOverlayData['daily'];
          }
          for (let item of Object.values(buy_array)) {
            this.rectangleTool.addRectanglesFromData(item, { fillColor: buyfillColor, outlineColor: buyoutlineColor, outlineWidth: 0.5, text: "Daily", textColor: buytextColor });
          }

          for (let item of Object.values(sell_array)) {
            this.rectangleTool.addRectanglesFromData(item, { fillColor: sellfillColor, outlineColor: selloutlineColor, outlineWidth: 0.5, text: "Daily", textColor: selltextColor });
          }
        }

        if (this.finData.time_frame == 3) {
          let buy_array = null;
          let sell_array = null;
          if (this.FullScreenModeValue == 'seventy_five') {
            buy_array = this.BuyOverlayDataonSeventyFive['seventy_five'];
            sell_array = this.SellOverlayDataonSeventyFive['seventy_five'];
          } else {
            buy_array = this.BuyOverlayData['sixty'];
            sell_array = this.SellOverlayData['daily'];
          }
          for (let item of Object.values(buy_array)) {
            this.rectangleTool.addRectanglesFromData(item, { fillColor: buyfillColor, outlineColor: buyoutlineColor, outlineWidth: 0.5, text: "Weekly", textColor: buytextColor });
          }

          for (let item of Object.values(sell_array)) {
            this.rectangleTool.addRectanglesFromData(item, { fillColor: sellfillColor, outlineColor: selloutlineColor, outlineWidth: 0.5, text: "Weekly", textColor: selltextColor });
          }
        }

        if (this.finData.time_frame == 4) {
          var buy_array = this.BuyOverlayData['weekly'];
          for (let item of Object.values(buy_array)) {
            this.rectangleTool.addRectanglesFromData(item, { fillColor: buyfillColor, outlineColor: buyoutlineColor, outlineWidth: 0.5, text: "Weekly", textColor: buytextColor });
          }
          var sell_array = this.SellOverlayData['weekly'];
          for (let item of Object.values(sell_array)) {
            this.rectangleTool.addRectanglesFromData(item, { fillColor: sellfillColor, outlineColor: selloutlineColor, outlineWidth: 0.5, text: "Weekly", textColor: selltextColor });
          }
        }

        if (this.finData.time_frame == 5) {
          var buy_array = this.BuyOverlayData['daily'];
          for (let item of Object.values(buy_array)) {
            this.rectangleTool.addRectanglesFromData(item, { fillColor: buyfillColor, outlineColor: buyoutlineColor, outlineWidth: 0.5, text: "Daily", textColor: buytextColor });
          }
          var sell_array = this.SellOverlayData['daily'];
          for (let item of Object.values(sell_array)) {
            this.rectangleTool.addRectanglesFromData(item, { fillColor: sellfillColor, outlineColor: selloutlineColor, outlineWidth: 0.5, text: "Daily", textColor: selltextColor });
          }
        }

        if (this.finData.time_frame == 6) {
          var buy_array = this.BuyOverlayData['one_twenty_five'];
          for (let item of Object.values(buy_array)) {
            this.rectangleTool.addRectanglesFromData(item, { fillColor: buyfillColor, outlineColor: buyoutlineColor, outlineWidth: 0.5, text: "Weekly", textColor: buytextColor });
          }
          var sell_array = this.SellOverlayData['one_twenty_five'];
          for (let item of Object.values(sell_array)) {
            this.rectangleTool.addRectanglesFromData(item, { fillColor: sellfillColor, outlineColor: selloutlineColor, outlineWidth: 0.5, text: "Weekly", textColor: selltextColor });
          }
        }
      }
      if (this.selectedOptions['optimized_buy_sell_zone']) {
        const fillColorBuy = 'rgba(0,255,0,0.2)';
        let buy_array = null;
        if (this.FullScreenModeValue == 'seventy_five') {
          buy_array = this.OptimizedBuySellZoneData75[this.FullScreenModeValue];
        } else {
          buy_array = this.OptimizedBuySellZoneData[this.FullScreenModeValue];
        }
        for (let item of Object.values(buy_array.Buy)) {
          this.rectangleTool.addRectanglesFromData(item,{fillColor: fillColorBuy});
        }
        const fillColorSell = 'rgba(255,51,51,0.2)';
        let sell_array = null;
        if (this.FullScreenModeValue == 'seventy_five') {
          sell_array =
            this.OptimizedBuySellZoneData75[this.FullScreenModeValue];
        } else {
          sell_array = this.OptimizedBuySellZoneData[this.FullScreenModeValue];
        }
        for (let item of Object.values(sell_array.Sell)) {
          this.rectangleTool.addRectanglesFromData(item, { fillColor: fillColorSell });
        }
      }
      if (this.selectedOptions['gap_up_down']) {
        const fillColor = 'rgba(183,199,21, 1)'; // Green for Gap Up
        const fillColor2 = 'rgba(189, 70, 25, 1)'; // Red for Gap Down

        const gapData = this.GapUpDownData[this.FullScreenModeValue];

        // Initialize marker arrays if needed
        const gapMarkers: any[] = [];

        // Gap Up
        for (let item of Object.values(gapData.gap_ups)) {
          const rect = item as { time: number; price: number }[];
          this.rectangleTool.addRectanglesFromData(item,{ fillColor: fillColor });

          // Add Up Arrow Marker
          gapMarkers.push({
            time: rect[0].time, // assuming 'time' exists in item
            position: 'belowBar',
            color: 'green',
            shape: 'arrowUp',
            text: 'Gap Up',
          });
        }

        // Gap Down
        for (let item of Object.values(gapData.gap_downs)) {
          const rect = item as { time: number; price: number }[];
          this.rectangleTool.addRectanglesFromData(item, { fillColor: fillColor2 });

          // Add Down Arrow Marker
          gapMarkers.push({
            time: rect[0].time,
            position: 'aboveBar',
            color: 'red',
            shape: 'arrowDown',
            text: 'Gap Down',
          });
        }
        gapMarkers.sort((a, b) => a.time - b.time);
        // Finally, set the markers on your series
        const allMarkers = [...gapMarkers, ...this.buyZoneMarkers];
        allMarkers.sort((a, b) => a.time - b.time);
        this.candlestickSeries.setMarkers(allMarkers);
      }
      if (this.selectedOptions['setup']) {
        this.dropdownShow = true;
      } else {
        this.dropdownShow = false;
        if (this.buylineSeries) {
          this.buylineSeries.setMarkers([]);
          this.buylineSeries.setData([]);
        }
        if (this.targetlineSeries) {
          this.targetlineSeries.setMarkers([]);
          this.targetlineSeries.setData([]);
        }
        if (this.stoplosslineSeries) {
          this.stoplosslineSeries.setMarkers([]);
          this.stoplosslineSeries.setData([]);
        }
      }
    } else {
      this.dropdownShow = false;
      this.candlestickSeries.setMarkers([]);
      this.rectangleTool.removeAllRectangles();
      if (this.buylineSeries) {
        this.buylineSeries.setMarkers([]);
        this.buylineSeries.setData([]);
      }
      if (this.targetlineSeries) {
        this.targetlineSeries.setMarkers([]);
        this.targetlineSeries.setData([]);
      }
      if (this.stoplosslineSeries) {
        this.stoplosslineSeries.setMarkers([]);
        this.stoplosslineSeries.setData([]);
      }
    }
  }

  checkOptions(): boolean {
    for (let key in this.selectedOptions) {
      if (this.selectedOptions[key]) {
        return false;
      }
    }
    return true;
  }

  radioClicked(key: any) {
    if (this.selectedOption === key) {
      this.candlestickSeries.setMarkers([]);
      this.rectangleTool.removeAllRectangles();
      this.selectedOption = null;
      return;
    } else {
      this.selectedOption = key;
    }
    this.key = key;
    if (this.buylineSeries) {
      this.buylineSeries.setMarkers([]);
      this.buylineSeries.setData([]);
    }

    if (this.targetlineSeries) {
      this.targetlineSeries.setMarkers([]);
      this.targetlineSeries.setData([]);
    }
    if (this.stoplosslineSeries) {
      this.stoplosslineSeries.setMarkers([]);
      this.stoplosslineSeries.setData([]);
    }
    this.candlestickSeries.setMarkers([]);
    this.rectangleTool.removeAllRectangles();

    if (key == 'base_candle') {
      this.ModelPrediction = '';
      this.dropdownShow = false;
      const fillColor = 'rgba(51,153,255,0.3)';
      var array = this.BaseCandleData[this.FullScreenModeValue];
      for (let item of Object.values(array)) {
        this.rectangleTool.addRectanglesFromData(item, fillColor);
      }
    }

    if (key == 'buy_sell_zone') {
      this.ModelPrediction = '';
      this.dropdownShow = false;
      const fillColorBuy = 'rgba(0,255,0,0.3)';
      var buy_array = this.BuyZoneData[this.FullScreenModeValue];
      for (let item of Object.values(buy_array)) {
        this.rectangleTool.addRectanglesFromData(item, fillColorBuy);
      }
      const fillColorSell = 'rgba(255,51,51,0.3)';
      var sell_array = this.SellZoneData[this.FullScreenModeValue];
      for (let item of Object.values(sell_array)) {
        this.rectangleTool.addRectanglesFromData(item, fillColorSell);
      }
      var gapData = this.GapData[this.FullScreenModeValue];
      // Gap Up
      // const gapupcolour = 'rgba(0, 0, 0, 0.5)'
      // for (let item of Object.values(gapData.GAP_UP)) {
      //   this.rectangleTool.addRectanglesFromData(item, gapupcolour);
      // }
      // // Gap Down
      // for (let item of Object.values(gapData.GAP_DOWN)) {
      //   this.rectangleTool.addRectanglesFromData(item, gapupcolour);
      // }
    }

    if (key == 'price_marker') {
      this.ModelPrediction = '';
      this.dropdownShow = false;
      const buyZoneMarkers = [];
      const buyZoneData = this.BuyZoneData[this.FullScreenModeValue];
      const sellZoneData = this.SellZoneData[this.FullScreenModeValue];
      for (const item of buyZoneData) {
        if (
          item[0] &&
          item[1] &&
          item[0].price !== undefined &&
          item[1].price !== undefined
        ) {
          buyZoneMarkers.push(
            {
              time: item[1].act,
              position: 'aboveBar',
              color: 'green',
              text: `H: ${item[1].price.toFixed(2)}`,
            },
            {
              time: item[0].act,
              position: 'belowBar',
              color: 'green',
              text: `L: ${item[0].price.toFixed(2)}`,
            }
          );
        } else {
          console.warn('Encountered an item with undefined price:', item);
        }
      }
      for (const item of sellZoneData) {
        if (
          item[0] &&
          item[1] &&
          item[0].price !== undefined &&
          item[1].price !== undefined
        ) {
          buyZoneMarkers.push(
            {
              time: item[1].act,
              position: 'aboveBar',
              color: 'green',
              text: `H: ${item[1].price.toFixed(2)}`,
            },
            {
              time: item[0].act,
              position: 'belowBar',
              color: 'green',
              text: `L: ${item[0].price.toFixed(2)}`,
            }
          );
        } else {
          console.warn('Encountered an item with undefined price:', item);
        }
      }
      buyZoneMarkers.sort((a, b) => a.time - b.time);
      this.buy_sell_zone();
      this.candlestickSeries.setMarkers(buyZoneMarkers);
    }

    if (key == 'bad_zone') {
      this.ModelPrediction = '';
      this.dropdownShow = false;
      this.BadZoneData = [];
      this.showmsg = 'Fetching Bad Zone Data !';
      this.spinner.show();
      this.apiService.GetBadZoneDataService(this.finData).subscribe((resp) => {
        this.BadZoneData = resp.response;
        let array = this.BadZoneData[this.FullScreenModeValue];
        const fillColor = 'rgba(249, 3, 3, 0.21)';
        for (let item of Object.values(array)) {
          this.rectangleTool.addRectanglesFromData(item, fillColor);
        }
        this.spinner.hide();
      });
    }

    if (key == 'setup') {
      this.dropdownShow = true;
    }
  }

  addEntryPriceLine(price: number, time: any, extendedtime: any) {
    let RRR = null;
    if (this.FullScreenModeValue == 'seventy_five') {
      if (this.SETUPTYPE == 'BUY') {
        RRR = this.setupDataonseventyfive['BUY_RRR'];
      } else {
        RRR = this.setupDataonseventyfive['SELL_RRR'];
      }
    } else {
      if (this.SETUPTYPE == 'BUY') {
        RRR = this.setupData['BUY_RRR'];
      } else {
        RRR = this.setupData['SELL_RRR'];
      }
    }

    this.buylineSeries = this.chart.addLineSeries({
      color: 'blue',
      lineWidth: 2,
      priceLineVisible: false,
      priceLineColor: 'blue',
      priceLineWidth: 2,
    });

    // Initial line setup
    const lineData = [
      { time: time, value: price },
      { time: time + extendedtime, value: price },
    ];

    this.buylineSeries.setData(lineData);
    this.buylineSeries.setMarkers([
      {
        time: time,
        position: 'aboveBar',
        color: 'blue',
        text: `R-R : ${RRR}`,
      },
      {
        time: time,
        position: 'aboveBar',
        color: 'blue',
        text: `Entry : ${price.toFixed(2)}`,
      },
    ]);

    // Enable dragging functionality
    this.EntryPrice = price;
    this.EntryTime = time;
    this.makeLineDraggable(price, time, extendedtime);
  }

  makeLineDraggable(
    initialPrice: number,
    initialStartTime: any,
    initialEndTime: any
  ) {
    let isDragging = false;
    let currentPrice = initialPrice;
    let currentStartTime = initialStartTime;
    let currentEndTime = initialEndTime;
    let clickOffsetPrice = 0;
    let clickOffsetTime = 0;
    const pixelThreshold = 6;
    const chartElement = document.getElementById('chart-container_new');

    const disableChartInteractions = () => {
      this.chart.applyOptions({ handleScroll: false, handleScale: false });
    };

    const enableChartInteractions = () => {
      this.chart.applyOptions({ handleScroll: true, handleScale: true });
    };

    chartElement?.addEventListener('mousedown', (event) => {
      const chartRect = chartElement.getBoundingClientRect();
      const yCoordinate = event.clientY - chartRect.top;
      const xCoordinate = event.clientX - chartRect.left;

      const mousePrice = this.buylineSeries.coordinateToPrice(yCoordinate);
      const mouseTime = this.chart.timeScale().coordinateToTime(xCoordinate);
      const lineY = this.buylineSeries.priceToCoordinate(currentPrice);

      if (
        Math.abs(yCoordinate - lineY) < pixelThreshold &&
        mouseTime >= currentStartTime &&
        mouseTime <= currentEndTime
      ) {
        isDragging = true;
        clickOffsetPrice = currentPrice - mousePrice;
        clickOffsetTime = currentStartTime - mouseTime;
        disableChartInteractions();
      }
    });

    chartElement?.addEventListener('mousemove', (event) => {
      if (!isDragging) return;

      const chartRect = chartElement.getBoundingClientRect();
      const yCoordinate = event.clientY - chartRect.top;
      const xCoordinate = event.clientX - chartRect.left;

      let newPrice =
        this.buylineSeries.coordinateToPrice(yCoordinate) + clickOffsetPrice;
      let newTime =
        this.chart.timeScale().coordinateToTime(xCoordinate) + clickOffsetTime;

      this.buylineSeries.setData([
        { time: currentStartTime, value: newPrice },
        { time: currentEndTime, value: newPrice },
      ]);

      this.buylineSeries.setMarkers([
        {
          time: newTime,
          position: 'aboveBar',
          color: 'green',
          text: `Entry: ${newPrice.toFixed(2)}`,
        },
      ]);

      this.updateModelPredictionFlag = true;
      currentPrice = newPrice;
      currentStartTime = newTime;
      this.EntryPrice = newPrice;
      this.EntryTime = newTime;
      let type = '';
      if (this.SETUPTYPE === 'BUY') {
        type = 'Buy';
      } else {
        type = 'Sell';
      }

      this.fincreateform.patchValue({
        order_type: type,
        entry_price: this.EntryPrice.toFixed(2),
        stoploss_price: this.StoplossPrice.toFixed(2),
        target_price: this.TargetPrice.toFixed(2),
      });

      const RRR = this.calculateRRR();
      this.updateMarkers(this.EntryPrice, RRR, this.EntryTime);
    });

    chartElement?.addEventListener('mouseup', () => {
      if (isDragging) {
        isDragging = false;
        enableChartInteractions();
      }
    });

    chartElement?.addEventListener('mouseleave', () => {
      if (isDragging) {
        isDragging = false;
        enableChartInteractions();
      }
    });
  }

  disableChartInteractions() {
    this.chart.applyOptions({
      handleScroll: false,
      handleScale: false,
      priceScale: {
        autoScale: false, // Lock auto-scaling
        lockScale: true, // Prevent scaling adjustments
      },
      crosshair: {
        mode: 0,
      },
    });
  }

  addTargetPriceLine(price: number, time: any, extendedtime: any) {
    this.targetlineSeries = this.chart.addLineSeries({
      color: 'green',
      lineWidth: 2,
      priceLineVisible: false,
      priceLineColor: 'green',
      priceLineWidth: 2,
    });

    this.targetlineSeries.setData([
      { time: time, value: price },
      { time: time + extendedtime, value: price },
    ]);

    this.targetlineSeries.setMarkers([
      {
        time: time,
        position: 'aboveBar',
        color: 'green',
        text: `Target : ${price.toFixed(2)}`,
      },
    ]);
    this.TargetPrice = price;
    // Make the target price line draggable
    this.makeTargetLineDraggable(price, time, extendedtime);
  }

  makeTargetLineDraggable(
    initialPrice: number,
    initialStartTime: any,
    initialEndTime: any
  ) {
    let isDragging = false;
    let currentPrice = initialPrice;
    let currentStartTime = initialStartTime;
    let currentEndTime = initialEndTime;
    let clickOffsetPrice = 0;
    let clickOffsetTime = 0;
    const pixelThreshold = 6; // Replacing price-based threshold with pixel-based
    const chartElement = document.getElementById('chart-container_new');

    const disableChartInteractions = () => {
      this.chart.applyOptions({
        handleScroll: false,
        handleScale: false,
        priceScale: {
          autoScale: false,
          mode: 1,
          lockScale: true,
        },
      });
    };

    const enableChartInteractions = () => {
      this.chart.applyOptions({
        handleScroll: true,
        handleScale: true,
        priceScale: {
          autoScale: true,
        },
      });
    };

    chartElement?.addEventListener('mousedown', (event) => {
      const chartRect = chartElement.getBoundingClientRect();
      const yCoordinate = event.clientY - chartRect.top;
      const xCoordinate = event.clientX - chartRect.left;

      const mousePrice = this.targetlineSeries.coordinateToPrice(yCoordinate);
      const mouseTime = this.chart.timeScale().coordinateToTime(xCoordinate);
      const lineY = this.targetlineSeries.priceToCoordinate(currentPrice);

      if (
        Math.abs(yCoordinate - lineY) < pixelThreshold &&
        mouseTime >= currentStartTime &&
        mouseTime <= currentEndTime
      ) {
        isDragging = true;
        clickOffsetPrice = currentPrice - mousePrice;
        clickOffsetTime = currentStartTime - mouseTime;
        disableChartInteractions();
      }
    });

    chartElement?.addEventListener('mousemove', (event) => {
      if (!isDragging) return;

      const chartRect = chartElement.getBoundingClientRect();
      const yCoordinate = event.clientY - chartRect.top;
      const xCoordinate = event.clientX - chartRect.left;

      const newPrice =
        this.targetlineSeries.coordinateToPrice(yCoordinate) + clickOffsetPrice;
      const newTime =
        this.chart.timeScale().coordinateToTime(xCoordinate) + clickOffsetTime;

      this.targetlineSeries.setData([
        { time: currentStartTime, value: newPrice },
        { time: currentEndTime, value: newPrice },
      ]);

      this.targetlineSeries.setMarkers([
        {
          time: newTime,
          position: 'aboveBar',
          color: 'green',
          text: `Target: ${newPrice.toFixed(2)}`,
        },
      ]);

      this.updateModelPredictionFlag = true;
      currentPrice = newPrice;
      currentStartTime = newTime;
      this.TargetPrice = newPrice;
      let type = '';
      if (this.SETUPTYPE === 'BUY') {
        type = 'Buy';
      } else {
        type = 'Sell';
      }

      this.fincreateform.patchValue({
        order_type: type,
        entry_price: this.EntryPrice.toFixed(2),
        stoploss_price: this.StoplossPrice.toFixed(2),
        target_price: this.TargetPrice.toFixed(2),
      });

      const RRR = this.calculateRRR();
      this.updateMarkers(this.EntryPrice, RRR, this.EntryTime);
    });

    chartElement?.addEventListener('mouseup', () => {
      if (isDragging) {
        isDragging = false;
        enableChartInteractions();
      }
    });

    chartElement?.addEventListener('mouseleave', () => {
      if (isDragging) {
        isDragging = false;
        enableChartInteractions();
      }
    });
  }

  addStoplossPriceLine(price: number, time: any, extendedtime: any) {
    this.stoplosslineSeries = this.chart.addLineSeries({
      color: 'red',
      lineWidth: 2,
      priceLineVisible: false,
      priceLineColor: 'red',
      priceLineWidth: 2,
    });

    this.stoplosslineSeries.setData([
      { time: time, value: price },
      { time: time + extendedtime, value: price },
    ]);

    this.stoplosslineSeries.setMarkers([
      {
        time: time,
        position: 'belowBar',
        color: 'red',
        text: `Stoploss : ${price.toFixed(2)}`,
      },
    ]);
    this.StoplossPrice = price;
    this.makeStoplossLineDraggable(price, time, extendedtime);
  }

  makeStoplossLineDraggable(
    initialPrice: number,
    initialStartTime: any,
    initialEndTime: any
  ) {
    let isDragging = false;
    let currentPrice = initialPrice;
    let currentStartTime = initialStartTime;
    let currentEndTime = initialEndTime;
    let clickOffsetPrice = 0;
    let clickOffsetTime = 0;
    const pixelThreshold = 6; // Pixel proximity
    const chartElement = document.getElementById('chart-container_new');

    // Disable chart panning, scrolling, and auto-scaling
    const disableChartInteractions = () => {
      this.chart.applyOptions({
        handleScroll: false,
        handleScale: false,
        priceScale: {
          autoScale: false,
          mode: 1,
          lockScale: true,
        },
      });
    };

    // Enable chart panning, scrolling, and auto-scaling
    const enableChartInteractions = () => {
      this.chart.applyOptions({
        handleScroll: true,
        handleScale: true,
        priceScale: {
          autoScale: true,
        },
      });
    };

    chartElement?.addEventListener('mousedown', (event) => {
      const chartRect = chartElement.getBoundingClientRect();
      const yCoordinate = event.clientY - chartRect.top;
      const xCoordinate = event.clientX - chartRect.left;

      const mousePrice = this.stoplosslineSeries.coordinateToPrice(yCoordinate);
      const mouseTime = this.chart.timeScale().coordinateToTime(xCoordinate);
      const lineY = this.stoplosslineSeries.priceToCoordinate(currentPrice);

      if (
        Math.abs(yCoordinate - lineY) < pixelThreshold &&
        mouseTime >= currentStartTime &&
        mouseTime <= currentEndTime
      ) {
        isDragging = true;
        clickOffsetPrice = currentPrice - mousePrice;
        clickOffsetTime = currentStartTime - mouseTime;
        disableChartInteractions();
      }
    });

    chartElement?.addEventListener('mousemove', (event) => {
      if (!isDragging) return;

      const chartRect = chartElement.getBoundingClientRect();
      const yCoordinate = event.clientY - chartRect.top;
      const xCoordinate = event.clientX - chartRect.left;

      const newPrice =
        this.stoplosslineSeries.coordinateToPrice(yCoordinate) +
        clickOffsetPrice;
      const newTime =
        this.chart.timeScale().coordinateToTime(xCoordinate) + clickOffsetTime;

      this.stoplosslineSeries.setData([
        { time: currentStartTime, value: newPrice },
        { time: currentEndTime, value: newPrice },
      ]);

      this.stoplosslineSeries.setMarkers([
        {
          time: newTime,
          position: 'belowBar',
          color: 'red',
          text: `Stoploss: ${newPrice.toFixed(2)}`,
        },
      ]);

      this.updateModelPredictionFlag = true;
      currentPrice = newPrice;
      currentStartTime = newTime;
      this.StoplossPrice = newPrice;
      let type = '';
      if (this.SETUPTYPE === 'BUY') {
        type = 'Buy';
      } else {
        type = 'Sell';
      }

      this.fincreateform.patchValue({
        order_type: type,
        entry_price: this.EntryPrice.toFixed(2),
        stoploss_price: this.StoplossPrice.toFixed(2),
        target_price: this.TargetPrice.toFixed(2),
      });

      const RRR = this.calculateRRR();
      this.updateMarkers(this.EntryPrice, RRR, this.EntryTime);
    });

    chartElement?.addEventListener('mouseup', () => {
      if (isDragging) {
        isDragging = false;
        enableChartInteractions();
      }
    });

    chartElement?.addEventListener('mouseleave', () => {
      if (isDragging) {
        isDragging = false;
        enableChartInteractions();
      }
    });
  }

  addPreviousHighPriceLine(key: any) {
    const previousHigh = this.PreviousHighData?.[key]?.previous_high;

    if (!previousHigh || previousHigh.price == null || isNaN(previousHigh.price)) {
      return; // bypass if not found / invalid
    }

    const myPriceLine = {
      price: previousHigh.price,
      color: '#f5d131',
      lineWidth: 2,
      lineStyle: 2,
      axisLabelVisible: true,
      title: 'Previous High',
    };

    this.candlestickSeries?.createPriceLine(myPriceLine);
  }

  calculateRRR(): number {
    // Calculate risk and reward using absolute values
    const risk = Math.abs(this.EntryPrice - this.StoplossPrice); // Calculate risk
    const reward = Math.abs(this.TargetPrice - this.EntryPrice); // Calculate reward

    // Check to avoid division by zero
    if (risk === 0) {
      return Infinity; // or return null or handle as needed
    }

    const riskToRewardRatio = reward / risk; // Calculate the risk-to-reward ratio
    return riskToRewardRatio; // Return the risk-to-reward ratio
  }

  updateMarkers(price: number, RRR: number, time: any) {
    this.buylineSeries.setMarkers([
      {
        time: time,
        position: 'aboveBar',
        color: 'blue',
        text: `R-R :  ${RRR.toFixed(2)}`,
      },
      {
        time: time,
        position: 'aboveBar',
        color: 'blue',
        text: `Entry : ${price.toFixed(2)}`,
      },
    ]);
  }

  buy_sell_zone() {
    const fillColorBuy = 'rgba(0, 96, 15, 0.8)';
    var buy_array = this.BuyZoneData[this.FullScreenModeValue];
    for (let item of Object.values(buy_array)) {
      this.rectangleTool.addRectanglesFromData(item, fillColorBuy);
    }
    const fillColorSell = 'rgba(255,51,51,0.3)';
    var sell_array = this.SellZoneData[this.FullScreenModeValue];
    for (let item of Object.values(sell_array)) {
      this.rectangleTool.addRectanglesFromData(item, fillColorSell);
    }
  }

  setupType(setupType: any) {
    this.entryEnabled = true;
    this.targetEnabled = true;
    this.stoplossEnabled = true;
    this.ViewSetUpAnywayFlag = false;
    this.isDisabled = false;
    this.TradeSetupReason = '';
    this.ModelPrediction = '';
    let RRR = null;
    this.removeAllEntry();
    this.CreateButtonFlag = true;
    this.createBtnFlgForMannualSetup = false;
    this.closeCreateOrderPanel();
    this.EntryPrice = '';
    this.StoplossPrice = '';
    this.EntryPrice = '';
    this.SETUPTYPE = setupType;
    this.updateModelPredictionFlag = false;
    if (setupType == 'BUY') {
      if (this.buylineSeries && !this.buylineSeries.isDisposed) {
        this.buylineSeries.setMarkers([]);
        this.buylineSeries.setData([]);
      }
      if (this.targetlineSeries) {
        this.targetlineSeries.setMarkers([]);
        this.targetlineSeries.setData([]);
      }
      if (this.stoplosslineSeries) {
        this.stoplosslineSeries.setMarkers([]);
        this.stoplosslineSeries.setData([]);
      }
      if (this.setupdataStatus == 'failed') {
        this.ModelPrediction = 'No Prediction Found !';
        this.showMarketAlert(this.ModelPrediction);
      } else {
        if (this.FullScreenModeValue == 'seventy_five') {
          this.BuySetupData = this.setupDataonseventyfive[setupType];
          console.log('BUY SETUP BUTTON ON 75', this.BuySetupData);
        } else {
          this.BuySetupData = this.setupData[setupType];
          console.log('BUY SETUP BUTTON ON OTHERS', this.BuySetupData);
        }
        if (this.BuySetupData == undefined) {
          this.ModelPrediction = 'NOT A GOOD CONDITION TO TRADE !';
          this.showMarketAlert(this.ModelPrediction);
        } else {
          if (this.FullScreenModeValue == 'seventy_five') {
            this.BuyTimestampData =
              this.setupDataonseventyfive['BUY_TIMESTAMPS'];
          } else {
            this.BuyTimestampData = this.setupData['BUY_TIMESTAMPS'];
          }
          if (this.FullScreenModeValue == 'seventy_five') {
            RRR = this.setupDataonseventyfive['BUY_RRR'];
          } else {
            RRR = this.setupData['BUY_RRR'];
          }
          if (RRR < 2.1) {
            this.ViewSetUpAnywayFlag = true;
            const Prediction = 'Not a good condition to trade.';
            const Message = 'RISK TO REWARD not satisfied!';
            this.showMarketAlert2(Prediction, Message);
          } else {
            this.ViewSetUpAnywayFlag = false;
            this.addEntryPriceLine(
              this.BuySetupData.entry_price,
              this.BuyTimestampData.entry_price_timestamp,
              this.BuyTimestampData.extend_timestamp
            );
            this.addTargetPriceLine(
              this.BuySetupData.target_price,
              this.BuyTimestampData.target_price_timestamp,
              this.BuyTimestampData.extend_timestamp
            );
            this.addStoplossPriceLine(
              this.BuySetupData.stop_loss,
              this.BuyTimestampData.entry_price_timestamp,
              this.BuyTimestampData.extend_timestamp
            );
            const data = {
              order_type: 'Buy',
              entry_price: this.BuySetupData.entry_price,
              target_price: this.BuySetupData.target_price,
              stoploss_price: this.BuySetupData.stop_loss,
              last_d_time: this.finData.last_d_time,
              time_frame: this.finData.time_frame,
              tick: this.finData.tick,
              country_id: localStorage.getItem('selectedCountryId'),
            };
            this.apiService
              .getModelPredictionService(data)
              .subscribe((resp) => {
                console.log('Model Prediction', resp);
                this.ModelPrediction =
                  'PROBABILITY OF TRADE : ' +
                  resp.msg.toUpperCase() +
                  ' = ' +
                  resp.response.probability +
                  ' %';
                this.SelectedPrediction = resp.msg;
                this.ViewSetUpAnywayFlag = false;
                this.SelectedProbability = resp.response.probability;
                this.showMarketAlert(this.ModelPrediction);
              });
          }
        }
      }
    }

    if (setupType == 'SELL') {
      if (this.buylineSeries) {
        this.buylineSeries.setMarkers([]);
        this.buylineSeries.setData([]);
      }
      if (this.targetlineSeries) {
        this.targetlineSeries.setMarkers([]);
        this.targetlineSeries.setData([]);
      }
      if (this.stoplosslineSeries) {
        this.stoplosslineSeries.setMarkers([]);
        this.stoplosslineSeries.setData([]);
      }
      if (this.setupdataStatus == 'failed') {
        this.ModelPrediction = 'No Prediction Found !';
        this.showMarketAlert(this.ModelPrediction);
      } else {
        if (this.FullScreenModeValue == 'seventy_five') {
          this.SellSetupData = this.setupDataonseventyfive[setupType];
          console.log('SELL SETUP BUTTON ON 75', this.SellSetupData);
        } else {
          this.SellSetupData = this.setupData[setupType];
          console.log('SELL SETUP BUTTON ON OTHERS', this.SellSetupData);
        }
        if (this.SellSetupData == undefined) {
          this.ModelPrediction = 'NOT A GOOD CONDITION TO TRADE !';
          this.showMarketAlert(this.ModelPrediction);
        } else {
          if (this.FullScreenModeValue == 'seventy_five') {
            console.log('FOR SELL', this.setupDataonseventyfive);
            this.SellTimestampData =
              this.setupDataonseventyfive['SELL_TIMESTAMPS'];
          } else {
            this.SellTimestampData = this.setupData['SELL_TIMESTAMPS'];
          }
          if (this.FullScreenModeValue == 'seventy_five') {
            RRR = this.setupDataonseventyfive['SELL_RRR'];
          } else {
            RRR = this.setupData['SELL_RRR'];
          }
          if (RRR < 1.6) {
            this.ViewSetUpAnywayFlag = true;
            const Prediction = 'Not a good condition to trade.';
            const Message = 'RISK TO REWARD not satisfied!';
            this.showMarketAlert2(Prediction, Message);
          } else {
            this.ViewSetUpAnywayFlag = false;
            this.addEntryPriceLine(
              this.SellSetupData.entry_price,
              this.SellTimestampData.entry_price_timestamp,
              this.SellTimestampData.extend_timestamp
            );
            this.addTargetPriceLine(
              this.SellSetupData.target_price,
              this.SellTimestampData.target_price_timestamp,
              this.SellTimestampData.extend_timestamp
            );
            this.addStoplossPriceLine(
              this.SellSetupData.stop_loss,
              this.SellTimestampData.entry_price_timestamp,
              this.SellTimestampData.extend_timestamp
            );
            const parsedTimeFrame = parseInt(this.finData.time_frame, 10);
            const data = {
              order_type: 'Buy',
              entry_price: this.SellSetupData.entry_price,
              target_price: this.SellSetupData.target_price,
              stoploss_price: this.SellSetupData.stop_loss,
              last_d_time: this.finData.last_d_time,
              time_frame: this.finData.time_frame,
              tick: this.finData.tick,
              country_id: localStorage.getItem('selectedCountryId'),
            };
            this.spinner.show();
            this.apiService
              .getModelPredictionService(data)
              .subscribe((resp) => {
                this.ModelPrediction =
                  'PROBABILITY OF TRADE : ' +
                  resp.msg.toUpperCase() +
                  ' = ' +
                  resp.response.probability +
                  ' %';
                this.SelectedPrediction = resp.msg;
                this.SelectedProbability = resp.response.probability;

                this.spinner.hide();
                this.showMarketAlert(this.ModelPrediction);
              });
          }
        }
      }
    }
  }

  showMarketAlert2(Prediction: any, TrandeMessage: any) {
    this.TradeSetupReason = TrandeMessage;
    this.ModelPrediction = Prediction;
    this.isNotificationVisible = true;
  }

  showMarketAlert(TrandeMessage: any) {
    // this.TradeSetupReason=TrandeMessage;
    this.isNotificationVisible = true;
  }

  closeNotification() {
    this.isNotificationVisible = false;
  }

  UpdatePrediction() {
    this.spinner.show();
    const data = {
      order_type: this.SETUPTYPE,
      entry_price: this.EntryPrice,
      target_price: this.TargetPrice,
      stoploss_price: this.StoplossPrice,
      last_d_time: this.finData.last_d_time,
      time_frame: this.finData.time_frame,
      mod_frame: 'daily',
      tick: this.finData.tick,
      country_id: localStorage.getItem('selectedCountryId'),
    };
    this.apiService.getModelPredictionService(data).subscribe((resp) => {
      this.ModelPrediction =
        'PROBABILITY OF TRADE : ' +
        resp.msg.toUpperCase() +
        ' = ' +
        resp.response.probability +
        ' %';
      this.SelectedPrediction = resp.msg;
      this.SelectedProbability = resp.response.probability;
      this.showMarketAlert(this.ModelPrediction);
      this.spinner.hide();
    });
  }

  enablePriceLine(type: string) {
    this.selectedType = type;
  }

  addPriceLine(type: string, price: number) {
    const priceLineOptions = {
      price: price,
      color: type === 'entry' ? 'blue' : type === 'target' ? 'green' : 'red',
      lineWidth: 2,
      lineStyle: LineStyle.Solid,
      axisLabelVisible: true,
      title: type.charAt(0).toUpperCase() + type.slice(1),
    };

    this.candlestickSeries.createPriceLine(priceLineOptions);
  }

  onSearchInputChange(value: string): void {
    this.searchSubject.next(value);
  }

  search(value: string) {
    if (value.trim() !== '') {
      this.apiService.SearchStockonKey(value).subscribe((resp) => {
        this.filteredCompanies = resp.response || [];
        this.highlightedIndex = -1; // Reset highlight when list changes
      });
    } else {
      this.filteredCompanies = [];
    }
  }

  onSelectCompany(company: any) {
    this.handleDroppedStock(company);
    this.filteredCompanies = [];
  }

  onKeyDown(event: KeyboardEvent) {
    if (this.filteredCompanies.length > 0) {
      if (event.key === 'ArrowDown') {
        // Navigate down the list
        this.highlightedIndex =
          (this.highlightedIndex + 1) % this.filteredCompanies.length;
        event.preventDefault(); // Prevent default scrolling
      } else if (event.key === 'ArrowUp') {
        // Navigate up the list
        this.highlightedIndex =
          (this.highlightedIndex - 1 + this.filteredCompanies.length) %
          this.filteredCompanies.length;
        event.preventDefault(); // Prevent default scrolling
      } else if (event.key === 'Enter') {
        // Select the highlighted company
        if (this.highlightedIndex >= 0) {
          this.onSelectCompany(this.filteredCompanies[this.highlightedIndex]);
        }
      }
    }
  }

  onDragStart(event: DragEvent, stockId: any) {
    this.draggedStock = stockId;
    event.dataTransfer?.setData('text', stockId.toString());
  }

  onDragOver(event: DragEvent) {
    event.preventDefault();
  }

  onDrop(event: DragEvent) {
    event.preventDefault();
    const droppedStock = event.dataTransfer?.getData('text');
    this.handleDroppedStock(droppedStock);
  }

  handleDroppedStock(stock: any) {
    this.finform.patchValue({
      tick: stock,
    });
    this.finData.tick = stock;
    this.GetDraggedData();
  }

  GetDraggedData() {
    this.Counter = 0;
    // this.disconnectWebSocket()
    this.CloseFullModal();
    this.TrackFullScreenMode = true;
    this.showmsg = 'Analyzing Data and Generating Your Graph... Please Wait.';
    this.submitted = true;
    this.finform.markAllAsTouched();
    if (this.finform.invalid) {
      return;
    }
    if (this.finform.valid) {
      this.clearChartDiv();
      this.spinner.show();
      const promises = [
        this.previousHighService(),
        this.GetBaseCandleData(),
        this.GetBuyZoneData(),
        this.GetSellZoneData(),
        this.OverLayFetching(),
        this.GetAllZones(),
        this.GetQualifiedZones(),
        this.GetSetUpData(),
      ];
      if (this.finData.time_frame === '1') {
        this.layoutFlagfirst = true;
        this.layoutFlagsecond = false;
        this.layoutFlagthird = false;
      } else if (this.finData.time_frame === '2') {
        promises.push(
          this.GetSetUpDataonSeventy_five(),
          this.GetQualifiedZonesonSeventy_five(),
          this.OverLayFetchingonSeventyFive()
        );
        this.layoutFlagfirst = false;
        this.layoutFlagsecond = true;
        this.layoutFlagthird = false;
      } else if (this.finData.time_frame === '3') {
        promises.push(
          this.GetSetUpDataonSeventy_five(),
          this.GetQualifiedZonesonSeventy_five(),
          this.OverLayFetchingonSeventyFive()
        );
        this.layoutFlagfirst = false;
        this.layoutFlagsecond = false;
        this.layoutFlagthird = true;
      }
      // Execute all promises and fetch candle data after they are complete
      Promise.all(promises)
        .then(() => {
          return this.apiService.fetchCandleData(this.finData).toPromise();
        })
        .then((resp) => {
          this.ChartRESPONSE = resp.response;
          this.SelectedStockName = this.finData.tick;
          this.cdRef.detectChanges();
          this.ngAfterViewInit();
          const data = this.ChartRESPONSE[this.FullScreenModeValue];
          this.LoadChart(data, 'chart-container_new');
        })
        .catch((error) => {
          console.error('Error occurred during API calls', error);
        })
        .finally(() => {
          // this.ngAfterViewInit();
          // this.spinner.hide();
        });
      // Promise.all(promises).then(() => {
      //   this.apiService.fetchCandleData(this.finData).subscribe(resp => {
      //     this.ChartRESPONSE = resp.response;
      //     this.SelectedStockName = this.finData.tick;
      //     this.cdRef.detectChanges();
      //     this.ngAfterViewInit()
      //     const data = this.ChartRESPONSE[this.FullScreenModeValue];
      //     this.LoadChart(data,"chart-container_new")
      //     this.spinner.hide();
      //   });

      // }).catch((error) => {
      //   console.error("Error occurred during API calls", error);
      //   this.spinner.hide();
      // });
    }
  }

  gotoStockMgmt() {
    this.router.navigate(['/stock-management']);
  }

  updateCandleData() {
    this.spinner.show();
    this.apiService
      .updateCandleDataService(this.UpdateCnadleStockId)
      .subscribe((resp) => {
        if (resp.msg == 'success') {
          this.toastr.success('Candle Data Updated !');
          this.spinner.hide();
        } else {
          this.toastr.error('Updateion Failed !');
          this.spinner.hide();
        }
      });
  }

  showContextMenu(x: number, y: number): void {
    const menu = document.getElementById('customContextMenu');
    if (menu) {
      menu.style.display = 'block';
      menu.style.top = `${y}px`;
      menu.style.left = `${x}px`;
    }
  }

  hideContextMenu(): void {
    const menu = document.getElementById('customContextMenu');
    if (menu) {
      menu.style.display = 'none';
    }
  }

  showAlert(): void {
    if (this.finData?.tick) {
      const SymbolData = this.finform.value;
      const tickUpper = SymbolData.tick.kite_symbol; //nabonita
      this.alertForm.get('stock_symbol')?.patchValue(tickUpper);
    }

    this.alertForm.get('timeframe')?.patchValue(this.TimeFrame); //nabonita

    this.modalalert.show();
    this.hideContextMenu();
  }

  onSubmitSetAlert() {
    this.submitStock = true;
    this.alertForm.markAllAsTouched();
    if (this.alertForm.invalid) {
      this.toastr.error('This fields are required !');
      return;
    } else {
      this.spinner.show();
      const setAlertData = this.alertForm.value;
      this.apiService
        .onSubmitSetAlertService(setAlertData)
        .subscribe((resp) => {
          if (resp.msg == 'success') {
            this.spinner.hide();
            this.toastr.success(resp.response.message);
            this.submitStock = false;
            this.alertForm.get('trigger_price')?.reset();
            this.alertForm.get('target_percentage')?.reset();
            this.alertForm.get('threshold')?.reset();
            this.alertForm.get('price_range_min')?.reset();
            this.alertForm.get('price_range_max')?.reset();
            this.alertForm.get('cooldown_minutes')?.reset();
            this.alertForm.get('note')?.reset();
            this.alertForm.get('alert_type')?.setValue('');
            this.getAllSetAlerts();
          } else {
            this.spinner.hide();
            return;
          }
        });
    }
  }

  getAllSetAlerts(highlight: boolean = false) {
    // this.spinner.show();

    const payload = {
      country_id: localStorage.getItem('selectedCountryId'),
      user_id: this.userId,
      page_no:
        this.currentPage != null ? this.currentPage.toString() : undefined,
      limit: this.pageSize,
      stock_tick: this.searchText,
      start_date: this.StartDate,
      end_date: this.EndDate,
    };
    console.log('alert payload', payload);
    this.apiService.getViewAlertListService(payload).subscribe((resp) => {
      console.log('alert resp', resp);
      // this.spinner.hide();
      if (resp.msg === 'success') {
        const parsedData = typeof resp === 'string' ? JSON.parse(resp) : resp;
        this.allSetAlerts = resp.response.alerts || [];
        this.TotalCount = resp.response.total_count;
        console.log('alertssss', this.allSetAlerts);

        // Highlight if search matches
        if (highlight && this.searchText) {
          const lowerSearch = this.searchText.trim().toLowerCase();

          const matches = this.allSetAlerts.filter(
            (item: { stock_symbol: string }) =>
              item.stock_symbol?.toLowerCase().includes(lowerSearch)
          );

          this.MatchedCount = matches.length;
          this.highlightedStockNames = matches.map(
            (item: { stock_symbol: any }) => item.stock_symbol
          );

          if (matches.length > 0) {
            const firstMatchName = matches[0].stock_symbol;
            this.currentPage = resp.response.page_no;
            setTimeout(() => {
              const target = this.stockCells.find(
                (cell: {
                  nativeElement: { getAttribute: (arg0: string) => string };
                }) =>
                  cell.nativeElement
                    .getAttribute('data-stock')
                    ?.toLowerCase() === firstMatchName.toLowerCase()
              );

              if (target) {
                target.nativeElement.scrollIntoView({
                  behavior: 'smooth',
                  block: 'center',
                });
              }
            });
          } else {
            this.highlightedStockNames = [];
          }
        } else {
          this.highlightedStockNames = [];
          this.MatchedCount = 0;
        }
      } else {
        this.toastr.error('Failed to fetch alerts');
        this.MatchedCount = 0;
        this.TotalCount = 0;
      }
    });
  }
  deleteAlert(alertid: any) {
    const confirmation = window.confirm('Are you sure , you want to delete?');
    if (confirmation) {
      this.spinner.show();
      this.apiService.deleteAlertService(alertid).subscribe((data) => {
        this.showmsg = data.msg;
        if (this.showmsg == 'success') {
          this.spinner.hide();
          this.toastr.success('Alert Deleted Successfully');
          this.getAllSetAlerts();
        } else {
          this.spinner.hide();
          this.toastr.error('Alert Deletion Failed');
        }
      });
    }
  }

  PrepDebounce() {
    this.searchSubject.pipe(debounceTime(400)).subscribe((value: string) => {
      const trimmed = value.trim().toLowerCase();
      this.searchText = trimmed;
      this.currentPage = null;
      this.getAllSetAlerts(true);
    });
  }

  Search() {
    this.currentPage = 1; // Reset to first page on new search
    this.StartDate = this.selectedDateRange.startDate.format('YYYY-MM-DD');
    this.EndDate = this.selectedDateRange.endDate.format('YYYY-MM-DD');
    this.getAllSetAlerts(true);
  }

  goToNextPage() {
    const totalPages = this.getTotalPages();
    if (this.currentPage < totalPages) {
      this.currentPage++;
      this.getAllSetAlerts(true);
    }
  }

  goToPreviousPage() {
    this.currentPage--;
    this.getAllSetAlerts(true);
  }

  isHighlighted(stockName: string): boolean {
    return this.highlightedStockNames.some(
      (name) => name.toLowerCase() === stockName.toLowerCase()
    );
  }

  getPageNumbers(): number[] {
    const totalPages = this.getTotalPages();
    const currentPage = this.getCurrentPage();

    const maxVisible = 5;
    let startPage = Math.max(currentPage - Math.floor(maxVisible / 2), 1);
    let endPage = Math.min(startPage + maxVisible - 1, totalPages);

    if (endPage - startPage < maxVisible - 1) {
      startPage = Math.max(endPage - maxVisible + 1, 1);
    }

    const pageNumbers: number[] = [];
    for (let i = startPage; i <= endPage; i++) {
      pageNumbers.push(i);
    }

    return pageNumbers;
  }

  onSearchInput(value: string) {
    this.searchSubject.next(value);
  }

  goToPage(page: number) {
    this.currentPage = page;
    this.getAllSetAlerts(true);
  }

  onPageSizeChange() {
    this.currentPage = 1;
    this.getAllSetAlerts(true);
  }

  getTotalPages(): number {
    return Math.ceil(this.TotalCount / this.pageSize);
  }

  getCurrentPage(): number {
    return this.currentPage;
  }

  enableLinePlacement(mode: 'entry' | 'target' | 'stoploss') {
    // Block placing target/stoploss before entry exists
    if ((mode === 'target' || mode === 'stoploss') && !this.entryLine) {
      // use your global swal if you like
      alert('Place Entry first');
      return; // do not enter placement mode
    }
    this.checkboxClicked('setup');
    this.chart.priceScale('right').applyOptions({
      autoScale: false,
      scaleMargins: this.DEFAULT_SCALE_MARGINS, // keep your margins
    });

    // Cleanup old listeners
    if (this.boundShowPreviewLine) {
      this.chart.unsubscribeCrosshairMove(this.boundShowPreviewLine);
    }
    if (this.boundFixLineAtPrice) {
      this.chart.unsubscribeClick(this.boundFixLineAtPrice);
    }

    // Remove old preview
    if (this.previewLine) {
      this.chart.removeSeries(this.previewLine);
      this.previewLine = null;
    }

    this.placementMode = mode;

    // New preview line
    this.previewLine = this.chart.addLineSeries({
      color: this.getColorForMode(mode),
      lineWidth: 1,
      priceLineVisible: false,
      crossHairMarkerVisible: false,
    });

    // Bind handlers once per placement
    this.boundShowPreviewLine = this.showPreviewLine.bind(this);
    this.boundFixLineAtPrice = this.fixLineAtPrice.bind(this);

    // Subscribe
    this.chart.subscribeCrosshairMove(this.boundShowPreviewLine);
    this.chart.subscribeClick(this.boundFixLineAtPrice);
  }

  showPreviewLine(param: any) {
    if (!param?.point || !this.previewLine || this.placementMode === 'none')
      return;

    // get a safe time; prefer param.time (bar time); fallback to x->time
    let timeStart: any =
      param.time ?? this.chart.timeScale().coordinateToTime(param.point.x);
    if (!timeStart) return;

    // keep using your existing future time logic (same type as timeStart)
    const futureTime: any =
      typeof timeStart === 'number'
        ? Math.floor(Date.now() / 1000) + this.FUTURE_SECONDS
        : (() => {
          const d = new Date(
            Date.UTC(timeStart.year, timeStart.month - 1, timeStart.day)
          );
          d.setUTCDate(d.getUTCDate() + 7);
          return {
            year: d.getUTCFullYear(),
            month: d.getUTCMonth() + 1,
            day: d.getUTCDate(),
          };
        })();

    let price = this.candlestickSeries.coordinateToPrice(param.point.y);
    if (price === undefined) return;
    price = Math.max(this.MIN_PRICE, price);

    // 1) update preview line FIRST
    this.previewLine.setData([{ time: timeStart, value: price }]);
    const { ok, msg } = this.validatePlacement(
      this.placementMode as any,
      price
    );
    if (!ok && msg) {
      this.previewLine.setMarkers([
        {
          time: timeStart,
          position: 'aboveBar',
          color: 'white',
          shape: 'arrowUp',
          text: msg,
        },
      ]);
      this.previewLine.applyOptions({ color: 'white' });
    } else {
      this.previewLine.setMarkers([]);
      this.previewLine.applyOptions({
        color: this.getColorForMode(this.placementMode as any),
      });
    }
  }

  capitalize(text: string) {
    return text.charAt(0).toUpperCase() + text.slice(1);
  }

  getColorForMode(mode: 'entry' | 'target' | 'stoploss' | 'none') {
    switch (mode) {
      case 'entry':
        return 'blue';
      case 'target':
        return 'green';
      case 'stoploss':
        return 'red';
      default:
        return 'gray'; // fallback color for 'none'
    }
  }

  onChartClick(param: any) {
    if (!param?.point) return;

    const clickedY = param.point.y;
    const pixelThreshold = 6;

    let closestLine: any = null;
    let minPixelDiff = Number.MAX_VALUE;

    for (const line of this.horizontalLines) {
      const lineY = this.candlestickSeries.priceToCoordinate(line.price);
      if (lineY === null) continue;

      const pixelDiff = Math.abs(lineY - clickedY);
      if (pixelDiff < minPixelDiff && pixelDiff <= pixelThreshold) {
        closestLine = line;
        minPixelDiff = pixelDiff;
      }
    }

    // Deselect previous
    this.horizontalLines.forEach((line) => {
      if (line === this.selectedLine) {
        line.series.applyOptions({ lineWidth: 2, lineStyle: 0 });
        line.selected = false;
      }
    });

    if (closestLine) {
      this.selectedLine = closestLine;
      closestLine.series.applyOptions({
        lineWidth: 3,
        lineStyle: 1,
      });
      closestLine.selected = true;
    } else {
      this.selectedLine = null;
    }
  }

  fixLineAtPrice(param: any) {
    this.createBtnFlgForMannualSetup = true;
    this.CreateButtonFlag = false;
    if (!param.point || !param.time || this.placementMode === 'none') return;

    let price = this.candlestickSeries.coordinateToPrice(param.point.y);
    if (price === undefined) return;

    // clamp to avoid negatives at placement
    price = Math.max(this.MIN_PRICE, price);

    // final validation BEFORE commit
    const validation = this.validatePlacement(this.placementMode as any, price);
    if (!validation.ok) {
      // keep preview mode active and show message above line
      this.previewMessage(
        validation.msg || 'Invalid placement',
        param.time,
        'aboveBar'
      );
      // optional toast:
      alert(validation.msg || 'Invalid placement');
      return; // DO NOT place the line
    }

    const color = this.getColorForMode(this.placementMode);
    const currentMode = this.placementMode;

    // Unsubscribe preview listeners
    if (this.boundShowPreviewLine)
      this.chart.unsubscribeCrosshairMove(this.boundShowPreviewLine);
    if (this.boundFixLineAtPrice)
      this.chart.unsubscribeClick(this.boundFixLineAtPrice);

    // Remove preview
    if (this.previewLine) {
      this.chart.removeSeries(this.previewLine);
      this.previewLine = null;
    }
    // Reset placement mode AFTER capturing values
    this.placementMode = 'none';
    const timeStart = param.time;

    // ---------- NEW: prevent viewport shift ----------
    const ts = this.chart.timeScale();
    const prevRange = ts.getVisibleRange(); // save current viewport
    const FIVE_YEARS = 5 * 365 * 24 * 60 * 60;

    const futureTime = Math.floor(Date.now() / 1000) + FIVE_YEARS;
    // -------------------------------------------------

    const fixedLine = this.chart.addLineSeries({
      color,
      lineWidth: 2,
      priceLineVisible: false,
      crossHairMarkerVisible: false,
    });

    const prev = ts.getVisibleLogicalRange?.() ?? ts.getVisibleRange?.();

    // your original setData (can still use futureTime)
    fixedLine.setData([
      { time: timeStart, value: price },
      { time: futureTime, value: price },
    ]);

    // restore viewport so the chart doesn't shift
    if (prev?.from !== undefined) {
      // prefer logical range if available
      if (
        ts.setVisibleLogicalRange &&
        prev.from !== undefined &&
        prev.to !== undefined
      ) {
        ts.setVisibleLogicalRange(prev as any);
      } else if (ts.setVisibleRange) {
        ts.setVisibleRange(prev as any);
      }
    }

    fixedLine.setMarkers([
      {
        time: timeStart,
        position: currentMode === 'stoploss' ? 'belowBar' : 'aboveBar',
        color,
        shape: 'arrowUp',
        text: `${this.capitalize(currentMode)} : ${price.toFixed(2)}`,
      },
    ]);

    const lineObj: any = {
      type: currentMode,
      price,
      series: fixedLine,
      startTime: timeStart,
      endTime: futureTime,
    };
    this.horizontalLines.push(lineObj);

    // disable the respective button
    if (currentMode === 'entry') this.entryEnabled = false;
    if (currentMode === 'target') this.targetEnabled = false;
    if (currentMode === 'stoploss') this.stoplossEnabled = false;
    // Enable dragging for this line
    this.makeManualLineDraggable(lineObj, timeStart, futureTime);

    // Update form (safe formatting)
    const fmt = (v: number) => (typeof v === 'number' ? v.toFixed(2) : '');
    switch (currentMode) {
      case 'entry':
        this.EntryPrice = price;
        break;
      case 'stoploss':
        this.StoplossPrice = price;
        break;
      case 'target':
        this.TargetPrice = price;
        break;
    }
    this.fincreateformForMannualSetup.patchValue({
      entry_price: fmt(this.EntryPrice),
      stoploss_price: fmt(this.StoplossPrice),
      target_price: fmt(this.TargetPrice),
    });

    this.updateEntryLineMarker();

    // ✅ Re-apply your desired margins and restore interactions
    this.chart.priceScale('right').applyOptions({
      autoScale: true,
      scaleMargins: this.DEFAULT_SCALE_MARGINS,
    });
    this.chart.applyOptions({ handleScroll: true, handleScale: true });
  }

  makeManualLineDraggable(
    lineObj: any,
    initialStartTime: any,
    initialEndTime: any
  ) {
    const el = document.getElementById('chart-container_new');
    if (!el) return;

    // ---- time helpers (unix vs BusinessDay) ----
    const isBusiness = (t: any) => typeof t === 'object' && t && 'year' in t;
    const toUnix = (t: any) =>
      typeof t === 'number' ? t : Date.UTC(t.year, t.month - 1, t.day) / 1000;
    const toBusiness = (sec: number) => {
      const d = new Date(sec * 1000);
      return {
        year: d.getUTCFullYear(),
        month: d.getUTCMonth() + 1,
        day: d.getUTCDate(),
      };
    };
    const asLike = (sec: number, like: any) =>
      isBusiness(like) ? toBusiness(sec) : sec;
    const rightEdgeLike = (like: any): any => {
      const vr = this.chart.timeScale().getVisibleRange?.();
      if (!vr?.to) return like;
      return isBusiness(like)
        ? isBusiness(vr.to)
          ? vr.to
          : toBusiness(toUnix(vr.to))
        : typeof vr.to === 'number'
          ? vr.to
          : toUnix(vr.to);
    };

    // set initial times on the object
    lineObj.startTime = initialStartTime;
    lineObj.endTime = initialEndTime;

    if (!this._dragListenersAttached) {
      let isDragging = false;
      let dragLine: any = null;

      // offsets so the line doesn't snap on grab
      let offsetPrice = 0;
      let offsetTimeSec = 0;

      // snapshot to REVERT TO (state before drag)
      let orig = { price: 0, startTime: null as any, endTime: null as any };

      const pixelThreshold = 8;

      const disableChart = () => {
        this.chart.applyOptions({ handleScroll: false, handleScale: false });
        this.chart.priceScale('right').applyOptions({
          autoScale: false,
          scaleMargins: this.DEFAULT_SCALE_MARGINS,
        });
      };
      const enableChart = () => {
        this.chart.applyOptions({ handleScroll: true, handleScale: true });
        this.chart.priceScale('right').applyOptions({
          autoScale: true,
          scaleMargins: this.DEFAULT_SCALE_MARGINS,
        });
      };

      el.addEventListener('mousedown', (ev: MouseEvent) => {
        const r = el.getBoundingClientRect();
        const y = ev.clientY - r.top;
        const x = ev.clientX - r.left;

        // find the grabbed line by y-distance
        for (const line of this.horizontalLines) {
          const ly = this.candlestickSeries.priceToCoordinate(line.price);
          if (ly == null) continue;
          if (Math.abs(y - ly) <= pixelThreshold) {
            isDragging = true;
            dragLine = line;

            // snapshot ORIGINAL state to revert to
            orig = {
              price: line.price,
              startTime: line.startTime,
              endTime: line.endTime,
            };

            // offsets
            const priceAtCursor = this.candlestickSeries.coordinateToPrice(y);
            offsetPrice = line.price - (priceAtCursor ?? line.price);

            let tRaw: any = this.chart.timeScale().coordinateToTime(x);
            if (!tRaw) {
              const vr = this.chart.timeScale().getVisibleRange?.();
              if (!vr?.to) return;
              tRaw = vr.to;
            }
            const tUnix = toUnix(tRaw);
            offsetTimeSec = toUnix(line.startTime) - tUnix;

            disableChart();
            break;
          }
        }
      });

      el.addEventListener('mousemove', (ev: MouseEvent) => {
        if (!isDragging || !dragLine) return;

        const r = el.getBoundingClientRect();
        const y = ev.clientY - r.top;
        const x = ev.clientX - r.left;

        // proposed price
        let p = this.candlestickSeries.coordinateToPrice(y);
        if (p === undefined) return;
        const proposedPrice = Math.max(this.MIN_PRICE, p + offsetPrice);

        // proposed start time
        let tRaw: any = this.chart.timeScale().coordinateToTime(x);
        if (!tRaw) {
          const vr = this.chart.timeScale().getVisibleRange?.();
          if (!vr?.to) return;
          tRaw = vr.to;
        }
        const newStartUnix = toUnix(tRaw) + offsetTimeSec;
        const newStartTime = asLike(newStartUnix, dragLine.startTime);
        const newEndTime = rightEdgeLike(newStartTime);

        // draw VISUALLY only (no state commit here)
        dragLine.series.setData([
          { time: newStartTime, value: proposedPrice },
          { time: newEndTime, value: proposedPrice },
        ]);

        // optional visual validation (uses your own validatePlacement)
        const { ok, msg } = this.validatePlacement(
          dragLine.type as any,
          proposedPrice
        );
        if (!ok) {
          dragLine.series.applyOptions({ color: 'gray', lineWidth: 1 });
          dragLine.series.setMarkers([
            {
              time: newStartTime,
              position: dragLine.type === 'stoploss' ? 'belowBar' : 'aboveBar',
              color: 'gray',
              shape: 'arrowUp',
              text: msg || 'Invalid',
            },
          ]);
        } else {
          dragLine.series.applyOptions({
            color: this.getColorForMode(dragLine.type),
            lineWidth: 2,
          });
          dragLine.series.setMarkers([
            {
              time: newStartTime,
              position: dragLine.type === 'stoploss' ? 'belowBar' : 'aboveBar',
              color: this.getColorForMode(dragLine.type),
              shape: 'arrowUp',
              text: `${this.capitalize(dragLine.type)}: ${proposedPrice.toFixed(
                2
              )}`,
            },
          ]);

          // ✅ VALID WHILE DRAGGING: commit to state + sync form + RR
          dragLine.price = proposedPrice;
          dragLine.startTime = newStartTime;
          dragLine.endTime = newEndTime;

          if (dragLine.type === 'entry') this.EntryPrice = proposedPrice;
          if (dragLine.type === 'stoploss') this.StoplossPrice = proposedPrice;
          if (dragLine.type === 'target') this.TargetPrice = proposedPrice;

          this.fincreateformForMannualSetup.patchValue({
            entry_price:
              typeof this.EntryPrice === 'number'
                ? this.EntryPrice.toFixed(2)
                : '',
            stoploss_price:
              typeof this.StoplossPrice === 'number'
                ? this.StoplossPrice.toFixed(2)
                : '',
            target_price:
              typeof this.TargetPrice === 'number'
                ? this.TargetPrice.toFixed(2)
                : '',
          });

          this.updateEntryLineMarker?.();
        }
      });

      const stopDrag = (ev?: MouseEvent) => {
        if (!isDragging || !dragLine) return;

        const r = el.getBoundingClientRect();
        const x = ev ? ev.clientX - r.left : 0;
        const y = ev ? ev.clientY - r.top : 0;

        // compute final proposed position
        let p = this.candlestickSeries.coordinateToPrice(y);
        if (p === undefined) p = dragLine.price; // fallback if outside
        const finalPrice = Math.max(this.MIN_PRICE, p + offsetPrice);

        let tRaw: any = this.chart.timeScale().coordinateToTime(x);
        if (!tRaw) {
          const vr = this.chart.timeScale().getVisibleRange?.();
          tRaw = vr?.to ?? dragLine.startTime;
        }
        const newStartUnix = toUnix(tRaw) + offsetTimeSec;
        const newStartTime = asLike(newStartUnix, dragLine.startTime);
        const newEndTime = rightEdgeLike(newStartTime);

        // validate with YOUR function
        const { ok, msg } = this.validatePlacement(
          dragLine.type as any,
          finalPrice
        );

        if (!ok) {
          // ❌ INVALID → revert to ORIGINAL snapshot
          const revertedEndTime = rightEdgeLike(orig.startTime); // keep right edge glued to viewport
          dragLine.series.setData([
            { time: orig.startTime, value: orig.price },
            { time: revertedEndTime, value: orig.price },
          ]);
          dragLine.series.setMarkers([
            {
              time: orig.startTime,
              position: dragLine.type === 'stoploss' ? 'belowBar' : 'aboveBar',
              color: this.getColorForMode(dragLine.type),
              shape: 'arrowUp',
              text: `${this.capitalize(dragLine.type)}: ${orig.price.toFixed(
                2
              )}`,
            },
          ]);
          dragLine.series.applyOptions({
            color: this.getColorForMode(dragLine.type),
            lineWidth: 2,
          });

          // restore state to orig (align end to current right edge)
          dragLine.price = orig.price;
          dragLine.startTime = orig.startTime;
          dragLine.endTime = revertedEndTime;

          // 🔁 SYNC FORM to reverted values (derive from current lines)
          const entry = this.horizontalLines.find((l) => l.type === 'entry');
          const sl = this.horizontalLines.find((l) => l.type === 'stoploss');
          const target = this.horizontalLines.find((l) => l.type === 'target');

          this.EntryPrice = entry?.price;
          this.StoplossPrice = sl?.price;
          this.TargetPrice = target?.price;

          this.fincreateformForMannualSetup.patchValue({
            entry_price:
              typeof this.EntryPrice === 'number'
                ? this.EntryPrice.toFixed(2)
                : '',
            stoploss_price:
              typeof this.StoplossPrice === 'number'
                ? this.StoplossPrice.toFixed(2)
                : '',
            target_price:
              typeof this.TargetPrice === 'number'
                ? this.TargetPrice.toFixed(2)
                : '',
          });

          this.updateEntryLineMarker?.();
        } else {
          // ✅ VALID → commit new state and sync form
          dragLine.series.setData([
            { time: newStartTime, value: finalPrice },
            { time: newEndTime, value: finalPrice },
          ]);
          dragLine.series.setMarkers([
            {
              time: newStartTime,
              position: dragLine.type === 'stoploss' ? 'belowBar' : 'aboveBar',
              color: this.getColorForMode(dragLine.type),
              shape: 'arrowUp',
              text: `${this.capitalize(dragLine.type)}: ${finalPrice.toFixed(
                2
              )}`,
            },
          ]);
          dragLine.price = finalPrice;
          dragLine.startTime = newStartTime;
          dragLine.endTime = newEndTime;

          // form sync on commit
          if (dragLine.type === 'entry') this.EntryPrice = finalPrice;
          if (dragLine.type === 'stoploss') this.StoplossPrice = finalPrice;
          if (dragLine.type === 'target') this.TargetPrice = finalPrice;

          this.fincreateformForMannualSetup.patchValue({
            entry_price:
              typeof this.EntryPrice === 'number'
                ? this.EntryPrice.toFixed(2)
                : '',
            stoploss_price:
              typeof this.StoplossPrice === 'number'
                ? this.StoplossPrice.toFixed(2)
                : '',
            target_price:
              typeof this.TargetPrice === 'number'
                ? this.TargetPrice.toFixed(2)
                : '',
          });

          this.updateEntryLineMarker?.();
        }

        isDragging = false;
        dragLine = null;
        enableChart();
      };

      el.addEventListener('mouseup', stopDrag);
      el.addEventListener('mouseleave', stopDrag);

      this._dragListenersAttached = true;
    }
  }

  getCustomMOdelPrediction() {
    this.spinner.show();
    const data = {
      order_type: 'Buy',
      entry_price: this.EntryPrice,
      target_price: this.TargetPrice,
      stoploss_price: this.StoplossPrice,
      last_d_time: this.finData.last_d_time,
      time_frame: this.finData.time_frame,
      tick: this.finData.tick,
      country_id: localStorage.getItem('selectedCountryId'),
    };
    console.log('getCustomMOdelPrediction DATA', data);
    this.apiService.getModelPredictionService(data).subscribe({
      next: (resp: any) => {
        this.ModelPrediction =
          'PROBABILITY OF TRADE : ' +
          resp.msg.toUpperCase() +
          ' = ' +
          resp.response.probability +
          ' %';
        this.SelectedPrediction = resp.msg;
        this.SelectedProbability = resp.response.probability;
        this.ViewSetUpAnywayFlag = false;
        this.showMarketAlert(this.ModelPrediction);
        this.spinner.hide(); // always runs, success or error
      },
      error: (err) => {
        this.spinner.hide(); // always runs, success or error
        console.error('Model Prediction error:', err);
        this.ModelPrediction = 'PROBABILITY OF TRADE : FAILED';
        this.SelectedPrediction = 'FAILED';
        this.SelectedProbability = 0;
        this.ViewSetUpAnywayFlag = true;
        this.showMarketAlert('Model Prediction failed. Please try again.');
      },
      complete: () => {
        this.spinner.hide(); // always runs, success or error
      },
    });
  }

  searchStocks = (term: string, item: any) => {
    if (!term) return true;
    term = term.toLowerCase().trim();
    const tick = (item?.stock_tick ?? '').toLowerCase();
    const name = (item?.name ?? '').toLowerCase();
    return tick.includes(term) || name.includes(term);
  };

  updateEntryLineMarker() {
    if (!this.EntryPrice || !this.StoplossPrice || !this.TargetPrice) return;

    const rr = this.calculateRiskToReward();
    if (rr === null) return;

    this.RiskToReward = rr.toFixed(2);
    this.fincreateform.patchValue({ risk_to_reward: this.RiskToReward });

    const entryLine = this.horizontalLines.find(
      (line) => line.type === 'entry'
    );
    if (!entryLine) return;

    entryLine.series.setMarkers([
      {
        time:
          entryLine.series.options().data?.[0]?.time ||
          entryLine.series.options().lastValueVisible,
        position: 'aboveBar',
        color: this.getColorForMode('entry'),
        shape: 'arrowUp',
        text: `Entry: ${this.EntryPrice.toFixed(2)} | RR: ${this.RiskToReward}`,
      },
    ]);
  }

  calculateRiskToReward(): number | null {
    if (this.EntryPrice && this.StoplossPrice && this.TargetPrice) {
      const risk = Math.abs(this.EntryPrice - this.StoplossPrice);
      const reward = Math.abs(this.TargetPrice - this.EntryPrice);
      if (risk === 0) return null;
      return reward / risk;
    }
    return null;
  }

  closeCreateOrderPanelforMannual() {
    this.showCreateOrderModalForMAnnual = false;
    this.fincreateformForMannualSetup.reset();
    this.submittedForMannual = false;
  }

  createForMannualSetup() {
    this.showmsg = 'Please Wait !!';
    this.submittedForMannual = true;
    this.fincreateformForMannualSetup.markAllAsTouched();
    if (this.fincreateformForMannualSetup.invalid) {
      return;
    }
    if (this.fincreateformForMannualSetup.valid) {
      this.spinner.show();
      const finDataStock = this.finform.value;
      console.log('FINDATASTOCK createForMannualSetup', finDataStock);
      this.fincreateformForMannualSetup.patchValue({
        prediction: this.SelectedPrediction,
        probability: this.SelectedProbability / 100,
        country_id: this.countryId,
        stock_tick: this.selectedStockId,
        purchased_cmp_date: this.getCurrentDateTime(),
        time_frame: finDataStock.time_frame,
        stock_id: String(this.UpdateCnadleStockId),
      });
      const fincreateorderData = this.fincreateformForMannualSetup.value;
      console.log('Homecandle formss', fincreateorderData);
      this.apiService.createorder(fincreateorderData).subscribe((resp) => {
        console.log('create response', resp);
        this.createorderResp = resp;
        if (resp.msg == 'success') {
          // this.closemodal.nativeElement.click();
          this.spinner.hide();
          this.toastr.success('Order Create Success ', 'ALERT !');
          this.closeCreateOrderPanelforMannual();
          this.stopTimer();
        } else {
          this.spinner.hide();
          this.toastr.error(resp.response, 'ALERT !');
        }
      });
    }
  }

  openCreateOrderPanelforMannual() {
    this.showCreateOrderModalForMAnnual = true;
  }

  getLineByType(type: 'entry' | 'target' | 'stoploss') {
    return this.horizontalLines.find((l) => l.type === type) || null;
  }

  get entryLine() {
    return this.getLineByType('entry');
  }
  get targetLine() {
    return this.getLineByType('target');
  }
  get stoplossLine() {
    return this.getLineByType('stoploss');
  }

  private previewMessage(
    text: string,
    atTime: number,
    position: 'aboveBar' | 'belowBar' = 'aboveBar'
  ) {
    if (!this.previewLine) return;
    this.previewLine.setMarkers([
      {
        time: atTime,
        position,
        color: 'gray',
        shape: 'arrowUp',
        text,
      },
    ]);
  }

  private clearPreviewMessage() {
    if (!this.previewLine) return;
    this.previewLine.setMarkers([]);
  }

  private validatePlacement(
    mode: 'entry' | 'target' | 'stoploss',
    price: number
  ): { ok: boolean; msg?: string } {
    if ((mode === 'target' || mode === 'stoploss') && !this.entryLine) {
      return { ok: false, msg: 'Place Entry first' };
    }

    // NEW: If placing/moving Entry and both SL & Target exist, Entry must be between them
    if (mode === 'entry') {
      if (this.stoplossLine && this.targetLine) {
        const sl = this.stoplossLine.price;
        const tg = this.targetLine.price;
        const lo = Math.min(sl, tg);
        const hi = Math.max(sl, tg);

        if (price <= lo || price >= hi) {
          return {
            ok: false,
            msg: 'Entry must be between Stoploss and Target',
          };
        }
        if (price === sl || price === tg) {
          return { ok: false, msg: 'Entry cannot equal Stoploss or Target' };
        }
      }
      return { ok: true };
    }

    const entryPrice = this.entryLine?.price ?? 0;
    const isAbove = price > entryPrice;
    const isBelow = price < entryPrice;

    if (price === entryPrice) {
      return { ok: false, msg: 'Move off the Entry price' };
    }

    if (mode === 'stoploss') {
      if (this.targetLine) {
        const targetAbove = this.targetLine.price > entryPrice;
        if (targetAbove && !isBelow)
          return {
            ok: false,
            msg: 'Stoploss must be BELOW Entry (Target is above)',
          };
        if (!targetAbove && !isAbove)
          return {
            ok: false,
            msg: 'Stoploss must be ABOVE Entry (Target is below)',
          };
      }
    }

    if (mode === 'target') {
      if (this.stoplossLine) {
        const slAbove = this.stoplossLine.price > entryPrice;
        if (slAbove && !isBelow)
          return {
            ok: false,
            msg: 'Target must be BELOW Entry (Stoploss is above)',
          };
        if (!slAbove && !isAbove)
          return {
            ok: false,
            msg: 'Target must be ABOVE Entry (Stoploss is below)',
          };
      }
    }

    if (
      (mode === 'target' && this.stoplossLine) ||
      (mode === 'stoploss' && this.targetLine)
    ) {
      const sl = mode === 'stoploss' ? price : this.stoplossLine!.price;
      const tg = mode === 'target' ? price : this.targetLine!.price;
      const lo = Math.min(sl, tg);
      const hi = Math.max(sl, tg);
      if (!(entryPrice > lo && entryPrice < hi)) {
        return {
          ok: false,
          msg: 'Entry must remain between Stoploss and Target',
        };
      }
    }

    return { ok: true };
  }

  removeAllEntry() {
    ['entry', 'stoploss', 'target'].forEach((type) => {
      const line = this.horizontalLines.find((l) => l.type === type);
      if (line && line.series) {
        try {
          this.chart.removeSeries(line.series);
        } catch (e) {
          console.warn(`Series for ${type} already removed`, e);
        }
      }
    });
    this.horizontalLines = this.horizontalLines.filter(
      (l) => !['entry', 'stoploss', 'target'].includes(l.type)
    );
    this.selectedLine = null;
  }
  openPopup() {
    this.modalA.show();
  }

  PricePercentage() {
    this.apiService.PricePercentageService(this.finData).subscribe(resp => {
      this.PricePercentageData = resp.response;
      this.PP_Analyze = this.PricePercentageData.analyze;
      this.PP_Evaluate = this.PricePercentageData.evaluate;
      this.PP_Execute = this.PricePercentageData.execute;
      this.PP_Reason = this.PricePercentageData.reason;
      this.PP_FinalDecision = this.PricePercentageData.final_decision
    });
  }
}
