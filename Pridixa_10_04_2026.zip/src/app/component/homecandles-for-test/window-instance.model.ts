export interface WindowInstance {
    id: number;
    isMinimized: boolean;
    isMaximized: boolean;
  }
  