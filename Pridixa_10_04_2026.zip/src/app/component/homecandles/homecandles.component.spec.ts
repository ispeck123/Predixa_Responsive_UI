import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HomecandlesComponent } from './homecandles.component';

describe('HomecandlesComponent', () => {
  let component: HomecandlesComponent;
  let fixture: ComponentFixture<HomecandlesComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [HomecandlesComponent]
    });
    fixture = TestBed.createComponent(HomecandlesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
