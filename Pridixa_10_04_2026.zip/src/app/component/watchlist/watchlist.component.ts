import { Component, ElementRef, QueryList, ViewChildren } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Subscription } from 'rxjs';
import { ApiService } from 'src/app/services/api.service';
import { WebSocketService } from 'src/app/services/web-socket.service';
import Swal from 'sweetalert2';


type WatchlistWsResponse = {
  total_stocks: number;
  page_no: number;
  stocks: any[];
};

@Component({
  selector: 'app-watchlist',
  templateUrl: './watchlist.component.html',
  styleUrls: ['./watchlist.component.css']
})
export class WatchlistComponent {

  activeMenu: string = 'stock';
  private wlSub?: Subscription;
  private lastRequestKey = '';   // helps ignore stale responses
  private autoLocateOnce = false;  // ✅ only true right after new search
  errorMsg = '';
  isNoData = false;
  searchText = '';
  serverSearchKey = '';       // what we actually send to backend
  private searchTimer: any = null;
  @ViewChildren('wlRow') wlRows!: QueryList<ElementRef<HTMLElement>>;




  WatchlistData: any[] = [];
  totalStocks = 0;

  // pagination
  pageNo = 1;
  pageSize = 10;          // default page size
  totalPages = 1;

  // filters
  sortKey: 'stock' | 'price' | 'day_change_percentage' = 'stock';
  sortDir: 'asc' | 'desc' = 'asc';

  Role: any;
  UserName: any;
  isAdmin: boolean = false;
  UserId: any;
  countryId: any;

  // ui
  isLoading = true;

  constructor(
    private toastr: ToastrService,
    private webSocketService: WebSocketService,
    private router: Router,
    private apiService: ApiService
  ) { }

  ngOnInit(): void {
    this.UserId = localStorage.getItem('UserId');
    this.countryId = localStorage.getItem('selectedCountryId');
    this.Role = localStorage.getItem('role');
    this.isAdmin = (this.Role === 'admin');
    this.UserName = localStorage.getItem('UserName');

    this.connectWatchListWebsocket();
  }

  ngOnDestroy(): void {
    this.wlSub?.unsubscribe();
    this.disconnectWebSocket();
  }

  disconnectWebSocket(): void {
    this.webSocketService.disconnectWatchlistSocket?.(); // if you have it
  }

  connectWatchListWebsocket(): void {
    this.isLoading = true;

    this.wlSub?.unsubscribe();
    this.disconnectWebSocket();

    const key = (this.serverSearchKey || '').trim();

    // ✅ only send null for page_no on the FIRST request after typing search
    const pageToSend: any = (key && this.autoLocateOnce) ? null : this.pageNo;

    this.webSocketService.connectWatchlist(
      this.UserId,
      this.countryId,
      "NSE",
      pageToSend,
      this.pageSize,
      key
    );

    const requestKey = `${this.UserId}|${this.countryId}|NSE|${pageToSend}|${this.pageSize}|${key}`;
    this.lastRequestKey = requestKey;

    this.wlSub = this.webSocketService.getWatchlistData().subscribe((data) => {
      if (this.lastRequestKey !== requestKey) return;

      this.errorMsg = '';
      this.isNoData = false;

      let ws: any;

      // ✅ handle plain string / invalid JSON
      try {
        ws = JSON.parse(data);
      } catch (e) {
        const s = String(data || '');
        if (s.toLowerCase().includes('error')) {
          this.WatchlistData = [];
          this.totalStocks = 0;
          this.totalPages = 1;
          this.isNoData = true;
          this.errorMsg = 'No data found for your search.';
          this.isLoading = false;
          return;
        }
        return;
      }

      // ✅ handle backend explicit error message
      const msg = String(ws?.msg || ws?.message || '').toLowerCase();
      if (msg.includes('error fetching stock price') || msg.includes('error')) {
        this.WatchlistData = [];
        this.totalStocks = 0;
        this.totalPages = 1;
        this.isNoData = true;
        this.errorMsg = 'No data found for your search.';
        this.isLoading = false;
        return;
      }

      // ✅ normal success response
      this.pageNo = this.toNumber(ws.page_no) || 1;
      this.totalStocks = this.toNumber(ws.total_stocks);
      this.totalPages = Math.max(1, Math.ceil(this.totalStocks / this.pageSize));

      const key = (this.serverSearchKey || '').trim().toLowerCase();
      const raw = Array.isArray(ws.stocks) ? ws.stocks : [];

      this.WatchlistData = raw.map((item: any) => ({
        ...item,
        day_change_percentage: this.toNumber(item.day_change_percentage),
        day_change: this.normalizeChangeText(item.day_change),
        __highlight: key ? String(item.stock || '').toLowerCase().includes(key) : false
      }));

      this.scrollToHighlight();

      // ✅ if response is empty => show No Data UI
      if (!this.WatchlistData.length) {
        this.isNoData = true;
        this.errorMsg = key ? 'No data found for your search.' : 'No watchlist found.';
      }

      if (key && this.autoLocateOnce) this.autoLocateOnce = false;

      this.isLoading = false;
    });

  }

private scrollToHighlight() {
  // only when searching
  if (!this.serverSearchKey) return;

  // wait for DOM render
  setTimeout(() => {
    const rows = this.wlRows?.toArray() || [];
    if (!rows.length) return;

    const idx = this.WatchlistData.findIndex(x => x.__highlight);
    if (idx < 0) return;

    const el = rows[idx]?.nativeElement;
    if (!el) return;

    // smooth scroll to row
    el.scrollIntoView({ behavior: 'smooth', block: 'center' });

    // optional: pulse animation (nice UX)
    el.classList.add('wl-pulse');
    setTimeout(() => el.classList.remove('wl-pulse'), 900);
  }, 60);
}



  toNumber(val: any): number {
    if (val === null || val === undefined) return 0;
    if (typeof val === 'number') return Number.isFinite(val) ? val : 0;

    const s = String(val).trim();
    if (!s) return 0;

    const cleaned = s.replace(/%/g, '').replace(/,/g, '').trim();
    const n = Number(cleaned);
    return Number.isFinite(n) ? n : 0;
  }

  normalizeChangeText(v: any): string {
    const s = String(v ?? '').trim();
    return s || '-';
  }

  getChangeClass(stock: any): string {
    const pct = this.toNumber(stock?.day_change_percentage);
    if (pct > 0) return 'up';
    if (pct < 0) return 'down';
    return 'flat';
  }

  // ---------- pagination ----------
  goToPage(p: number) {
    const next = Math.min(Math.max(1, p), this.totalPages);
    if (next === this.pageNo) return;
    this.pageNo = next;
    this.connectWatchListWebsocket();
  }

  nextPage() {
    this.goToPage(this.pageNo + 1);
  }

  prevPage() {
    this.goToPage(this.pageNo - 1);
  }

  changePageSize(size: number) {
    this.pageSize = Number(size) || 10;
    this.pageNo = 1;
    this.connectWatchListWebsocket();
  }

  // show pages like: 1 2 3 ... 9 10 11 ... 35
  getVisiblePages(): (number | '...')[] {
    const total = this.totalPages;
    const current = this.pageNo;

    if (total <= 7) {
      return Array.from({ length: total }, (_, i) => i + 1);
    }

    const pages: (number | '...')[] = [];
    const add = (p: number | '...') => pages.push(p);

    add(1);

    // left side
    if (current > 4) add('...');

    const start = Math.max(2, current - 1);
    const end = Math.min(total - 1, current + 1);

    for (let p = start; p <= end; p++) add(p);

    // right side
    if (current < total - 3) add('...');

    add(total);

    return pages;
  }

  jumpToPageInput = '';

  jumpToPage() {
    const n = Number(String(this.jumpToPageInput).trim());
    if (!Number.isFinite(n)) return;
    this.goToPage(n);
    this.jumpToPageInput = '';
  }

  onPageClick(p: number | '...') {
    if (p === '...') return;
    this.goToPage(p);
  }


  onSearchChange() {

    clearTimeout(this.searchTimer);
    this.searchTimer = setTimeout(() => {
      const key = (this.searchText || '').trim();

      if (!key) {
        // back to normal mode
        this.serverSearchKey = '';
        this.autoLocateOnce = false;
        this.pageNo = 1;
        this.connectWatchListWebsocket();
        return;
      }

      // ✅ New search starts: auto locate once
      this.serverSearchKey = key;
      this.autoLocateOnce = true;   // only first request will send page_no = null
      this.pageNo = 1;              // UI fallback
      this.connectWatchListWebsocket();
    }, 350);
  }

  toggleSort(key: 'stock' | 'price' | 'day_change_percentage') {
    if (this.sortKey === key) {
      this.sortDir = this.sortDir === 'asc' ? 'desc' : 'asc';
    } else {
      this.sortKey = key;
      this.sortDir = 'asc';
    }
    this.applyClientSideFilterSort();
  }

  private applyClientSideFilterSort() {
    const q = this.searchText.trim().toLowerCase();

    let arr = [...this.WatchlistData];

    if (q) {
      arr = arr.filter(x => String(x?.stock ?? '').toLowerCase().includes(q));
    }

    arr.sort((a, b) => {
      const dir = this.sortDir === 'asc' ? 1 : -1;
      const k = this.sortKey;

      const av = (k === 'stock') ? String(a?.stock ?? '') : this.toNumber(a?.[k]);
      const bv = (k === 'stock') ? String(b?.stock ?? '') : this.toNumber(b?.[k]);

      if (typeof av === 'string' && typeof bv === 'string') {
        return av.localeCompare(bv) * dir;
      }
      return (Number(av) - Number(bv)) * dir;
    });

    this.WatchlistData = arr;
  }

  // ---------- navigation ----------
  ViewAnalytics(stock_tick: any) {
    this.router.navigate(['chart_analytics', stock_tick]);
  }

  removeFromWatchlist(watchlist_id: any, stockName?: string) {

    Swal.fire({
      title: 'Remove from Watchlist?',
      html: `<div style="font-size:13px;color:#6b7280;margin-top:6px;">
            ${stockName ? `<b>${stockName}</b><br/>` : ''}
            This will remove the stock from your watchlist.
          </div>`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, remove',
      cancelButtonText: 'Cancel',
      reverseButtons: true,
      focusCancel: true,
      buttonsStyling: false,
      customClass: {
        popup: 'swal-pro-popup',
        title: 'swal-pro-title',
        confirmButton: 'swal-pro-confirm',
        cancelButton: 'swal-pro-cancel',
        actions: 'swal-pro-actions'
      }
    }).then((result) => {
      if (!result.isConfirmed) return;

      this.apiService.removeFromWatchlist(watchlist_id).subscribe(resp => {
        if (resp.msg === "success") {
          this.toastr.success("Removed!");
          this.connectWatchListWebsocket();
        } else {
          this.toastr.error("Failed!");
        }
      });
    });
  }

  clearSearch() {
  this.searchText = '';
  this.serverSearchKey = '';
  this.autoLocateOnce = false;

  this.errorMsg = '';
  this.isNoData = false;

  this.pageNo = 1;
  this.jumpToPageInput = '';

  this.connectWatchListWebsocket();
}


}
