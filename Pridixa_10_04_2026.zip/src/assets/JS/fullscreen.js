
// FULLSCREEN 1

function openFullscreenModal1() {
    const fullscreenModal = document.querySelector('.fullscreen-modal1');
    fullscreenModal.style.display = 'block';
}

function closeFullscreenModal1() {
    const closeButton = document.querySelector('.close-button');
    const fullscreenModal = document.querySelector('.fullscreen-modal1');
    fullscreenModal.style.display = 'none';
}

// END FULLSCREEN 1


// FULLSCREEN 2

function openFullscreenModal2() {
    const fullscreenModal = document.querySelector('.fullscreen-modal2');
    fullscreenModal.style.display = 'block';
}

function closeFullscreenModal2() {
    const fullscreenModal = document.querySelector('.fullscreen-modal2');
    fullscreenModal.style.display = 'none';
}

// END FULLSCREEN 2

// FULLSCREEN 3

function openFullscreenModal3() {
    const fullscreenModal = document.querySelector('.fullscreen-modal3');
    fullscreenModal.style.display = 'block';
}

function closeFullscreenModal3() {
    const fullscreenModal = document.querySelector('.fullscreen-modal3');
    fullscreenModal.style.display = 'none';
}

// END FULLSCREEN 3

// FULLSCREEN 4

function openFullscreenModal4() {
    const fullscreenModal = document.querySelector('.fullscreen-modal4');
    fullscreenModal.style.display = 'block';
}

function closeFullscreenModal4() {
    const fullscreenModal = document.querySelector('.fullscreen-modal4');
    fullscreenModal.style.display = 'none';
}

// END FULLSCREEN 4

// FULLSCREEN 5

function openFullscreenModal5() {
    const fullscreenModal = document.querySelector('.fullscreen-modal5');
    fullscreenModal.style.display = 'block';
}

function closeFullscreenModal5() {
    const fullscreenModal = document.querySelector('.fullscreen-modal5');
    fullscreenModal.style.display = 'none';
}

// END FULLSCREEN 5

// Global

function openFullscreenModalglobal() {
    const fullscreenModal = document.querySelector('.fullscreen-modalglobal');
    fullscreenModal.style.display = 'block';
}

function closeFullscreenModalglobal() {
    const closeButton = document.querySelector('.close-buttonglobal');
    const fullscreenModal = document.querySelector('.fullscreen-modalglobal');
    fullscreenModal.style.display = 'none';
}